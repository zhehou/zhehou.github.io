use "make" to compile and generate the executable file

Specify a formula in a file (I usually use bi_formulae.bi), the grammar is:
f ::= true | false | mtrue | e |-> e | e |-> e,e | e = e | ~f | f & f | f -> f | f * f | f -* f | exists y.(f) | forall y.(f) 

You can also write | for classical or. 

then use the following commands:

./lssl [-sh] [-verbose] [-r] filename

or

./lssl [-sh] [-verbose] [-o] [-g] filename

-sh: restrict the prover to only use rules for symbolic heaps.
-verbose: print detailed information on the screen.
-r: prove a list of formulae separated by 1 line in filename. 
-o: output the derivation in a pdf file.
-g: print the ternary relational atoms in the pdf file.

You must use -o if you wanna use -g. You cannot use -o or -g when you use -r, and vice versa.

If you need help, use 

./lssl -help

NOTE THAT:
please DO NOT use "x..." for expressions or binded variables, the system will automatically rename the variables to "x...", so "x" is reserved for the system.

some example formulae are in the files *.bi

