let rec cartesian = function 
  [] -> [[]]
  | head::tail ->
      let rest = cartesian tail in
      List.concat(List.map (fun y -> List.map (fun ys -> y::ys) rest) head);;

let explode s =
  let rec f acc = function
    | -1 -> acc
    | k -> f (s.[k] :: acc) (k - 1)
  in f [] (String.length s - 1);;

let matches s = 
  let chars = 
    explode s in 
    fun c -> List.mem c chars;;

let space = matches " \t\n\r"
and punctuation = matches "()[]{},"
and symbolic = matches "~`!@#$%^&*-+=|\\:;<>.?/"
and numeric = matches "0123456789"
and alphanumeric = matches
  "abcdefghijklmnopqrstuvwxyz_'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";; 

let rec sublist list i j = 
  if i > j then 
    []
  else 
    if i = j then
      [List.nth list i]
    else 
      (List.nth list i)::(sublist list (i+1) j);;   

let rec sblists e acc l =
  match l with
    | h::t -> if h = e then acc@t else sblists e (acc@[h]) t
    | _ -> failwith "Element not in list!";; 

(* delete an occurrence of e from l *)
let subtlist e l = sblists e [] l;;

(* delete all occurrrences of e from l *)
let rec subtalllist e l =
  match l with
  | h::t -> if h = e then subtalllist e t else [h]@(subtalllist e t)
  | _ -> [];;

(* substitution [x/y] on the list l *)
let subslist x y l = 
  let rec subs x y l acc =
    match l with
    | h::t -> if h = y then subs x y t (acc@[x]) else subs x y t (acc@[h])
    | _ -> acc
  in 
  subs x y l [];;

(* substitution [x/y] on a list of lists ll *)
let subslistlist x y ll =
  let rec subs x y ll acc =
    match ll with
    | h::t -> subs x y t (acc@[subslist x y h])
    | _ -> acc 
  in 
  subs x y ll [];;

(* test if list l1 is the subset of list l2*)
let rec listsubset l1 l2 =
  match l1 with
  | h::t -> if List.mem h l2 then listsubset t l2 else false
  | _ -> true;;

(* test if two lists l1 and l2 contains the same set of elements *)
let equalsetlist l1 l2 = if (listsubset l1 l2) && (listsubset l2 l1) then true else false;;

(* test if two lists l1 and l2 contains the same multiset of elements *)
let rec equalmultisetlist l1 l2 = 
  match l1 with
  | h::t ->
     if List.mem h l2 then 
       equalmultisetlist t (subtlist h l2) 
     else false
  | _ -> if (List.length l2) = 0 then true else false;;

(* return the elements in l1 that are not in l2 *)
let rec listsetdiff l1 l2 =
  match l1 with
  | h::t -> if List.mem h l2 then listsetdiff t l2 else [h]@(listsetdiff t l2)
  | _ -> [];;

(* test if two lists of lists ll1 and ll2 contains a common list with *)
(* the same set of elements *)
let rec commonsetlists ll1 ll2 =
  let rec containslist l ll =
    match ll with
    | h::t -> if equalsetlist l h then true else containslist l t 
    | _ -> false
  in 
  match ll1 with
  | h::t -> if containslist h ll2 then true else commonsetlists t ll2 
  | _ -> false;;

let rec outputlist file = function
  |h::t -> output_string file (h^";"); outputlist file t
  |[] -> ();;

let rec outputlistlist file = function 
  |h::t -> output_string file "["; outputlist file h; output_string file "];"; outputlistlist file t
  |[] -> ();; 

let rec overlaplist = function
  |head::tail -> 
     let rec testrest act = function
       |h::t ->
	  if (String.compare act h) == 0 then true
	  else testrest act t
       |[] -> false
     in
       if testrest head tail then true
       else overlaplist tail
  |[] -> false;;
     
let isemptylist = function
  |[] -> true
  |h::t -> false;;

(* Read a line in the file *)
let readfile filename = 
  let fp = open_in filename in
  let str = input_line fp in
  let _ = close_in fp in
    str;;

(* Read every line in the file, return a list of lines *)
let readfileall filename =
  let fp = open_in filename in
  let nonspace str = 
    let chars = explode str in
    let rec checkalph charlist = 
      match charlist with 
      | h::t -> if alphanumeric h then true else checkalph t
      | _ -> false
    in 
    checkalph chars
  in 
  let rec readall fp acc =
    try 
      let line = input_line fp in 
      if nonspace line then readall fp (acc@[line])
      else readall fp acc
    with End_of_file -> acc
  in 
  let linelist = readall fp [] in
  let _ = close_in fp in
  linelist;;

(* Read every line in the file, return a string of lines *)
let readfileall_str filename =
  let fp = open_in filename in
  let nonspace str = 
    let chars = explode str in
    let rec checkalph charlist = 
      match charlist with 
      | h::t -> if alphanumeric h then true else checkalph t
      | _ -> false
    in 
    checkalph chars
  in 
  let rec readall fp acc =
    try 
      let line = input_line fp in 
      if nonspace line then readall fp (acc^line)
      else readall fp acc
    with End_of_file -> acc
  in 
  let linestr = readall fp "" in
  let _ = close_in fp in
  linestr;;

(*search key words from a string *)
let searchword words str =
  let regexp = Str.regexp words in
  let rec search re str pos =
    if pos >= String.length str then false 
    else if Str.string_match re str pos then true 
    else search re str (pos+1) 
  in 
  search regexp str 0;;

(* Write a list of lines into files, a line for a file *)
let writefilesall filename linelist =
  let mkfilename filename num =
    let pos = String.index filename '.' in
    ((String.sub filename 0 pos)^(string_of_int num)^(String.sub filename pos ((String.length filename)-pos)))
  in 
  let rec write filename linelist acc =
    match linelist with
    | h::t -> 
      let fp = open_out (mkfilename filename acc) in
      output_string fp h;close_out fp;write filename t (acc+1)
    | _ -> acc-1
  in 
  write filename linelist 0;;
   

module SetOfList (E : Set.OrderedType) = struct
  module S = Set.Make(E)
  let set_of_list li =
    List.fold_left (fun set elem -> S.add elem set) S.empty li
end

module SoL = SetOfList(String);;

(* Randomly insert an element into a list *)
let randinsertlist e l =
  let pos = Random.int ((List.length l)+1) in
  let rec insert e pos l acc = 
    match l with
    | h::t-> if pos = 0 then insert e (pos-1) t (acc@[e;h]) else insert e (pos-1) t (acc@[h])
    | _ -> if pos = 0 then (acc@[e]) else acc
  in 
  insert e pos l [];;

(* eliminate duplicate elements in a list *)
let setlist l =
  let rec fresh l acc =
    match l with
    | h::t -> if List.mem h acc then fresh t acc else fresh t (acc@[h])
    | _ -> acc
  in 
  fresh l [];;

(* test if list l contains an element multiple times *)
let rec distinctlist l =
  match l with
  | h::t -> if List.mem h t then false else distinctlist t 
  | _ -> true;;

(* initialise the random seed *)
let _ = Random.self_init ();;

(* randomly choose a member from a list *)
let rand_listmem l =
  let randindex = Random.int (List.length l) in
  let rec getmem l index =
    if index > 0 then 
      match l with
      | h::t -> getmem t (index-1)
      | _ -> failwith "getmem(): index is longer than the list"
    else List.hd l
  in 
  getmem l randindex;;

(* compare if two lists l1, l2 have a common element *)
let intersectinglists l1 l2 =
  let rec compare l1 l2 = 
    match l1 with 
    | h::t -> if List.mem h l2 then true else compare t l2
    | _ -> false
  in 
  compare l1 l2;;

(* randomly shuffle a list *)
let shuffle d =
    let nd = List.map (fun c -> (Random.bits (), c)) d in
    let sond = List.sort compare nd in
    List.map snd sond;;

(* given a list l of natural numbers, return the largest number *)
let listmaxn l =
  let rec findmax l max =
    match l with 
    | h::t -> if h > max then findmax t h else findmax t max
    | _ -> max
  in 
  findmax l 0;;

(* convert a list of pairs into a list *)
let rec list_of_pairs pl =
  match pl with
  | h::t -> let (p1,p2) = h in [p1;p2]@(list_of_pairs t)
  | _ -> [];;
 
(* given two lists l1 and l2, return their intersection *)
let rec list_intersect l1 l2 =
  match l1 with
  | h::t -> 
    if List.mem h l2 then [h]@(list_intersect t l2) 
    else list_intersect t l2
  | _ -> [];;
