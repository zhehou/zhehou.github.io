module F = BIformulae
module M = Misc

(* A global variable for the number of labels *)
let labelnum = ref 0;;
let expnum = ref 0;;

(* (\* labels hx are created for the (x+1)th -*L formula in this list *\) *)
(* let mlforms = ref [];; *)

(* test if x is a variable, we assume variables start with "x" *)
let isvar x = if x.[0] = 'x' then true else false;;

(* given a list lfl of labelled formulae, find all the formulae with label l *)
(* may return repeated formulae *)
let rec labelledform l lfl =
  match lfl with 
  | h::t -> let F.LF(l1,f1) = h in if l1 = l then (labelledform l t)@[f1] else labelledform l t
  | _ -> [];;

(* test if a list fl of formulae contains a pointsto formula *)
let rec haspointer fl =
  match fl with
  | h::t -> 
    (match h with
    | F.AP(F.PT(_,_)) -> true
    | _ -> haspointer t)
  | _ -> false;;

(* given a list g of ternary relations and a label w *)
(* return the parents of w in g *)
(* if w doens't have a parent, return [] *)
let getparent g w =
  let rec search g w =
    match g with
    | h::t -> 
      let F.RT(a1,a2,a3) = h in
      if w = a1 || w = a2 then [a3]@(search t w)
      else search t w 
    | _ -> []
  in 
  M.setlist (search g w);;

(* given a list g of ternary relations and a label w *)
(* return the direct children of w in g *)
(* w is NOT it's own direct child *)
let dirchd g w =
  let rec findchildren w g =
    match g with
    | h::t -> 
      let F.RT(a1,a2,a3) = h in 
      if a3 = w then 
	if a1 = "epsilon" || a2 = "epsilon" then findchildren w t
	else 
	  (if a1 <> w && a2 <> w then (findchildren w t)@[a1;a2]
	   else if a1 <> w then (findchildren w t)@[a1]
	   else if a2 <> w then (findchildren w t)@[a2]
	   else findchildren w t)
      else findchildren w t
    | _ -> []
  in 
  M.setlist (findchildren w g);;

(* given a list g of ternary relations and a label w *)
(* return the height of w in it descending chain in g *)
let rec labelh g w =
  let dchd = dirchd g w in
  1 + (M.listmaxn (List.map (labelh g) dchd));;

(* given a list g of ternary relations, and a label w *)
(* return all descendents of w *)
let allchd g w =
  let rec findallchd g cl = 
    if cl = [] then [] else cl@(findallchd g (List.flatten (List.map (dirchd g) cl)))
  in 
  M.subtlist w (M.setlist (findallchd g [w]));; 

(* given a list g of ternary relations *)
(* a parent p and a direct child d1 *)
(* find the other direct child d2 *)
let rec otherdirchd g p d1 =
  match g with
  | h::t -> 
    let F.RT(a1,a2,a3) = h in
    if a3 = p && a1 = d1 then a2
    else if a3 = p && a2 = d1 then a1
    else otherdirchd t p d1
  | _ -> "-1";;

(* test if ax expsubs is invalid *)
(* such as ("nil","nil"), ("12312","nil"), ("23","5") etc*)
let invalidexpsub expsub =
  let (e1,e2) = expsub in
  if (e1 <> e2) && (e1 = "nil" || F.isnumstr e1) && (e2 = "nil" || F.isnumstr e2) then true
  else false;;

(* given a list of expression subs expsubl *)
(* detect if there are invalid subs such as ("nil","nil") *)
(* ("12312","nil"), ("23","5") etc *)
let rec invalidexpsubl expsubl =
  match expsubl with
  | h::t -> if invalidexpsub h then true else invalidexpsubl t 
  | _ -> false;;

(* print a list of pairs of relational atoms *)
let rec print_rpairl rpl = 
  match rpl with
  | h::t -> let (r1,r2) = h in F.print_rel r1;print_string " , ";F.print_rel r2;print_endline "";print_rpairl t
  | _ -> ();;

(* get all labels that occur in a list of relations *)
let getrllabels rl =
  let rec labels rl acc =
    match rl with 
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      let test1 = List.mem s1 acc in
      let test2 = List.mem s2 acc in
      let test3 = List.mem s3 acc in
      if test1 && test2 && test3 then labels t acc
      else if test1 && test2 then labels t (acc@[s3])
      else if test1 && test3 then labels t (acc@[s2])
      else if test2 && test3 then labels t (acc@[s1])
      else if test1 then labels t (acc@[s2;s3])
      else if test2 then labels t (acc@[s1;s3])
      else if test3 then labels t (acc@[s1;s2])
      else labels t (acc@[s1;s2;s3])
    | _ -> acc
  in 
  labels rl [];;

(* get all labels that occur in a list of labelled formulae *)
let getfllabels fl =
  let rec labels fl acc =
    match fl with
    | h::t -> 
      let label = F.lb h in 
      if List.mem label acc then labels t acc else labels t (acc@[label])
    | _ -> acc
  in 
  labels fl [];;

(* get all labels that occur in a sequent *)
let getseqlabels seq =
  let F.SEQ(g,lf,rf) = seq in 
  (getrllabels g)@(getfllabels lf)@(getfllabels rf);;

(* Find the formula f in the list of labelled formulae l. *)
(* Return the label (a number) if found, otherwise return "-1". *)
let rec findf f l =
  match l with 
    | h::t -> if (F.fm h) = f then (F.lb h) else findf f t
    | _ -> "-1";;

(* Find a labelled formula in l that matches lf in the id rule *)
let rec findlf lf l =
  match l with
  | h::t -> if ((F.fm h) = (F.fm lf)) && ((F.lb h) = (F.lb lf)) then (F.lb h) else findlf lf t
  | _ -> "-1";;

(* test if a label is a leaf node *)
let rec is_leaf l g =
  match g with
  | h::t -> 
    let F.RT(a1,a2,a3) = h in 
    if a3 = l && a1 <> "epsilon" && a2 <> "epsilon" then false 
    else is_leaf l t
  | _ -> true;;

(* test if w is a leave in the 2lvl tree tr *)
let isleave w tr = if List.mem w (snd tr) then true else false;;

(* given a list g of ternary relations *)
(* find the set of leaves *)
let getleaves g =
  let alllabels = getrllabels g in
  let rec findleaves ll g =
    match ll with
    | h::t -> if is_leaf h g then [h]@(findleaves t g) else findleaves t g
    | _ -> []
  in 
  findleaves alllabels g;;

(* test if a label is a root node *)
let rec is_root l g =
  match g with
  | h::t -> 
    let F.RT(a1,a2,a3) = h in
    if a1 = l && a2 <> "epsilon" && a3 <> l then false 
    else if a2 = l && a1 <> "epsilon" && a3 <> l then false 
    else is_root l t
  | _ -> true;;

(* given a list g of ternary relations *)
(* fidn the set of roots *)
let getroots g =
  let alllabels = getrllabels g in
  let rec findroots ll g =
    match ll with
    | h::t -> if is_root h g then [h]@(findroots t g) else findroots t g
    | _ -> []
  in 
  findroots alllabels g;;

(* given two labels l1, l2, and a list g of ternary relations *)
(* test if l1 and l2 have the same set of leaves *)
let sameleaves l1 l2 g =
  let leaves = getleaves g in
  let allchd1 = allchd g l1 in
  let allchd2 = allchd g l2 in
  let allleave1 = M.list_intersect allchd1 leaves in
  let allleave2 = M.list_intersect allchd2 leaves in
  if allleave1 = [] || allleave2 = [] then false
  else if M.equalsetlist allleave1 allleave2 then true
  else false;;

(* given a set of leaves, and a list g of relations *)
(* find the set of labels with this set of leaves *)
let findlabel_by_leaves leaves g =
  let alllabel = getrllabels g in
  let allleaves = getleaves g in
  let rec find leaves ll allleaves g =
    match ll with
    | h::t -> 
      let hallchd = allchd g h in
      let hleaves = M.list_intersect hallchd allleaves in
      if M.equalsetlist hleaves leaves then [h]@(find leaves t allleaves g)
      else find leaves t allleaves g
    | _ -> []
  in 
  find leaves alllabel allleaves g;;

(* given a label l, a label list ll  and a list g of relations *)
(* find the set of labels from ll with the same set of leaves as l *)
let rec findisolabels l ll g =
  match ll with
  | h::t -> 
    if sameleaves l h g then [(l,h)]@(findisolabels l t g) 
    else findisolabels l t g
  | _ -> [];;	

(* given a list g of ternary relations *)
(* return a list of label pairs [(l1,l2)] *)
(* such that l1 and l2 have the same set of leaves *)
let getisolabel g =
  let alllabels = getrllabels g in
  let rec find ll g =
    match ll with
    | h::t -> (findisolabels h t g)@(find t g)
    | _ -> []
  in 
  find alllabels g;;

(*************** the following are for inference rules ***************)
(* each rule takes a sequent as input, and output a inference, i.e., *)
(* UINF for a single sequent, and BINF for a pair of sequents        *)
(* each rule also output the principal formulae *)
(*********************************************************************)

(* Find the identical formulae with the same label in lf and rf *)
(* if found, return the labelled formula, *) 
(* otherwise return LF.nulllf. *)
let rec findidpair_f l r =
  match l with 
    | h::t ->
      let label2 = findlf h r in
      if label2 = "-1" then findidpair_f t r else h
    | _ -> F.nulllf;;

(* given two lists of fields fl1 and fl2 *)
(* test if fl1 includes fl2 *)
let rec fieldinc fl1 fl2 =
  match fl2 with
  | h2::t2 -> 
    (match fl1 with
    | h1::t1 -> 
      if h1 = h2 then fieldinc t1 t2
      else false
    | _ -> false)
  | _ -> true;;

(* find identical heaps of the form *)
(* e1|->fl1,fl2 from the LHS, and e1|->fl1 from the RHS *)
let rec findidpair_hp l r =
  let rec find lf r =
    match r with
    | h::t ->
      if (F.lb lf) = (F.lb h) then
	(match F.fm lf with
	| F.AP(F.PT(e1,fl1)) ->
	  (match F.fm h with
	  | F.AP(F.PT(e2,fl2)) -> 
	    if e1 = e2 && (fieldinc fl1 fl2) then  (lf,h) 
	    else find lf t
	  | _ -> find lf t)
	| _ -> find lf t)
      else find lf t
    | _ -> (F.nulllf,F.nulllf)
  in
  match l with
  | h::t ->
    let (lpf,rpf) = find h r in
    if lpf = F.nulllf then findidpair_hp t r
    else (lpf,rpf)
  | _ -> (F.nulllf,F.nulllf);;

(***** the id rule *****)
(* A simplified id rule that only deal with formulae with the same label *)
let id_f seq = 
  let F.SEQ(g,lf,rf) = seq in
  let pf = findidpair_f lf rf in
  if pf = F.nulllf then (F.NULLI,F.nulllf)
  else ((F.UINF F.empseq),pf);;

(*********************** this rule is not used yet *********************************)
(***** the id2 rule *****)
let id2 seq =
  let F.SEQ(g,lf,rf) = seq in
  let (lpf,rpf) = findidpair_hp lf rf in
  if lpf = F.nulllf then (F.NULLI,F.nulllf,F.nulllf)
  else ((F.UINF F.empseq),lpf,rpf);;
 
(***** the falseL rule *****)
let falsel seq = 
  let F.SEQ(g,lf,rf) = seq in
  let label = findf F.FALSE lf in
  if label = "-1" then (F.NULLI,F.nulllf) 
  else ((F.UINF F.empseq),F.LF(label,F.FALSE));;

(***** the trueR rule *****)
let truer seq = 
  let F.SEQ(g,lf,rf) = seq in
  let label = findf F.TRUE rf in
  if label = "-1" then (F.NULLI,F.nulllf) 
  else ((F.UINF F.empseq),F.LF(label,F.TRUE));;

(***** the mtrueR rule *****)
let mtruer seq =
  let F.SEQ(g,lf,rf) = seq in
  let label = findlf (F.LF("epsilon",F.MTRUE)) rf in 
  if label = "-1" then (F.NULLI,F.nulllf) 
  else ((F.UINF F.empseq),F.LF("epsilon",F.MTRUE));;

(* apply a subssitution [x/y] on a label l *)
let subslabel l x y =
  if y <> "epsilon" && y = l then x
  else if y = "epsilon" && x <> "epsilon" && x = l then y
  else if x = "epsilon" && y = "epsilon" then 
    failwith "subslabel: x and y are both epsilon"
  else l;;

(* Substitution [x/y] in a list of relations *)
let subsrlist l x y =
  let rec subsrl l x y acc =
    match l with
      | h::t ->
	let F.RT(s3,s4,s5) = h in 
	subsrl t x y (acc@[F.RT((subslabel s3 x y),(subslabel s4 x y),(subslabel s5 x y))])
      | _ -> acc 
  in
  subsrl l x y [];;

(* label Substitution [x/y] on a labelled formulae *)
let subsf lf x y = F.LF((subslabel (F.lb lf) x y),(F.fm lf));;

(* Substitution [x/y] in a list of labelled formulae *)
let subsflist l x y =
  let rec subsfl l x y acc =
    match l with
      | h::t -> subsfl t x y (acc@[subsf h x y])
      | _ -> acc 
  in
  subsfl l x y [];;

(* perform a list of substitutions [x/y] list on a formula lf *)
let rec subslf lf subs =
  match subs with
  | h::t -> subslf (subsf lf (fst h) (snd h)) t
  | _ -> lf;;

(* perform a list of substitutions [x/y] list on a list of formulae fl *)
let rec subslflist fl subs =
  match subs with
  | h::t -> subslflist (subsflist fl (fst h) (snd h)) t
  | _ -> fl;;

(* perform a list of substitutions [x/y] list on a label l *)
let rec subsll l subs =
  match subs with
  | h::t -> subsll (subslabel l (fst h) (snd h)) t
  | _ -> l;;

(* perform a list of substitutions [x/y] list on a list ll of labels *)
let rec subslll ll subs =
  match ll with
  | h::t -> [subsll h subs]@(subslll t subs)
  | _ -> [];;

(***** the mtrueL rule *****)
let mtruel seq =
  let F.SEQ(g,lf,rf) = seq in
  let lf0 =
    if (List.length lf) > 1 then 
      M.subtalllist (F.LF("epsilon",F.MTRUE)) lf
    else lf
  in
  let label = findf F.MTRUE lf0 in
  if label = "-1" then (F.NULLI,F.nulllf)
  else if label = "epsilon" then 
    (*failwith "mtruel: epsilon:mtrue should not be in lf0!"*)
    (F.NULLI,F.nulllf)
  else 
    let g1 = subsrlist g "epsilon" label in
    let lft =
      if (List.length lf0) > 1 then
	M.subtlist (F.LF(label,F.MTRUE)) lf0
      else lf0
    in
    let lf1 = subsflist lft "epsilon" label in
    let rf1 = subsflist rf "epsilon" label in
    ((F.UINF(F.SEQ((M.setlist g1),lf1,rf1))),F.LF(label,F.MTRUE));;

(* test if a formula with the main connective con is in the list l *)
(* return the formula if found, otherwise return nulllf *)
let rec hasform con l =
  match l with
  | h::t -> 
    begin
      match (F.fm h) with
      | F.NOT(f) -> if con = "NOT" then h else hasform con t
      | F.AND(f1,f2) -> if con = "AND" then h else hasform con t
      | F.OR(f1,f2) -> if con = "OR" then h else hasform con t
      | F.IMP(f1,f2) -> if con = "IMP" then h else hasform con t
      | F.MAND(f1,f2) -> if con = "MAND" then h else hasform con t
      | F.MIMP(f1,f2) -> if con = "MIMP" then h else hasform con t
      | F.EXISTS(x,f1) -> if con = "EXISTS" then h else hasform con t
      | F.FORALL(x,f1) -> if con = "FORALL" then h else hasform con t  
      | F.AP(F.EQ(e1,e2)) -> if con = "EQ" then h else hasform con t
      | F.AP(F.PT(_,_)) -> if con = "PT" then h else hasform con t
      (* | F.AP(F.PT2(e1,e2,e3)) -> if con = "PT2" then h else hasform con t *)
      | F.AP(F.LS(e1,e2)) -> if con = "LS" then h else hasform con t
      | F.AP(F.TR(e)) -> if con = "TR" then h else hasform con t
      | _ -> hasform con t
    end 
  | _ -> F.nulllf;;

(* find all formulae with the main connective con in the list l *)
(* return a list of formulae with the same main connective *)
let findallform con l =
  let rec findall con l acc =
    match l with
    | h::t -> 
      begin
	match (F.fm h) with
	| F.AND(f1,f2) -> 
	  if con = "AND" 
	  then findall con t (acc@[h]) else findall con t acc
	| F.IMP(f1,f2) -> 
	  if con = "IMP"
	  then findall con t (acc@[h]) else findall con t acc
	| F.MAND(f1,f2) ->
	  if con = "MAND"
	  then findall con t (acc@[h]) else findall con t acc
	| F.MIMP(f1,f2) -> 
	  if con = "MIMP"
	  then findall con t (acc@[h]) else findall con t acc
	| F.EXISTS(x,f1) -> 
	  if con = "EXISTS" 
	  then findall con t (acc@[h]) else findall con t acc
	| F.FORALL(x,f1) -> 
	  if con = "FORALL" 
	  then findall con t (acc@[h]) else findall con t acc
	| F.AP(F.EQ(e1,e2)) ->
	  if con = "EQ" 
	  then findall con t (acc@[h]) else findall con t acc
	| F.AP(F.PT(_,_)) ->
	  if con = "PT"
	  then findall con t (acc@[h]) else findall con t acc
	(* | F.AP(F.PT2(e1,e2,e3)) -> *)
	(*   if con = "PT2" *)
	(*   then findall con t (acc@[h]) else findall con t acc *)
	| F.AP(F.LS(e1,e2)) -> 
	  if con = "LS"
	  then findall con t (acc@[h]) else findall con t acc
	| F.AP(F.TR(e)) ->
	  if con = "TR" 
	  then findall con t (acc@[h]) else findall con t acc 
	| _ -> findall con t acc
      end 
    | _ -> acc
  in 
  findall con l [];;

(* find all relations in l that has w as the nth element *)
(* n can only be 1 to 3 *)
let findallrel w n l =
  let rec findall w n l acc =
    match l with
    | h::t -> 
      begin
	match h with
	| F.RT(t1,t2,t3) -> 
	  if n = 1 && w = t1 then findall w n t (acc@[h])
	  else if n = 2 && w = t2 then findall w n t (acc@[h])
	  else if n = 3 && w = t3 then findall w n t (acc@[h])
	  else findall w n t acc
	| _ -> failwith "findallrel(): not a valid relation"
      end 
    | _ -> acc
  in 
  findall w n l [];;

(* test if a ternary relation list rl contains a relation with children c1 c2 *)
let rec haschildren rl c1 c2 =
  let rl1 = findallrel c1 1 rl in
  let rl2 = findallrel c2 2 rl1 in
  if rl2 <> [] then let F.RT(s1,s2,s3) = List.hd rl2 in s3
  else 
    let rl3 = findallrel c2 1 rl in
    let rl4 = findallrel c1 2 rl3 in
    if rl4 <> [] then let F.RT(s1,s2,s3) = List.hd rl4 in s3
    else "-1";;

(* find applicable mandR or mimpL applications *)
(* given a list of mand or mimp formula, a list of relations *)
(* and a list of used (relation * labelled_form) *)
(* return a list of applicable pairs (relation * labelled_form) *)
let findallapp rule fl rl used =
  let rec mkpairl a l acc =
    match l with
    | h::t -> mkpairl a t (acc@[(h,a)])
    | _ -> acc
  in 
  let rec unused rl f used acc =
    match rl with
    | h::t -> 
      if List.mem (h,f) used then unused t f used acc 
      else unused t f used (acc@[h]) 
    | _ -> acc
  in 
  let rec findall rule fl rl used acc =
    match fl with
    | h::t -> 
      if rule = "mandr" then 
	let apprl = findallrel (F.lb h) 3 rl in
	let apprlt = unused apprl h used [] in
       	let apppairl = mkpairl h apprlt [] in
	findall rule t rl used (acc@apppairl)
      else 
	let apprl = findallrel (F.lb h) 2 rl in
	let apprlt = unused apprl h used [] in
       	let apppairl = mkpairl h apprlt [] in
	findall rule t rl used (acc@apppairl)
    | _ -> acc
  in 
  findall rule fl rl used [];;

(* Given a list of candidate apps (relation * labelled form) *)
(* For mandR or mimpL, filter out those apps that do not benefit the proof search *)
(* i.e., for (a1,a2|>a0), a0:A*B, if a1:A or a2:B is already in rf *)
(* for (a1,a0|>a2), a0:A-*B, a1:A already in rf or a2:B already in lf *)
let usefulapp rule seq appl =
  let F.SEQ(g,lf,rf) = seq in
  let rec filter rule lf rf appl acc =
    match appl with
    | h::t -> 
      let (r,pf) = h in
      let F.RT(a1,a2,a3) = r in
      if rule = "mandr" then
	let F.MAND(f1,f2) = F.fm pf in
	if (List.mem (F.LF(a1,f1)) rf) || (List.mem (F.LF(a2,f2)) rf) then 
	  filter rule lf rf t acc
	else 
	  filter rule lf rf t (acc@[h])
      else if rule = "mimpl" then
	let F.MIMP(f1,f2) = F.fm pf in
	if (List.mem (F.LF(a1,f1)) rf) || (List.mem (F.LF(a2,f2)) lf) then 
	  filter rule lf rf t acc
	else 
	  filter rule lf rf t (acc@[h])
      else failwith "filter(): Wrong rule\n"
    | _ -> acc
  in 
  filter rule lf rf appl [];;

(***** the notL rule *****)
let notl seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "NOT" lf in
  if pf = F.nulllf then (F.NULLI,pf) 
  else 
    let lf1 = M.subtlist pf lf in
    let label = F.lb pf in
    let F.NOT(f) = F.fm pf in
    (F.UINF(F.SEQ(g,lf1,([F.LF(label,f)]@rf))),pf);;

(***** the notR rule *****)
let notr seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "NOT" rf in
  if pf = F.nulllf then (F.NULLI,pf) 
  else 
    let rf1 = M.subtlist pf rf in
    let label = F.lb pf in
    let F.NOT(f) = F.fm pf in
    (F.UINF(F.SEQ(g,([F.LF(label,f)]@lf),rf1)),pf);;

(***** the andL rule *****)
let andl seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "AND" lf in
  if pf = F.nulllf then (F.NULLI,pf) 
  else 
    let lf1 = M.subtlist pf lf in
    let label = F.lb pf in
    let F.AND(f1,f2) = F.fm pf in
    (F.UINF(F.SEQ(g,([F.LF(label,f1);F.LF(label,f2)]@lf1),rf)),pf);;

(***** the andR rule *****)
let andr seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "AND" rf in
  if pf = F.nulllf then (F.NULLI,pf)
  else 
    let rf1 = M.subtlist pf rf in
    let label = F.lb pf in
    let F.AND(f1,f2) = F.fm pf in
    (F.BINF(F.SEQ(g,lf,([F.LF(label,f1)]@rf1)),F.SEQ(g,lf,([F.LF(label,f2)]@rf1))),pf);;

(***** the orL rule *****)
let orl seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "OR" lf in
  if pf = F.nulllf then (F.NULLI,pf)
  else 
    let lf1 = M.subtlist pf lf in
    let label = F.lb pf in
    let F.OR(f1,f2) = F.fm pf in
    (F.BINF(F.SEQ(g,([F.LF(label,f1)]@lf1),rf),F.SEQ(g,([F.LF(label,f2)]@lf1),rf)),pf);;

(***** the orR rule *****)
let orr seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "OR" rf in
  if pf = F.nulllf then (F.NULLI,pf) 
  else 
    let rf1 = M.subtlist pf rf in
    let label = F.lb pf in
    let F.OR(f1,f2) = F.fm pf in
    (F.UINF(F.SEQ(g,lf,([F.LF(label,f1);F.LF(label,f2)]@rf1))),pf);;

(***** the impL rule *****)
let impl seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "IMP" lf in
  if pf = F.nulllf then (F.NULLI,pf)
  else 
    let lf1 = M.subtlist pf lf in
    let label = F.lb pf in
    let F.IMP(f1,f2) = F.fm pf in
    (F.BINF(F.SEQ(g,lf1,([F.LF(label,f1)]@rf)),F.SEQ(g,([F.LF(label,f2)]@lf1),rf)),pf);;

(***** the impR rule *****)
let impr seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "IMP" rf in
  if pf = F.nulllf then (F.NULLI,pf)
  else 
    let rf1 = M.subtlist pf rf in
    let label = F.lb pf in
    let F.IMP(f1,f2) = F.fm pf in
    (F.UINF(F.SEQ(g,([F.LF(label,f1)]@lf),([F.LF(label,f2)]@rf1))),pf);;

(***** the mandL rule *****)
(* return a pair (UINF * (relation * labelled_form)) *)
let mandl seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "MAND" lf in
  if pf = F.nulllf then (F.NULLI,(F.nullr,pf))
  else 
    let lf1 = M.subtlist pf lf in 
    let label = F.lb pf in
    let F.MAND(f1,f2) = F.fm pf in
    let _ = labelnum := !labelnum+2 in
    let t = !labelnum in
    let newrel = F.RT(("a"^(string_of_int (t-1))),("a"^(string_of_int t)),label) in
    (F.UINF(F.SEQ((g@[newrel]),([F.LF(("a"^(string_of_int (t-1))),f1);F.LF(("a"^(string_of_int t)),f2)]@lf1),rf)),(newrel,pf));;

(* delete a formula f from a list of formulae fl *)
(* if fl contains more than one f, delete all *)
(* if f not in fl, return fl *)
let rec delf f fl = if List.mem f fl then delf f (M.subtlist f fl) else fl;;

(* given a list g of ternary relations, delete the commutative variants *)
let delcommv g =
  let setg = M.setlist g in
  let rec delcmv sg acc =
    match sg with
    | h::t -> 
      let F.RT(a1,a2,a3) = h in
      if List.mem (F.RT(a2,a1,a3)) t then delcmv t acc 
      else delcmv t acc@[h]
    | _ -> acc
  in 
  delcmv setg [];;

(* test if a list lfl of labelled formuale *)
(* contains a formula f *)
(* return the label of f if found, otherwise return "-1" *)
let rec containsf f lfl =
  match lfl with
  | h ::t -> if (F.fm h) = f then F.lb h else containsf f t 
  | _ -> "-1";;

(* find the world where the (unlabelled) formula f is true at *)
(* based on the the labelled formulae lfl, and relation list rl *)
(* don't consider MIMP *)
(* if found, return the label, otherwise return "-1" *)
(* also return the set of relations that is the sub tree of the label of f *)
let rec findworld f lfl rl = 
  let label = containsf f lfl in
  if label <> "-1" then (label,[])
  else 
    begin
      match f with
      | F.NOT(f1) | F.EXISTS(_,f1) | F.FORALL(_,f1) ->
	let (label1,rl1) = findworld f1 lfl rl in
	if label1 <> "-1" then (label1,rl1)
	else ("-1",rl) 
      | F.EQU(f1,f2) | F.AND(f1,f2) | F.IMP(f1,f2) | F.OR(f1,f2) -> 
	let (label1,rl1) = findworld f1 lfl rl in
	if label1 <> "-1" then (label1,rl1)
	else 
	  let (label2,rl2) = findworld f2 lfl rl in
	  if label2 <> "-1" then (label2,rl2)
	  else ("-1",rl)
      | F.MAND(f1,f2) ->
	let (label1,rl1) = findworld f1 lfl rl in
	let (label2,rl2) = findworld f2 lfl rl in
	if (label1 <> "-1") && (label2 <> "-1") then 
	  let r = haschildren rl label1 label2 in
	  if r = "-1" then
	    (*let _ = labelnum := !labelnum+1 in
	    let t = !labelnum in
	    let newlabel = "y"^(string_of_int t) in
	    (newlabel,(rl1@rl2@[F.RT(label1,label2,newlabel)]))*)
	    (* can test if label1 and label2 are disjoint *)
	    (* but this is too expensive, leave as future work *)
	    ("-1",rl)
	  else (r,(rl1@rl2@[F.RT(label1,label2,r)]))
	else ("-1",rl)
      | _ -> ("-1",rl)
    end;;
(* test if two 2lvl trees are isomorphic *)
(* i.e., have the same root and same set of leaves *)
(* epsilon leaves don't count *)
let isomorphictrees tr1 tr2 =
  let (r1,l1) = tr1 in
  let (r2,l2) = tr2 in
  let nel1 = if List.mem "epsilon" l1 then M.subtlist "epsilon" (M.setlist l1) else l1 in
  let nel2 = if List.mem "epsilon" l2 then M.subtlist "epsilon" (M.setlist l2) else l2 in
  if r1 = r2 && M.equalmultisetlist nel1 nel2 then true else false;;

(* test if a list trl of trees contain an isomorphic tree of tr *)
let rec containisotree tr trl =
    match trl with
    | h::t -> if isomorphictrees tr h then true else containisotree tr t
    | _ -> false;;

(* given a list trl of 2lvl trees, return a list of distinct trees *)
let rec distincttrees trl = 
  match trl with
  | h::t -> if containisotree h t then distincttrees t else (distincttrees t)@[h]
  | _ -> [];;

(* test if two lists of trees have a common isomorphic tree *)
let rec commontree trs1 trs2 =
  match trs1 with
  | h::t -> if containisotree h trs2 then true else commontree t trs2
  | _ -> false;;

(* given a list g of ternary relations and a label w, *)
(* test if w is the parent in more than one ternary relations *)
(* commutative variants don't count *)
(* relations with epsilon don't count *)
let multiparent g w =
  let rec parent g w acc =
    match g with
    | h::t -> 
      let F.RT(a1,a2,a3) = h in
      if a3 = w && (a1 <> "epsilon" && a2 <> "epsilon") && acc = F.nullr then parent t w h 
      else if a3 = w && (a1 <> "epsilon" && a2 <> "epsilon") && (acc = h || acc = F.RT(a2,a1,a3)) then parent t w h 
      else if a3 = w && (a1 <> "epsilon" && a2 <> "epsilon") then true
      else parent t w acc
    | _ -> false
  in 
  parent g w F.nullr;;

(* given a list l of ternary relations, scan l once *)
(* and find all (sub)trees with said root *)
(* return the list of (sub)trees, each (sub)tree is in the form *)
(* (root,leaves) *)
let rec gettree root l accl accr acct = 
  (* accl stores unused relations, accr stores leaves, acct stores 2lvl trees *)
    match l with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      if s3 = root && accr = [] && s1 <> "epsilon" && s2 <> "epsilon" then 
	let thisleaves = [s1;s2] in
	let restrel = if multiparent l s1 || multiparent l s2 then accl@[h] else accl in
	let restl = if List.mem (F.RT(s2,s1,s3)) t then M.subtlist (F.RT(s2,s1,s3)) t else t in
	gettree root restl restrel thisleaves (acct@[(root,thisleaves)])
      else if (List.mem s3 accr) && s1 <> "epsilon" && s2 <> "epsilon" then 
	let thisleaves = (M.subtlist s3 accr)@[s1;s2] in
	let restrel = if multiparent l s1 || multiparent l s2 then accl@[h] else accl in
	let restl = if List.mem (F.RT(s2,s1,s3)) t then M.subtlist (F.RT(s2,s1,s3)) t else t in 
	gettree root restl restrel thisleaves (acct@[(root,thisleaves)])
      else if s3 <> "epsilon" && s1 <> "epsilon" && s2 <> "epsilon" then 
	let restl = if List.mem (F.RT(s2,s1,s3)) t then M.subtlist (F.RT(s2,s1,s3)) t else t in
	gettree root restl (accl@[h]) accr acct 
      else 
	let restl = if List.mem (F.RT(s2,s1,s3)) t then M.subtlist (F.RT(s2,s1,s3)) t else t in
	gettree root restl accl accr acct
    | _ -> (accl,accr,acct);;
 
(* given a list l of ternary relations, return a complete tree with said root *)
(* each tree is in the form (root,leaves) *)
(* last is the set of leaves computed last time *)
(* acctree is the accumulated subtrees with the said root *)
let rec getcompletetree root l last acctree =
  let (lt,accr,acct) = gettree root l [] last [] in
  if acct = [] then (lt,(root,accr),acctree) else getcompletetree root lt accr (acctree@acct);;

(* given a list l of ternary relations, return (sub)trees with the said root *)
(* each tree is in the form (root,leaves) *)
let gettreeroot root l =
  let rec gettrees root l acc =
    let (lt,accl,acct) = getcompletetree root l [] [] in
    if List.length (snd accl) = 0 then acc else gettrees root lt (acc@acct)
  in 
  distincttrees (gettrees root (delcommv l) []);;

(* given a list l of ternary relations, return complete trees with the said root *)
(* each tree is in the form (root,leaves) *)
let getcompletetreeroot root l =
  let rec getcompletetrees root l acc =
    (*let _ = print_endline "l = ";F.print_rell l;print_endline "\n2lvl comp trees = ";F.printl2trees acc in*)
    let (lt,accl,acct) = getcompletetree root l [] [] in
    if List.length (snd accl) = 0 then acc else getcompletetrees root lt (acc@[accl])
  in 
  distincttrees (getcompletetrees root (delcommv l) []);;

(* given a tree tr and a list of trees trl, test if a tree in trl *)
(* contains the leaves in tr *)
let rec trl_hasleaves trl tr =
  match trl with
  | h::t -> if M.listsubset (snd tr) (snd h) then h else trl_hasleaves t tr
  | _ -> ("",[]);;

(* search a list of ternary relations l find ones with parent node p *)
let getternp p l =
  let rec search p l acc =
    match l with
    | h::t -> let F.RT(s1,s2,s3) = h in if s3 = p then search p t (acc@[h]) else search p t acc
    | _ -> acc 
  in 
  search p l [];;

(* generate a set of relational atoms based on g, tr and rl *)
(* rl is a set of relational atoms representing a binary tree tr on RHS *)
(* the root and leaves of tr must occur in g, internal nodes might not *)
(* return (terns,r), terns is a list of generated relations *)
(* r is the principal relation to be used in quick_mandr *)
let quickstr g tr rl =
  let rec terngen root node g tr rl =
    (* return (rl,w), rl is generated relations, w is a label that replaces node *)
    (* if node doesn't need to be replaced, w = "0" *)
    if isleave node tr then ([],"0",F.nullr)
    else 
      let ternpl = getternp node rl in
      if (List.length ternpl) <> 1 then 
	failwith "terngen(): the node is parent in multiple (or 0) ternaery relations"
      else 
	let F.RT(s1,s2,s3) = List.hd ternpl in
	let (rl1,t1,r) = terngen root s1 g tr rl in
	let (rl2,t2,r) = terngen root s2 g tr rl in
	let n1 = if t1 = "0" then s1 else t1 in
	let n2 = if t2 = "0" then s2 else t2 in
	let n3 = haschildren g n1 n2 in
	if n3 = "-1" then 
	  if node = root then ((rl1@rl2@[F.RT(n1,n2,s3)]),"0",F.RT(n1,n2,root))
	  else ((rl1@rl2@[F.RT(n1,n2,s3)]),"0",F.nullr)
	else 
	  if node = root then ((rl1@rl2),n3,F.RT(n1,n2,root))
	  else ((rl1@rl2),n3,F.nullr)
  in 
  let (terns,w,r) = (terngen (fst tr) (fst tr) g tr rl) in
  (terns,r)

(* given a list of trees, return the largest one *)
let largest_tree trl =
  let rec larger trl maxtr =
    match trl with
    | h::t ->
      if (List.length (snd h)) > (List.length (snd maxtr)) then 
	larger t h
      else larger t maxtr 
    | _ -> maxtr
  in 
  larger trl ("",[]);;

(* test if a list of relatoins rl is implied by g *)
(* root is the root in rl *)
let str_solvable root tr trsg =
  let rec solvable tr trl =
    match trl with
    | h::t -> if isomorphictrees tr h then true else solvable tr t
    | _ -> false
  in 
  if solvable tr trsg then true else false;;

(***** the quick mandR rule *****)
(* using the heuristic method to deal with structural rules *)
let quick_mandr seq usedrt =
  let rec used pf usedrt =
    match usedrt with
    | h::t -> let (r,F.LF(l,f)) = h in if pf = f then true else used pf t
    | _ -> false
  in  
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "MAND" rf in
  if pfl = [] then (F.NULLI,(F.nullr,F.nulllf))
  else 
    let rec tryquick pfl fl g =
      match pfl with
      | h::t -> 
	if used (F.fm h) usedrt then tryquick t fl g 
	else 
	  let flt = delf h fl in
	  let F.MAND(f1,f2) = F.fm h in
	  let (w1,rl1) = findworld f1 flt g in
	  let (w2,rl2) = findworld f2 flt g in
	  let root = F.lb h in
	  let rl = M.setlist (rl1@rl2@[F.RT(w1,w2,root)]) in
	  if F.invalidrell rl then tryquick t fl g
	  else 
	    let trsg = gettreeroot root g in
	    (*let _  = print_endline "The set of (sub)trees are:" in
	    let _  = F.printl2trees trsg;print_endline "" in*)
	    let tr = largest_tree (gettreeroot root rl) in
	    if str_solvable root tr trsg then 
	      let (terns,F.RT(s1,s2,s3)) = quickstr g tr rl in
	      if F.invalidrell (terns@[F.RT(s1,s2,s3)]) then tryquick t fl g
	      else (F.BINF(F.SEQ((g@terns),lf,([F.LF(s1,f1)]@rf)),F.SEQ((g@terns),lf,([F.LF(s2,f2)]@rf))),(F.RT(w1,w2,root),h))
	    else tryquick t fl g 
      | _ -> (F.NULLI,(F.nullr,F.nulllf))
    in 
    tryquick pfl (lf@rf) g;;

(* given a set g of ternary relational atoms *)
(* remove all the identity relational atoms from g *)
let rec rmid g =
  match g with
  | h::t ->
     (match h with
      | F.RT(a1,a2,a3) -> if (a1 = "epsilon" && a2 = a3) || (a2 = "epsilon" && a1 = a3) then rmid t else [h]@(rmid t)
      | _ -> failwith "rmid(): h is not a valid ternary relation")
  | _ -> [];;

(* given a root node, a set of leaves, and a set g of ternary relations *)
(* build a binary tree tr with the said root and leaves *)
(* use labels in g as internal nodes when possible *)
(* return the new set of ternary relations *)
let buildbtree root leaves g =
  let rec build thisnode root leaves g =
    match leaves with
    | h::t -> 
      let tmpnode = haschildren g thisnode h in
      if (List.length t) = 0 then (* use root as parent *)
	(g@[F.RT(thisnode,h,root)])
      else if tmpnode = "-1" then (* create this parent node *)
	let _ = labelnum := !labelnum+1 in
	let tmp = !labelnum in
	let newlabel = "x"^(string_of_int tmp) in
	let nr = F.RT(thisnode,h,newlabel) in
	build newlabel root t (g@[nr])
      else build tmpnode root t g
    | _ -> failwith "buildbtree: not supposed to come here"
  in 
  if (List.length leaves) = 0 then g
  else if (List.length leaves) = 1 then (* root is equal to the only leaf *)
    (g@[F.RT((List.hd leaves),"epsilon",root)])
  else (* invoke build *)
    build (List.hd leaves) root (List.tl leaves) g;;
(***** the quick mandR rule version 2 *****)
let quick_mandr2 seq usedrt =
  let rec used pf pr usedrt =
    match usedrt with
    | h::t -> 
      let (r,lf) = h in 
      let F.RT(a1,a2,a3) = pr in
      let F.RT(b1,b2,b3) = r in
      if pf = lf && a3 = b3 && (a1 = b1 || a1 = b2 || a2 = b1 || a2 = b2) then true
      else used pf pr t
    | _ -> false
  in  
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "MAND" rf in
  if pfl = [] then (F.NULLI,(F.nullr,F.nulllf))
  else 
    let rec tryquick pfl fl g =
      match pfl with
      | h::t -> 
	let F.MAND(f1,f2) = F.fm h in
	let (w1,rl1) = findworld f1 fl g in
	let (w2,rl2) = findworld f2 fl g in
	let root = F.lb h in
	let rl = rmid (M.setlist (rl1@rl2@[F.RT(w1,w2,root)])) in
	if w1 = "-1" || w2 = "-1" then
	  (if w1 <> "-1" then
	    let trsg = gettreeroot root g in
	    let tr1 = 
	      if rl1 = [] then (w1,[w1]) else 
		largest_tree (getcompletetreeroot w1 rl1) 
	    in
	    let tr1g = trl_hasleaves trsg tr1 in
	    if M.distinctlist (snd tr1) && tr1g <> ("",[]) && not(used h (F.RT(w1,"-1",root)) usedrt) then
	      let _ = labelnum := !labelnum+1 in
	      let t = !labelnum in
	      let newlabel = "x"^(string_of_int t) in
	      let nlleaves = M.listsetdiff (snd tr1g) (snd tr1) in
	      (* build a tree for w1 *)
	      let ng = buildbtree newlabel nlleaves g in
	      let newrl = rl1@[F.RT(w1,newlabel,root)] in
	      (F.BINF(F.SEQ((ng@newrl),lf,([F.LF(w1,f1)]@rf)),F.SEQ((ng@newrl),lf,([F.LF(newlabel,f2)]@rf))),(F.RT(w1,newlabel,root),h))
	    else tryquick t fl g
	  else if w2 <> "-1" then
	    let trsg = gettreeroot root g in
	    let tr2 = 
	      if rl2 = [] then (w2,[w2]) else 
		largest_tree (getcompletetreeroot w2 rl2) 
	    in
	    let tr2g = trl_hasleaves trsg tr2 in
	    if M.distinctlist (snd tr2) && tr2g <> ("",[]) && not(used h (F.RT("-1",w2,root)) usedrt) then
	      let _ = labelnum := !labelnum+1 in
	      let t = !labelnum in
	      let newlabel = "x"^(string_of_int t) in
	      let nlleaves = M.listsetdiff (snd tr2g) (snd tr2) in
	      (* build a tree for w2 *)
	      let ng = buildbtree newlabel nlleaves g in
	      let newrl = rl2@[F.RT(newlabel,w2,root)] in
	      (F.BINF(F.SEQ((ng@newrl),lf,([F.LF(newlabel,f1)]@rf)),F.SEQ((ng@newrl),lf,([F.LF(w2,f2)]@rf))),(F.RT(newlabel,w2,root),h))
	    else tryquick t fl g
	  else tryquick t fl g)
	(*else if (w1 = "epsilon" && w2 = root) || (w2 = "epsilon" && w1 = root) then
	  let tsetprint = print_endline "quick_mandr2 applied on an identity relation" in
	  (F.BINF(F.SEQ((g@[F.RT(w1,w2,root)]),lf,([F.LF(w1,f1)]@rf)),F.SEQ((g@[F.RT(w1,w2,root)]),lf,([F.LF(w2,f2)]@rf))),(F.RT(w1,w2,root),h))
	else if (w1 = "epsilon" && w2 <> root) || (w2 = "epsilon" && w1 <> root) then             let testprint = print_endline ("w1 = "^w1^"\nw2 = "^w2^"\nroot = "^root) in             failwith "tryquick(): (w1,w2|>root) is identity relational atom, but structural rules with substitutions haven't been applied yet." *)
	else (* apply quick_mandr *)
	  let trsg = gettreeroot root g in
	  let tr = largest_tree (gettreeroot root rl) in
	  if str_solvable root tr trsg then 
	    (*let testprint = print_endline "tr = ";F.printl2tree tr;print_endline "trsg = ";F.printl2trees trsg;print_endline "\nrl = ";F.print_rell rl;print_endline ("\nw1 = "^w1^"\nw2 = "^w2^"\n");print_endline "rl1 = ";F.print_rell rl1;print_endline "\nrl2 = ";F.print_rell rl2;print_endline "g = ";F.print_rell g;print_endline ("root = "^root^"\n") in*)
	    (let (terns,F.RT(s1,s2,s3)) = quickstr g tr rl in
	    if F.invalidrell (terns@[F.RT(s1,s2,s3)]) then tryquick t fl g
	    else if used h (F.RT(w1,w2,root)) usedrt then tryquick t fl g
	    else (F.BINF(F.SEQ((g@terns),lf,([F.LF(s1,f1)]@rf)),F.SEQ((g@terns),lf,([F.LF(s2,f2)]@rf))),(F.RT(w1,w2,root),h)))
	  else tryquick t fl g
      | _ -> (F.NULLI,(F.nullr,F.nulllf))
    in 
    tryquick pfl lf g;;

(* print a list of rule applications *)
let rec print_appl appl =
  let print_app app = print_string "(";F.print_rel (fst app);print_string ",";F.print_lf (snd app);print_string ")" in
  match appl with
  | h::t -> print_app h;print_string " ";print_appl t 
  | _ -> ();;
    
(***** the mandR rule *****)
(* usedrt is a list of (relation * labelled_form) which is a history record *)
(* to avoid applying the rule on the same formula and relation *)
(* return a pair (BINF * (relation * labelled_form)) *)
let mandr seq usedrt = 
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "MAND" rf in
  if pfl = [] then (F.NULLI,(F.nullr,F.nulllf))
  else (* usefulapp may not be necessary, since findallapp already filters off used apps *)
    let apppairl = usefulapp "mandr" seq (findallapp "mandr" pfl g usedrt) in
    if List.length apppairl > 0 then 
      let fstapp = List.hd apppairl in
      let (F.RT(t1,t2,t3),F.LF(l,F.MAND(f1,f2))) = fstapp in
      let rf1 = M.subtlist (F.LF(l,F.MAND(f1,f2))) rf in
      if t3 = l then (F.BINF(F.SEQ(g,lf,([F.LF(t1,f1)]@rf1@[F.LF(l,F.MAND(f1,f2))])),F.SEQ(g,lf,([F.LF(t2,f2)]@rf1@[F.LF(l,F.MAND(f1,f2))]))),fstapp)
      else failwith "mandr(): t3 and l do not match"
    else (F.NULLI,(F.nullr,F.nulllf));;

(***** the quick mimpl rule *****)
(* if there is (h1,h2|>h0), h1:A, h2:A-*B in antecedent *)
(* then add h0:B in the antecedent *)
let quick_mimpl seq usedrt =
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "MIMP" lf in
  let rec used r pf usedrt =
    match usedrt with
    | h::t -> 
      let (r1,f1) = h in
      if r = r1 && pf = f1 then true else used r pf t 
    | _ -> false
  in 
  let rec findapp pf parents g lfl usedrt =
    match parents with
    | h::t -> 
      let sib = otherdirchd g h (F.lb pf) in
      let F.MIMP(f1,f2) = F.fm pf in
      if (List.mem (F.LF(sib,f1)) lfl) && not(List.mem (F.LF(h,f2)) lfl) && not(used (F.RT(sib,(F.lb pf),h)) pf usedrt) then 
	((F.LF(h,f2)),(F.RT(sib,(F.lb pf),h)))
      else findapp pf t g lfl usedrt
    | _ -> (F.nulllf,F.nullr)
  in 
  let rec tryquick pfl lfl g usedrf = 
    match pfl with
    | h::t -> 
      let parents = getparent g (F.lb h) in
      let (nf,pr) = findapp h parents g lfl usedrt in
      if nf = F.nulllf then tryquick t lfl g usedrt
      else
	let lf1 = M.subtlist h lf in
	(F.UINF(F.SEQ(g,([nf]@lf1@[h]),rf)),(pr,h,nf))
    | _ -> (F.NULLI,(F.nullr,F.nulllf,F.nulllf))
  in 
  tryquick pfl lf g usedrt;;

(***** the mimpL rule *****)
(* usedrt is a list of (relation * labelled_form) which is a history record *)
(* to avoid applying the rule on the same formula and relation *)
(* return a pair (BINF * (relation * labelled_form)) *)
let mimpl seq usedrt = 
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "MIMP" lf in
  if pfl = [] then (F.NULLI,(F.nullr,F.nulllf))
  else (* usefulapp may not be necessary, since findallapp already filters off used apps *)
    let apppairl = usefulapp "mimpl" seq (findallapp "mimpl" pfl g usedrt) in
    if List.length apppairl > 0 then
      let fstapp = List.hd apppairl in
      let (F.RT(t1,t2,t3),F.LF(l,F.MIMP(f1,f2))) = fstapp in
      let lf1 = M.subtlist (F.LF(l,F.MIMP(f1,f2))) lf in
      if t2 = l then (F.BINF(F.SEQ(g,lf1@[F.LF(l,F.MIMP(f1,f2))],([F.LF(t1,f1)]@rf)),F.SEQ(g,([F.LF(t3,f2)]@lf1@[F.LF(l,F.MIMP(f1,f2))]),rf)),fstapp)
      else failwith "mimpl(): t2 and l do not match"
    else (F.NULLI,(F.nullr,F.nulllf));;

(* check if a singleton heap is valid according to rf *)
(* pt is an unlablled points-to formula for the singleton heap *)
let rec validsh pt rf =
  match rf with
  | h::t -> 
    (match pt with
    | F.AP(F.PT(e1,_)) ->
    (* | F.AP(F.PT2(e1,_,_)) ->  *)
      (match F.fm h with
      | F.AP(F.EQ(e2,e3)) -> 
	if (e2 = e1 && e3 = "nil") || (e3 = e1 && e2 = "nil") then true 
	else validsh pt t
      | _ -> validsh pt t)
    | _ -> failwith "validsh: pt is not a points-to formula!")
  | _ -> false;;

(***** the H rule *****)
(* take two expressions e1, e2, and a sequent seq as parameters *)
(* return a new sequent with l:e1|->e2 in the antecedent, l is fresh *)
(* also return the created formula *)
let mkshp e1 e2 seq =
  let F.SEQ(g,lf,rf) = seq in
  if validsh (F.AP(F.PT(e1,[e2]))) rf then
    let _ = labelnum := !labelnum+1 in
    let n = !labelnum in
    let nl = "a"^(string_of_int n) in
    let nf = F.LF(nl,F.AP(F.PT(e1,[e2]))) in
    (F.SEQ(g,lf@[nf],rf),nf)
  else (* not sure if e1 is a valid address, don't apply H *)
    (F.SEQ([],[],[]),F.nulllf);;

(* given a list lfl of labelled formulae, return n expressions *)
(* that are distinct and fresh *)
(* assume the expresions in lfl are all in the form exxx *)
let rec freshexps n =
  if n > 0 then 
    let _ = expnum := !expnum+1 in
    let thisnum = !expnum in
    ["v"^(string_of_int thisnum)]@(freshexps (n-1))
  else [];;

(* create n normal fresh labels *)
(* these labels start with a *)
let freshlabels n =
  let _ = labelnum := !labelnum+n in
  let last = !labelnum in
  let rec mklb num lastnum = 
    if num > 0 then (mklb (num-1) (lastnum-1))@["a"^(string_of_int lastnum)]
    else []
  in 
  mklb n last;;

(***** the HE rule *****)
(* take a label l and a sequent seq as parameters *)
(* l must occur in seq *)
(* return the sequent, the new formula, and the new relation *)
let exthp l seq =
  if F.oldlabelseq l seq then
    let F.SEQ(g,lf,rf) = seq in
    (* let _ = labelnum := !labelnum+2 in *)
    (* let n = !labelnum in *)
    (* let nl1 = "a"^(string_of_int (n-1)) in *)
    (* let nl2 = "a"^(string_of_int n) in *)
    let [nl1;nl2] = freshlabels 2 in
    let nr = F.RT(l,nl1,nl2) in
    let [ne1] = freshexps 1 in
    let nf = F.LF(nl1,F.AP(F.PT(ne1,[ne1]))) in
    (F.SEQ((g@[nr]),(lf@[nf]),rf),nf,nr)
  else failwith "exthp: l doesn't occur in seq!";;

(* test if a label l is for a singleton heap in seq *)
let issingleton l seq =
  let F.SEQ(g,lf,rf) = seq in
  haspointer (labelledform l lf);;
  
(***** the HC rule *****)
(* take two labels l1, l2 and a sequent seq as parameters *)
(* l1, l2 must occur in seq *)
(* return a pair of sequents and the new parent label *)
(* in the form ((seq1,seq2),l) *)
let combhps l1 l2 seq =
  if (F.oldlabelseq l1 seq) && (F.oldlabelseq l2 seq) then 
    let F.SEQ(g,lf,rf) = seq in
    let l1sig = issingleton l1 seq in
    let l2sig = issingleton l2 seq in
    let [ne1;ne2;ne3] = freshexps 3 in
    let nf1 = F.AP(F.PT(ne1,[ne2])) in
    let nf2 = F.AP(F.PT(ne1,[ne3])) in
    (if l1sig && l2sig then
      let [nl1] = freshlabels 1 in
      let nr1 = F.RT(l1,l2,nl1) in
      (((F.SEQ(g,(lf@[F.LF(l1,nf1);F.LF(l2,nf2)]),rf)),(F.SEQ((g@[nr1]),lf,rf))),nl1)
    else if l1sig then
      let [nl1;nl2;nl3] = freshlabels 3 in
      let nr1 = F.RT(nl1,nl2,l2) in
      let nr2 = F.RT(l1,l2,nl3) in
      (((F.SEQ((g@[nr1]),(lf@[F.LF(l1,nf1);F.LF(nl1,nf2)]),rf)),(F.SEQ((g@[nr2]),lf,rf))),nl3)
    else if l2sig then
      let [nl1;nl2;nl3] = freshlabels 3 in
      let nr1 = F.RT(nl1,nl2,l1) in
      let nr2 = F.RT(l1,l2,nl3) in
      (((F.SEQ((g@[nr1]),(lf@[F.LF(nl1,nf1);F.LF(l2,nf2)]),rf)),(F.SEQ((g@[nr2]),lf,rf))),nl3)
    else 
      let [nl1;nl2;nl3;nl4;nl5] = freshlabels 5 in
      let nr1 = F.RT(nl1,nl2,l1) in
      let nr2 = F.RT(nl3,nl4,l2) in
      let nr3 = F.RT(l1,l2,nl5) in
      (((F.SEQ((g@[nr1;nr2]),(lf@[F.LF(nl1,nf1);F.LF(nl3,nf2)]),rf)),(F.SEQ((g@[nr3]),lf,rf))),nl5))
  else failwith "combhps: l1 or l2 doesn't occur in seq!";;

(* given a set g of ternary relations and two labels l1, l2 *)
(* test if l1 < l2 in the descending chain in g *)
let lowerdc l1 l2 g =
  let rec lower l ll lastll g =
    if ll = lastll then false 
    else 
      if List.mem l ll then true
      else lower l (List.flatten (List.map (dirchd g) ll)) ll g
  in
  lower l1 [l2] [] g;;

(* given a list g of ternary relations, return the parent of l1 and l2 *)
(* if no parent of l1 and l2 is found, return "-1" *)
let rec getcomb g l1 l2 =
  match g with
  | h::t -> 
    let F.RT(a1,a2,a3) = h in
    if (a1 = l1 && a2 = l2) || (a1 = l2 && a2 = l1) then a3
    else getcomb t l1 l2 
  | _ -> "-1";;
    
(* given a list g of ternary relations g, *)
(* a list of candidate labels hccndl *)
(* and applied pairs applied *)
(* return the next pair to be applied on HC *)
(* don't select pairs l1,l2 if (1) l1 < l2 or l2 < l1 *)
(* (2) l1,l2|>l3, for some l3 in g *)
(* (3) l1,l2 is applied on HC already *)
let randhcapp g hccndl applied =
  let allpairs = M.cartesian [hccndl;hccndl] in
  let incompatible g applied l1 l2 =
    let l1allchd = allchd g l1 in
    let l2allchd = allchd g l2 in
    let rec chkincmp applied l1 l2chd =
      match l2chd with
      | h::t -> 
	if List.mem (l1,h) applied || List.mem (h,l1) applied then true 
	else chkincmp applied l1 t
      | _ -> false
    in
    let rec chkincmp2 applied l1chd l2chd =
      match l1chd with
      | h::t -> if chkincmp applied h l2chd then true else chkincmp2 applied t l2chd
      | _ -> false
    in 
    if chkincmp2 applied (l1allchd@[l1]) (l2allchd@[l2]) then true
    else false
  in 
  let rec findallhcapp g ll applied =
    match ll with
    | h::t -> 
      let [l1;l2] = h in 
      if (getcomb g l1 l2) <> "-1" || (l1 = l2) then 
	findallhcapp g t applied
      else if (lowerdc l1 l2 g) || (lowerdc l2 l1 g) then 
	findallhcapp g t applied
      else if l1 = "epsilon" || l2 = "epsilon" then 
	findallhcapp g t applied
      else if incompatible g applied l1 l2 then 
	findallhcapp g t applied
      else [(l1,l2)]@(findallhcapp g t applied)
    | _ -> []
  in
  let allcand = findallhcapp g allpairs applied in
  let candnum = List.length allcand in
  if candnum  <= 0 then ("-1","-1")
  else (* randomly choose a pair of labels *)
    let randnum = Random.int candnum in 
    List.nth allcand randnum;;

(* given a list hccnd of (F.LF,[label]), a formula f, and a label l *)
(* where f occurs in hccnd, insert l to the list of labels for f *)
(* f should only occur in hccnd ONCE *)
(* l should be distinct from any labels for f *)
let addlhccnd hccnd f l =
  let rec add hccnd f l before =
    match hccnd with
    | h::t -> 
      let (f1,ll) = h in 
      if f1 = f then (before@[(f1,(ll@[l]))]@t)
      else add t f l (before@[h])
    | _ -> failwith "addlhcnd: f doesn't occur in hccnd!"
  in 
  add hccnd f l [];;

(* check if HC has been applied on labels for the -*L formula *)
(* i.e., marked with F.nullr2 *)
let rec hcapplied mf uml =
  match uml with
  | h::t -> 
    let (r,f) = h in 
    if f = mf && r = F.nullr2 then true else hcapplied mf t
  | _ -> false;;

(* get the set of useful candidates for HC *)
(* hccnd is a list of (F.LF,[labels]) *)
(* i.e., those -*L formulae that are not marked with F.nullr2 *)
let rec filterhccnd hccnd uml =
  match hccnd with
  | h::t -> 
    if hcapplied (fst h) uml then filterhccnd t uml else [h]@(filterhccnd t uml)
  | _ -> [];;

(* find all points-to subformulae of f *)
let rec pointersubf f =
  match f with
  | F.AP(F.PT(_,_)) -> [f]
  (* | F.AP(F.PT2(_,_,_)) -> [f] *)
  | F.TRUE
  | F.FALSE
  | F.MTRUE
  | F.AP(F.EQ(_,_))
  | F.AP(F.LS(_,_))
  | F.AP(F.TR(_)) -> []
  | F.FORALL (_,f1)
  | F.EXISTS (_,f1)
  | F.NOT f1 -> pointersubf f1
  | F.EQU(f1,f2) 
  | F.IMP(f1,f2)
  | F.OR(f1,f2)
  | F.AND(f1,f2)
  | F.MAND(f1,f2)
  | F.MIMP(f1,f2) -> (pointersubf f1)@(pointersubf f2)
  | _ -> failwith "pointersubf: not a valid SL formula!";;

(* given a labelled formula lf, and a list lfl of labelled formulae *)
(*return a list of labels for the |-> subformuale of lf *)
let psubflabels lf lfl =
  let psubfs = pointersubf (F.fm lf) in
  let rec getlabel f lfl =
    match lfl with
    | h::t -> if (F.fm h) = f then (F.lb h) else getlabel f t
    | _ -> "-1"
  in 
  let rec getlabels fl lfl =
    match fl with
    | h::t -> 
      let label = getlabel h lfl in 
      if label = "-1" then getlabels t lfl 
      else (getlabels t lfl)@[label] 
    | _ -> []
  in 
  getlabels psubfs lfl;;

(* check if an unlabelled formula f is in *)
(* a list fl of labelled formulae *)
(* return the labelled formula if found, otherwise return F.nulllf *)
let rec findulform f fl =
  match fl with
  | h::t -> if (F.fm h) = f then h else findulform f t 
  | _ -> F.nulllf;;

(* apply H, HE according to a -* formula *)
(* do not create all necessary heaps, since it's too expensive *)
(* return (F.INF, pf, nfl) where pf is the -*L formula *)
(* nfl is the list of created formulae *)
let restrictedhe seq usedrt =
  (* (F.nullr,f) in usedrt means H,HE have been *)
  (* applied to f *)
  let rec applied f usedrt =
    match usedrt with
    | h::t -> 
      let (r,f1) = h in 
      if f = f1 && r = F.nullr then true
      else applied f t
    | _ -> false
  in
  let rec unapplied fl usedrt =
    match fl with 
    | h::t -> if applied h usedrt then unapplied t usedrt else h
    | _ -> F.nulllf 
  in
  (* apply HE based on mf, extend the heap for mf *) 
  (* with ONLY max(|A|,|B|)/2+1 new addresses *)
  (* where A-*B = mf *)
  let rec applyhe seq l num acc =
    if num > 0 then
      let (nseq,nf,nr) = exthp l seq in
      let F.RT(l1,l2,l3) = nr in
      applyhe nseq l3 (num-1) (acc@[nf])
    else (seq,acc)
  in 
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "MIMP" lf in
  let pf = unapplied pfl usedrt in
  if pf = F.nulllf then (F.NULLI,F.nulllf,[])
  else (* apply HE to pf *)
    let F.MIMP(f1,f2) = (F.fm pf) in
    (* extsize can be changed to more if you like *)
    (* but Calcagno's results no longer hold for FOSL *)
    (* so it won't be complete anyway *)
    let extsize = (max (F.sizeform f1) (F.sizeform f2))/2 + 1  in
    let (nseq,nfl) = applyhe seq (F.lb pf) extsize [] in
    (* remember to add (F.nullr,pf) to usedrt in the calling function *)
    (F.UINF(nseq),pf,nfl);;

(***** the mimpR rule *****)
(* return a pair (UINF * (relation * labelled_form)) *)
let mimpr seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "MIMP" rf in
  if pf = F.nulllf then (F.NULLI,(F.nullr,pf))
  else 
    let rf1 = M.subtlist pf rf in 
    let label = F.lb pf in
    let F.MIMP(f1,f2) = F.fm pf in
    let _ = labelnum := !labelnum+2 in
    let t = !labelnum in
    let newrel = F.RT(("a"^(string_of_int (t-1))),label,("a"^(string_of_int t))) in
    (F.UINF(F.SEQ((g@[newrel]),([F.LF(("a"^(string_of_int (t-1))),f1)]@lf),([F.LF(("a"^(string_of_int t)),f2)]@rf1))),(newrel,pf));;

(* Find all the eq-relations of the form *)
(* (x,epsilon |> y) or (epsilon,x |> y) from a list l of relations *)
(* return a list of relations *)
let findeqrl l =
  let rec findall l acc = 
    match l with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      if ((s1 = "epsilon") && (s2 <> s3)) || ((s2 = "epsilon") && (s1 <> s3)) 
      then findall t (acc@[h]) else findall t acc 
    | _ -> acc
  in 
  findall l [];;

(* find all relations of the form (x,y |> epsilon) from a list l of relations *)
(* return a list of relations *)
let findiurl l =
  let rec findall l acc =
    match l with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      if (s1 <> "epsilon") && (s2 <> "epsilon") && (s3 = "epsilon")
      then findall t (acc@[h]) else findall t acc
    | _ -> acc
  in 
  findall l [];;

(* find all relations of the form (x,x |> y) from a list l of relations *)
(* return a list of relations *)
let finddjrl l =
  let rec findall l acc =
    match l with
    | h::t ->
      let F.RT(s1,s2,s3) = h in
      if (s1 = s2) && (s1 <> "epsilon") (*&& (s1 <> s3) && (s3 <> "epsilon")*)
      then findall t (acc@[h]) else findall t acc
    | _ -> acc
  in 
  findall l [];;

(* merge two lists of substitutions (x,y) *)
(* delete duplication substitutions *)
(* including (a,b) and (b,a) *)
let mergesubs subs1 subs2 =
  let rec merge subs1 subs2 acc =
    match subs1 with
    | h::t -> 
      let (x,y) = h in
      if (List.mem (x,y) subs2) || (List.mem (y,x) subs2) then 
	merge t subs2 acc
      else merge t subs2 (acc@[h])
    | _ -> subs2@acc
  in 
  merge subs1 subs2 [];;

(* get a list of substitutions (x,y) list from a list of relations *)
(* in the form (x,epsilon |> y) or (epsilon,x |> y) or (x,y |> epsilon) *)
(* return a list of substitutions (x,y), meaning [x/y] *)
let getsubsl rl =
  let rec getsubs rl acc =
    match rl with
    | h::t ->
      let F.RT(s1,s2,s3) = h in
      if s1 = "epsilon" && s2 <> s3 then getsubs t (mergesubs [(s2,s3)] acc)
      else if s2 = "epsilon" && s1 <> s3 then getsubs t (mergesubs [(s1,s3)] acc)
      else if s3 = "epsilon" && s1 <> "epsilon" && s2 <> "epsilon" then 
	if s1 = s2 then getsubs t (mergesubs [("epsilon",s1)] acc)
	else getsubs t (mergesubs [("epsilon",s1);("epsilon",s2)] acc)
      else failwith "getsubs(): not eq-relation nor iu-relation\n"
    | _ -> acc 
  in 
  getsubs rl [];;

(* get a list of substitutions (x,y) list from a list of relations *)
(* in the form (x,x |> y) *)
(* return a list of substitutions (x,y), meaning [x/y] *)
let getsubsdj rl =
  let rec getsubs rl acc =
    match rl with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      getsubs t (mergesubs [("epsilon",s1)] acc)
    | _ -> acc
  in 
  getsubs rl [];;

(* for partiality rule *)
(* find all pairs of relations of the form *)
(* (a,b|>c);(a,b|>d) from a list l of relations *)
(* return a list of substitutions (x,y), meaning [x/y] *)
let getpsubs rl vb =
  let rec findppairs r rl acc =
    match rl with
    | h::t -> 
      let F.RT(s1,s2,s3) = r in
      let F.RT(t1,t2,t3) = h in
      if (s1 = t1 && s2 = t2 && s3 <> t3) || (s1 = t2 && s2 = t1 && s3 <> t3) then 
	if List.mem (s3,t3) acc || List.mem (t3,s3) acc then
	  findppairs r t acc
	else 
	  let _ =
	    if vb = "-v" then 
	      (print_string "Patial rel pair is: ";print_rpairl [(r,h)];print_endline "") 
	    else ()
	  in  
	  findppairs r t (acc@[(s3,t3)])
      else findppairs r t acc
    | _ -> acc
  in 
  let rec findallppairs rl1 rl2 acc =
    match rl1 with
    | h::t -> 
      let subs = findppairs h rl2 [] in
      findallppairs t rl2 (mergesubs subs acc)
    | _ -> acc
  in 
  findallppairs rl rl [];;

(* for cancellativity rule *)
(* find all pairs of relations of the form *)
(* (a,b|>c);(a,d|>c) from a list l of relations *)
(* return a list of substitutions (x,y), meaning [x/y] *)
let getcsubs rl vb =
  let rec findcpairs r rl acc =
    match rl with
    | h::t -> 
      let F.RT(s1,s2,s3) = r in
      let F.RT(t1,t2,t3) = h in
      if (s1 = t1 && s3 = t3 && s2 <> t2)  then 
	if List.mem (s2,t2) acc || List.mem (t2,s2) acc then
	  findcpairs r t acc
	else 
	  let _ =
	    if vb = "-v" then
	      (print_string "Cancel rel pair is: ";print_rpairl [(r,h)];print_endline "") 
	    else ()
	  in
	  findcpairs r t (acc@[(s2,t2)])
      else if (s1 = t2 && s3 = t3 && s2 <> t1) then 
	if List.mem (s2,t1) acc || List.mem (t1,s2) acc then
	  findcpairs r t acc
	else 
	  let _ =
	    if vb = "-v" then
	      (print_string "Cancel rel pair is: ";print_rpairl [(r,h)];print_endline "") 
	    else ()
	  in
	  findcpairs r t (acc@[(s2,t1)])
      else if (s2 = t1 && s3 = t3 && s1 <> t2) then
	if List.mem (s1,t2) acc || List.mem (t2,s1) acc then
	  findcpairs r t acc
	else 
	  let _ =
	    if vb = "-v" then
	      (print_string "Cancel rel pair is: ";print_rpairl [(r,h)];print_endline "") 
	    else ()
	  in
	  findcpairs r t (acc@[(s1,t2)])
      else if (s2 = t2 && s3 = t3 && s1 <> t1) then 
	if List.mem (s1,t1) acc || List.mem (t1,s1) acc then
	  findcpairs r t acc
	else 
	  let _ =
	    if vb = "-v" then
	      (print_string "Cancel rel pair is: ";print_rpairl [(r,h)];print_endline "") 
	    else ()
	  in
	  findcpairs r t (acc@[(s1,t1)])
      else findcpairs r t acc
    | _ -> acc
  in 
  let rec findallcpairs rl1 rl2 acc =
    match rl1 with
    | h::t -> 
      let subs = findcpairs h rl2 [] in
      findallcpairs t rl2 (mergesubs subs acc)
    | _ -> acc
  in 
  findallcpairs rl rl [];;

(* globally substitute [x/y] on the sequent seq *)
let subsseq seq x y =
  let F.SEQ(g,lf,rf) = seq in
  if y <> "epsilon" then
    let ng = subsrlist g x y in
    let nlf = subsflist lf x y in
    let nrf = subsflist rf x y in
    (F.SEQ(ng,nlf,nrf))
  else if x <> "epsilon" then
    let ng = subsrlist g y x in
    let nlf = subsflist lf y x in
    let nrf = subsflist rf y x in
    (F.SEQ(ng,nlf,nrf))
  else failwith "subsseq(): both x and y are epsilon in [x/y]\n";;

(* gloably perform a list of substitutions sl = (x,y) list on the sequent seq *)
let rec subslseq seq sl =
  match sl with
  | h::t -> let (x,y) = h in subslseq (subsseq seq x y) t
  | _ -> seq;;     

(* compute the eq-closure of g in seq *)
(* global substitution is performed when needed *)
(* return a sequent that is eq-closed *)
(* also return the list of substitutions (x,y) list *)
(* to recover the unsat core *)
let eqclosure seq vb =
  let rec recsub seq accsubs =
    let F.SEQ(g,lf,rf) = seq in
    let g0 = M.setlist g in
    let eqrl = findeqrl g0 in
    let eqsubs = getsubsl eqrl in
    let _ = 
      if vb = "-v" then
	if eqsubs = [] then () else print_endline "Applied Eq\n" 
      else ()
    in 
    let F.SEQ(g1,lf1,rf1) = subslseq (F.SEQ(g0,lf,rf)) eqsubs in
    let g01 = M.setlist g1 in
    let iurl = findiurl g01 in
    let iusubs = getsubsl iurl in
    let _ =
      if vb = "-v" then
	if iusubs = [] then () else print_endline "Applied IU\n" 
      else ()
    in 
    let F.SEQ(g2,lf2,rf2) = subslseq (F.SEQ(g01,lf1,rf1)) iusubs in
    let g02 = M.setlist g2 in
    let djrl = finddjrl g02 in
    let djsubs = getsubsdj djrl in
    let _ = 
      if vb = "-v" then 
	if djsubs = [] then () else print_endline "Applied D\n" 
      else ()
    in 
    let F.SEQ(g3,lf3,rf3) = subslseq (F.SEQ(g02,lf2,rf2)) djsubs in
    let g03 = M.setlist g3 in
    let psubs = getpsubs g03 vb in
    let _ = 
      if vb = "-v" then
	if psubs = [] then () else print_endline "Applied P\n" 
      else ()
    in 
    let F.SEQ(g4,lf4,rf4) = subslseq (F.SEQ(g03,lf3,rf3)) psubs in
    let g04 = M.setlist g4 in
    let csubs = getcsubs g04 vb in
    let _ = 
      if vb = "-v" then
	if csubs = [] then () else print_endline "Applied C\n" 
      else ()
    in 
    let F.SEQ(g5,lf5,rf5) = subslseq (F.SEQ(g04,lf4,rf4)) csubs in
    let seqf = F.SEQ((M.setlist g5),lf5,rf5) in
    if (eqsubs@iusubs@djsubs@psubs@csubs) = [] then 
      (seqf,accsubs)
    else recsub seqf (accsubs@eqsubs@iusubs@djsubs@psubs@csubs)
  in 
  recsub seq [];;

(* make identity relations based on a list of labels *)
let mkid l =
  let rec makeid l acc =
    match l with
    | h::t -> makeid t (acc@[F.RT("epsilon",h,h)])
    | _ -> acc
  in 
  makeid l [];;

(* g with the rule U applied on every label *)
let idrel g =
  let labels = getrllabels g in
  let idrl = mkid labels in
  M.setlist (g@idrl);;

(***** the u rule *****)
(* this rule generates all identity relatins for each label *)
let unit seq =
  let F.SEQ(g,lf,rf) = seq in
  let labels = getseqlabels seq in
  let idrl = mkid labels in
  F.UINF(F.SEQ((g@idrl),lf,rf));;
    
(* find the commutative variants of relations in g *)
(* return a list of relations that are not in g *)
let commvar g =
  let rec cvar l g acc =
    match l with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      let cv = F.RT(s2,s1,s3) in
      if List.mem cv g then cvar t g acc 
      else cvar t g (acc@[cv])
    | _ -> acc
  in 
  cvar g g [];;

(***** the e rule *****)
(* this rule generates all commutative variants of relations in g *)
let comm seq =
  let F.SEQ(g,lf,rf) = seq in
  F.UINF(F.SEQ((M.setlist (g@(commvar g))),lf,rf));;

(* find pairs of relations from g that are applicable for assoc *)
(* assume disjointness in the semantics *)
(* do not allow the ternary relations to have epsilons *)
let assocpairs g =
  let containsunit r = 
    let F.RT(t1,t2,t3) = r in 
    if t1 = "epsilon" || t2 = "epsilon" || t3 = "epsilon" then true else false
  in 
  let applicable r1 r2 g =
    let F.RT(s1,s2,s3) = r1 in
    let F.RT(t1,t2,t3) = r2 in
    let rec searchg t1 t2 s2 s3 l g =
      match l with
      | h::t -> 
	let F.RT(a1,a2,a3) = h in
	if a1 = t1 && a3 = s3 then 
	  if (List.mem (F.RT(s2,t2,a2)) g) || (List.mem (F.RT(t2,s2,a2)) g) then true
	  else searchg t1 t2 s2 s3 t g
	else if a2 = t1 && a3 = s3 then
	  if (List.mem (F.RT(s2,t2,a1)) g) || (List.mem (F.RT(t2,s2,a1)) g) then true
	  else searchg t1 t2 s2 s3 t g
	else searchg t1 t2 s2 s3 t g
      | _ -> false
    in
    if containsunit r1 || containsunit r2 then false 
    else if searchg t1 t2 s2 s3 g g then false else true 
  in 
  let rec apppairs r rl g acc =
    match rl with
    | h::t -> 
      if applicable r h g then apppairs r t g (acc@[(r,h)]) 
      else apppairs r t g acc
    | _ -> acc
  in 
  let rec getpairs l g acc =
    match l with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      let children = findallrel s1 3 g in
      if children = [] then getpairs t g acc 
       else getpairs t g (acc@(apppairs h children g []))
    | _ -> acc
  in 
  getpairs g g [];;

(***** the assoc rule *****)
(* the rule generates all assoc pairs in g *)
let assoc seq =
  let F.SEQ(g,lf,rf) = seq in
  let apppairs = assocpairs g in
  let rec mkpairs pairs acc =
    match pairs with
    | h::t -> 
      let (F.RT(s1,s2,s3),F.RT(t1,t2,t3)) = h in 
      let _ = labelnum := !labelnum+1 in
      let n = !labelnum in
      mkpairs t (acc@[F.RT(t1,("a"^(string_of_int n)),s3);F.RT(s2,t2,("a"^(string_of_int n)))])
    | _ -> acc
  in 
  F.UINF(F.SEQ((M.setlist (g@(mkpairs apppairs []))),lf,rf));;

(* find the pair of assoc app such that *)
(* the root of this pair is the lowest in all apps *)
let lowestassocapp pairs g =
  let rec findlapp pairs g lapp =
    match pairs with
    | h::t -> 
      let (F.RT(s1,s2,s3),F.RT(t1,t2,t3)) = h in
      if lapp = (F.nullr,F.nullr) then findlapp t g h
      else 
	let (F.RT(a1,a2,a3),F.RT(b1,b2,b3)) = lapp in
	if labelh g a3 > labelh g s3 then findlapp t g h
	else findlapp t g lapp
    | _ -> lapp
  in 
  findlapp pairs g (F.nullr,F.nullr);;

(* find the pair of assoc app such that *)
(* the root has the largest index *)
let lowestassocapp_index pairs =
  let rec findlapp pairs lapp =
    match pairs with
    | h::t -> 
      let (F.RT(s1,s2,s3),F.RT(t1,t2,t3)) = h in
      if lapp = (F.nullr,F.nullr) then findlapp t h
      else 
	let (F.RT(a1,a2,a3),F.RT(b1,b2,b3)) = lapp in
	if (F.getnum s3) > (F.getnum a3) then findlapp t h
	else findlapp t lapp
    | _ -> lapp
  in 
  findlapp pairs (F.nullr,F.nullr);;

(* find the pair of assoc app such that *)
(* the root has the smallest index *)
let highestassocapp_index pairs =
  let rec findlapp pairs happ =
    match pairs with
    | h::t -> 
      let (F.RT(s1,s2,s3),F.RT(t1,t2,t3)) = h in
      if happ = (F.nullr,F.nullr) then findlapp t h
      else 
	let (F.RT(a1,a2,a3),F.RT(b1,b2,b3)) = happ in
	if (F.getnum s3) < (F.getnum a3) then findlapp t h
	else findlapp t happ
    | _ -> happ
  in 
  findlapp pairs (F.nullr,F.nullr);;

(***** the quick assoc rule *****)
(* the rule generates a pair of new relations *)
(* always apply on the pair with highest root *)
let assoc_quick seq =
  let F.SEQ(g,lf,rf) = seq in
  (* let testprint = print_endline "assoc_quick: computing apppairs" in *)
  let apppairs = assocpairs g in
  (* let testprint = print_endline "assoc_quick: finished computing apppairs" in *)
  if List.length apppairs > 0 then
    (* let testprint = print_endline "assoc_quick: computing highstapp" in *)
    let highestapp = highestassocapp_index apppairs in
    (* let testprint = print_endline "assoc_quick: finished computing highestapp" in *)
    let (F.RT(s1,s2,s3),F.RT(t1,t2,t3)) = highestapp in
    let _ = labelnum := !labelnum+1 in
    let n = !labelnum in
    let nrl = [F.RT(t1,("a"^(string_of_int n)),s3);F.RT(s2,t2,("a"^(string_of_int n)))] in
    F.UINF(F.SEQ((g@nrl),lf,rf))
  else F.NULLI;;

(* test if two relational atoms are commutative variants *)
let comvrels r1 r2 =
  let F.RT(s1,s2,s3) = r1 in
  let F.RT(t1,t2,t3) = r2 in
  if (s3 = t3) && (((s1 = t1) && (s2 = t2)) || ((s1 = t2) && (s2 = t1))) then
    true 
  else false;;

(* test if two relational atoms are cancellative variants *)
let cancvrels r1 r2 =
  let F.RT(s1,s2,s3) = r1 in
  let F.RT(t1,t2,t3) = r2 in
  if (s3 = t3) && ((s1 = t1) || (s1 = t2) || (s2 = t1) || (s2 = t2)) then 
    true
  else false;;

(* find applicable pairs of relational atoms for cross-split *)
(* assume Cancellativity and Partiality in the semantics *) 
(* do not allow s1 = t1 or s1 = t2 *)
(* or s2 = t1 or s2 = t2 *)
(* also, if the two relations have a common complete 2lvl tree, *)
(* then do not apply CS on them *)
let cspairs g =
  (* given two lists of 2lvl trees, return a list of their possible combined leaves *)
  let rec combinedleaves trs1 trs2 acc =
    let rec combineleaves tr trs acc =
      match trs with
      | h::t -> 
	let (r1,l1) = tr in 
	let (r2,l2) = h in
	combineleaves tr t acc@[M.setlist (l1@l2)]
      | _ -> acc 
    in 
    match trs1 with
    | h::t -> combinedleaves t trs2 acc@(combineleaves h trs2 [])
    | _ -> M.setlist acc
  in 
  (* test if r1 and r2 have a common complete 2lvl tree in g *)
  let rec applicable g r1 r2 =
    let F.RT(s1,s2,s3) = r1 in
    let F.RT(t1,t2,t3) = r2 in
    let cptrss1 = (getcompletetreeroot s1 g)@[(s1,[s1])] in
    let cptrss2 = (getcompletetreeroot s2 g)@[(s2,[s2])] in
    let cptrst1 = (getcompletetreeroot t1 g)@[(t1,[t1])] in
    let cptrst2 = (getcompletetreeroot t2 g)@[(t2,[t2])] in
    let cl1 = combinedleaves cptrss1 cptrss2 [] in
    let cl2 = combinedleaves cptrst1 cptrst2 [] in
    if M.commonsetlists cl1 cl2 then false
    else true
  in
  let rec pair og r g acc =
    match g with
    | h::t -> 
      let F.RT(s1,s2,s3) = r in
      let F.RT(t1,t2,t3) = h in
      if (s3 = t3) && s1 <> t1 && s1 <> t2 && s2 <> t1 && s2 <> t2 && s3 <> "epsilon" && s1 <> "epsilon" && s2 <> "epsilon" && t1 <> "epsilon" && t2 <> "epsilon" then
	(if applicable og r h then pair og r t (acc@[(r,h)])
	 else pair og r t acc)
      else pair og r t acc 
    | _ -> acc
  in 
  let rec getpairs og g acc =
    match g with
    | h::t -> getpairs og t (acc@(pair og h g []))
    | _ -> acc
  in 
  let rec containpair p ps =
    match ps with
    | h::t -> 
      let (F.RT(a1,a2,a3),F.RT(b1,b2,b3)) = p in
      let (F.RT(c1,c2,c3),F.RT(d1,d2,d3)) = h in
      if a3 = c3 && ((a1 = c1 && a2 = c2) || (a1 = c2 && a2 = c1)) && b3 = d3 && ((b1 = d1 && b2 = d2) || (b1 = d2 && b2 = d1)) then 
	true
      else if a3 = d3 && ((a1 = d1 && a2 = d2) || (a1 = d2 && a2 = d1)) && b3 = c3 && ((b1 = c1 && b2 = c2) || (b1 = c2 && b2 = c1)) then
	true
      else containpair p t 
    | _ -> false
  in 
  let rec simppairs apppairs =
    match apppairs with
    | h::t -> if containpair h t then simppairs t else [h]@(simppairs t)
    | _ -> []
  in 
  simppairs (getpairs g g []);; 

(* given a list of CS application pairs apppiars, and a list g of ternary relations *)
(* return the application pair such that the root is the lowest *) 
(* of all apppairs roots in the descending chain in g *)
let lowestcsapp apppairs g =
  let rec findlapp apppairs g lapp =
    match apppairs with
    | h::t -> 
      let (F.RT(a1,a2,a3),F.RT(b1,b2,b3)) = h in 
      if lapp = (F.nullr,F.nullr) then findlapp t g h
      else 
	let (F.RT(c1,c2,c3),F.RT(d1,d2,d3)) = lapp in
	if labelh g c3 > labelh g a3 then findlapp t g h
	else findlapp t g lapp
    | _ -> lapp
  in 
  findlapp apppairs g (F.nullr,F.nullr);;

(***** the CS rule *****)
let cs seq = 
  let F.SEQ(g,lf,rf) = seq in
  let apppairs = cspairs (delcommv g) in
  if List.length apppairs > 0 then 
    let (F.RT(s1,s2,s3),F.RT(t1,t2,t3)) = lowestcsapp apppairs g in
    let _ = labelnum := !labelnum + 4 in
    let n = !labelnum in
    let l1 = "a"^(string_of_int (n-3)) in
    let l2 = "a"^(string_of_int (n-2)) in
    let l3 = "a"^(string_of_int (n-1)) in
    let l4 = "a"^(string_of_int (n)) in
    let nr1 = F.RT(l1,l2,s1) in
    let nr2 = F.RT(l1,l3,t1) in
    let nr3 = F.RT(l3,l4,s2) in
    let nr4 = F.RT(l2,l4,t2) in
    let ng = g@[nr1;nr2;nr3;nr4] in
    F.UINF(F.SEQ(ng,lf,rf))
  else F.NULLI;;

(* get a list of binded variables in a list of formulae *)
let getvarsfl lfl =
  let rec findvars lfl vars =
    match lfl with
    | h::t -> findvars t (vars@(F.getvars (F.fm h)))
    | _ -> vars
  in 
  M.setlist (findvars lfl []);;

(* get a list of binded variables in a sequent *)
let getvarsseq seq =
  let F.SEQ(g,lf,rf) = seq in
  M.setlist ((getvarsfl lf)@(getvarsfl rf));;

(***** the exists L rule *****)
(* return a pair (UINF * labelled_form) *)
let existsl seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "EXISTS" lf in
  if pf = F.nulllf then (F.NULLI,("",pf))
  else 
    let lf1 = M.subtlist pf lf in
    let _ = expnum := !expnum+1 in
    let newv = "v"^(string_of_int (!expnum)) in
    let F.EXISTS(x,f) = F.fm pf in 
    let newf = F.LF((F.lb pf),(F.subsexpf f newv x)) in
    (F.UINF(F.SEQ(g,([newf]@lf1),rf)),(newv,pf));;

(* find all the expressions/values in a list of labelled formulae fl *)
let rec findexplfl lfl =
  match lfl with
  | h::t -> (F.findexpf (F.fm h))@(findexplfl t)
  | _ -> [];;

(* find all binded variables in a list of labelled formulae fl *)
let findvarslfl fl =
  let rec findv fl acc =
    match fl with
    | h::t -> findv t (acc@(F.getvars (F.fm h)))
    | _ -> acc
  in 
  M.setlist (findv fl []);;

(* find all binded variables in a sequent seq *)
let findvarsseq seq =
  let F.SEQ(g,lf,rf) = seq in
  M.setlist ((findvarslfl lf)@(findvarslfl rf));;

(* find all the expressions/values in a sequent seq *)
let findexpseq seq =
  let F.SEQ(g,lf,rf) = seq in
  let expvars = M.setlist ((findexplfl lf)@(findexplfl rf)) in
  let vars = M.setlist ((findvarslfl lf)@(findvarslfl rf)) in
  let rec filter ev v acc =
    match ev with
    | h::t -> if List.mem h v then filter t v acc else filter t v (acc@[h])
    | _ -> acc
  in 
  filter expvars vars [];;

(* find applicable existsR applications *)
(* given a list of exists formula, a list of values/expressions, *)
(* and a list of used (exp/value * labelled_form) *)
(* return a list of applicable pairs (exp/value * labelled_form) *)
let findallqtapp fl el used =
  let rec mkpairl a l acc =
    match l with
    | h::t -> mkpairl a t (acc@[(h,a)])
    | _ -> acc
  in
  let rec unused el f used acc =
    match el with
    | h::t -> 
      if List.mem (h,f) used then unused t f used acc 
      else unused t f used (acc@[h]) 
    | _ -> acc
  in
  let rec findall fl el used acc =
    match fl with
    | h::t -> 
      let appel = unused el h used [] in
      let apppairl = mkpairl h appel [] in
      findall t el used (acc@apppairl)
    | _ -> acc
  in 
  findall fl el used [];;

(***** the exists R rule 1 *****)
(* usedef is a list of (exp/value * labelled_form) which is a history record *)
(* to avoid applying the rule on the same expression/value and formula *)
(* return a pair (UINF * (exp/value * labelled_form)), where exp/value is string *)
let existsr1 seq usedef =
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "EXISTS" rf in
  if pfl = [] then (F.NULLI,("",F.nulllf))
  else 
    let expl = findexpseq seq in 
    let apppairl = findallqtapp pfl expl usedef in
    if List.length apppairl > 0 then
      let fstapp = List.hd apppairl in
      let (e,pf) = fstapp in
      let F.LF(l,F.EXISTS(x,f)) = pf in
      let newf = F.subsexpf f e x in 
      let rf1 = M.subtlist pf rf in
      (F.UINF(F.SEQ(g,lf,[F.LF(l,newf)]@rf1@[pf])),(e,pf))
    else 
      (F.NULLI,("",F.nulllf));;

(***** the exists R rule 2 *****)
(* when existsr1 fails, this rule acts like exists l *)
(* to create a new value/expression *)
(* apply to a random exists formula on the RHS *)
(* return a pair (UINF * (exp/value * labelled_form)), where exp/value is string *)
let existsr2 seq =
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "EXISTS" rf in
  if pfl = [] then (F.NULLI,("",F.nulllf))
  else
    let pf = M.rand_listmem pfl in
    let _ = expnum := !expnum+1 in
    let newv = "v"^(string_of_int (!expnum)) in
    let rf1 = M.subtlist pf rf in
    let F.EXISTS(x,f) = F.fm pf in 
    let newf = F.LF((F.lb pf),(F.subsexpf f newv x)) in
    (F.UINF(F.SEQ(g,lf,([newf]@rf1@[pf]))),(newv,pf));;

(***** the forall L rule 1 *****)
(* usedef is a list of (exp/value * labelled_form) which is a history record *)
(* to avoid applying the rule on the same expression/value and formula *)
(* return a pair (UINF * (exp/value * labelled_form)), where exp/value is string *)
let foralll1 seq usedef =
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "FORALL" lf in
  if pfl = [] then (F.NULLI,("",F.nulllf))
  else 
    let expl = findexpseq seq in 
    let apppairl = findallqtapp pfl expl usedef in
    if List.length apppairl > 0 then
      let fstapp = List.hd apppairl in
      let (e,pf) = fstapp in
      let F.LF(l,F.FORALL(x,f)) = pf in
      let newf = F.subsexpf f e x in 
      let lf1 = M.subtlist pf lf in
      (F.UINF(F.SEQ(g,[F.LF(l,newf)]@lf1@[pf],rf)),(e,pf))
    else 
      (F.NULLI,("",F.nulllf));;

(***** the forall L rule 2 *****)
(* when foralll1 fails, this rule acts like forall r *)
(* to create a new value/expression *)
(* apply to a random forall formula on the LHS *)
(* return a pair (UINF * (exp/value * labelled_form)), where exp/value is string *)
let foralll2 seq =
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "FORALL" lf in
  if pfl = [] then (F.NULLI,("",F.nulllf))
  else
    let pf = M.rand_listmem pfl in
    let _ = expnum := !expnum+1 in
    let newv = "v"^(string_of_int (!expnum)) in
    let lf1 = M.subtlist pf lf in
    let F.FORALL(x,f) = F.fm pf in 
    let newf = F.LF((F.lb pf),(F.subsexpf f newv x)) in
    (F.UINF(F.SEQ(g,[newf]@lf1@[pf],rf)),(newv,pf));;

(***** the forall R rule *****)
(* return a pair (UINF * labelled_form) *)
let forallr seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "FORALL" rf in
  if pf = F.nulllf then (F.NULLI,("",pf))
  else 
    let rf1 = M.subtlist pf rf in
    let _ = expnum := !expnum+1 in
    let newv = "v"^(string_of_int (!expnum)) in
    let F.FORALL(x,f) = F.fm pf in 
    let newf = F.LF((F.lb pf),(F.subsexpf f newv x)) in
    (F.UINF(F.SEQ(g,lf,[newf]@rf1)),(newv,pf));;

(* perform exp/value substitution [e1/e2] on a sequent *)
let subsexpseq seq e1 e2 =
  let F.SEQ(g,lf,rf) = seq in
  F.SEQ(g,(F.subsexpfl lf e1 e2),(F.subsexpfl rf e1 e2));;

(* perform a list of exp/value substitutions subsl on a sequent *)
let rec subsexplseq seq subsl =
  match subsl with
  | h::t -> let (e1,e2) = h in subsexplseq (subsexpseq seq e1 e2) t
  | _ -> seq;;

(* get a list of exp/value substitutions from a list of equality atomic formulae eql *)
let rec getexpsubs eql =
  match eql with
  | h::t -> 
    let F.LF(_,F.AP(F.EQ(e1,e2))) = h in 
    if isvar e1 || isvar e2 then 
      failwith "getexpsubs(): one of the exp/value being substituted is a variable"
    else [(e1,e2)]@(getexpsubs t)
  | _ -> [];;
      
(* delete the trivial equality atomic formulae in a list of formulae fl *)
let deltrivialeqaf fl =
  let rec del fl acc =
    match fl with
    | h::t -> 
      (match F.fm h with
       | F.AP(F.EQ(e1,e2)) ->
	  if e1 = e2 then
	    del t acc
	  else del t (acc@[h]) 
      | _ -> del t (acc@[h]))
    | _ -> acc
  in 
  let f1f = del fl [] in
  if (List.length f1f) = 0 then
    [F.LF("a0",F.TRUE)]
  else f1f;;

(***** equalityL rule *****)
(* note that we restrict to only deal with e1 = e2 where nont of them are variables *)
(* we assume that if the equality atomic formula appears by itself, *)
(* it must contain no variables *)
(* return a sequent, a list of substitutions involved, and the principal formulae *)
let equalityl seq = 
  let F.SEQ(g,lf,rf) = seq in
  let eql = findallform "EQ" (deltrivialeqaf lf) in
  let expsubs = getexpsubs eql in
  if invalidexpsubl expsubs then (seq,[("1","2")],eql)
  else 
    let F.SEQ(gt,lft,rft) = subsexplseq seq expsubs in 
    let nseq = F.SEQ(gt,(deltrivialeqaf lft),rft) in
    (nseq,expsubs,eql);;

(* test if an equality atomic formula is trivial *)
let trivialeqaf eqaf = let F.AP(F.EQ(e1,e2)) = eqaf in if e1 = e2 then true else false;;

(* test if a list of equality atomic formulae contains trivial equality *) 
let rec hastrivialeqaf eqafl =
  match eqafl with
  | h::t -> if trivialeqaf (F.fm h) then h else hastrivialeqaf t
  | _ -> F.nulllf;;

(***** equalityR rule *****)
let equalityr seq =
  let F.SEQ(g,lf,rf) = seq in
  let eql = findallform "EQ" rf in
  let eqaf = hastrivialeqaf eql in
  if eqaf = F.nulllf then (F.NULLI,F.nulllf)
  else ((F.UINF F.empseq),eqaf);;

(* find a list of expression pairs (e1,e2) for cut= rule *)
(* e1 = e2 or e2 = e1 can't be in RHS *)
let findcuteqapps exps rf =
  let rec find1 e1 exps rf =
    match exps with
    | h::t -> 
      if e1 = "nil" && h = "nil" then find1 e1 t rf
      else 
	let f1 = findulform (F.AP(F.EQ(e1,h))) rf in
	let f2 = findulform (F.AP(F.EQ(h,e1))) rf in
	if f1 = F.nulllf && f2 = F.nulllf then
	  [(e1,h)]@(find1 e1 t rf)
	else find1 e1 t rf
    | _ -> []
  in 
  let rec find2 exps rf =
    match exps with
    | h::t -> (find1 h t rf)@(find2 t rf)
    | _ -> []
  in 
  find2 exps rf;;

(***** the cut= rule *****)
(* return the binary inf, the expression subs on the left premise *)
(* and the created formula on the right premise *)
let cuteq seq =
  let F.SEQ(g,lf,rf) = seq in
  let allexps = M.setlist ((findexplfl (lf@rf))@["nil"]) in
  if List.length allexps <= 1 then (* nil is the only expression *)
    (F.NULLI,[],F.nulllf)
  else (* randomly choose two expressions to apply the rule *)
    let epairl = findcuteqapps allexps rf in
    if List.length epairl = 0 then (F.NULLI,[],F.nulllf)
    else 
      let (e1,e2) = M.rand_listmem epairl in
      let alllabels = getseqlabels seq in
      let randlabel = M.rand_listmem alllabels in
      let rpf = F.LF(randlabel,F.AP(F.EQ(e1,e2))) in
      let nseq2 = F.SEQ(g,lf,(rf@[rpf])) in
      if invalidexpsub (e1,e2) then
	(F.BINF(seq,nseq2),[(e1,e2)],rpf)
      else 
	let nseq1 = subsexplseq seq [(e1,e2)] in
	(F.BINF(nseq1,nseq2),[(e1,e2)],rpf);;
    
(*********************************************************************)
(*********** The following rules are for points-to predicate *********)
(*********************************************************************)
(*********************************************************************)

(* test if a pointsto atomic formula is labelled by epsilon *)
let badpointer lf = 
  match F.fm lf with
  | F.AP(F.PT(_,_)) -> if (F.lb lf) = "epsilon" then true else false
  (* | F.AP(F.PT2(_,_,_)) -> if (F.lb lf) = "epsilon" then true else false *)
  | _ -> false;;

(* test if a list of formulae contains a bad pointer *)
(* i.e., a pointsto atomic formula which is laeblled by epsilon *)
let rec hasbadpointer lfl =
  match lfl with
  | h::t -> if badpointer h then h else hasbadpointer t
  | _ -> F.nulllf;;

(***** pointstoL1 rule *****)
let pointstol1 seq =
  let F.SEQ(g,lf,rf) = seq in
  let badpt = hasbadpointer lf in
  if badpt = F.nulllf then (F.NULLI,F.nulllf)
  else ((F.UINF F.empseq),badpt);;

(* test if an atomic pointsto formula is labelled by a non-singleton heap h *)
(* g is a list of relational atoms *)
(* i.e., there is some (h1,h2|>h) *)
let rec comppointer lf g =
  match g with
  | h::t -> 
    let F.RT(l1,l2,l3) = h in 
    if (l3 = (F.lb lf)) && (l1 <> "epsilon") && (l2 <> "epsilon") then h 
    else comppointer lf t
  | _ -> F.nullr;;

(* test if a list of labelled formulae contains an atomic pointsto formula *)
(* labelled by a non-singleton heap *)
(* return the formula and the relational atom if found *)
let rec hascomppointer lfl g =
  match lfl with
  | h::t -> let r = comppointer h g in if r = F.nullr then hascomppointer t g else (r,h)
  | _ -> (F.nullr,F.nulllf);;

(***** pointstoL2 rule *****)
let pointstol2 seq =
  let F.SEQ(g,lf,rf) = seq in
  let ptl = (findallform "PT" lf) in
  let apppair = hascomppointer ptl g in
  if apppair = (F.nullr,F.nulllf) then (F.NULLI,(F.nullr,F.nulllf))
  else 
    let (r,pf) = apppair in
    let F.RT(l1,l2,l3) = r in
    let g1 = M.setlist(subsrlist g "epsilon" l1) in
    let lf1 = subsflist lf "epsilon" l1 in
    let rf1 = subsflist rf "epsilon" l1 in
    let g2 = M.setlist(subsrlist g "epsilon" l2) in
    let lf2 = subsflist lf "epsilon" l2 in
    let rf2 = subsflist rf "epsilon" l2 in
    ((F.BINF((F.SEQ(g1,lf1,rf1)),(F.SEQ(g2,lf2,rf2)))),(r,pf));;


(* given a set g of ternary relations, test if two labels w1, w2 *)
(* are siblings in a ternary relation *)
let rec siblings g w1 w2 =
  match g with
  | h::t -> let F.RT(a1,a2,a3) = h in if (a1 = w1 && a2 = w2) || (a1 = w2 && a2 = w1) then true else siblings t w1 w2
  | _ -> false;;  

(* test if two labelled formulae are diff pointers with the same address *)
(* i.e., h1:e1 |-> _ and h2:e1 |-> _ *)
(* and h1, h2 are siblings in a ternary relation *)
let sameaddrpointer g lf1 lf2 =
  match lf1 with 
  | F.LF(h1,F.AP(F.PT(e1,_))) ->
  (* | F.LF(h1,F.AP(F.PT2(e1,_,_))) -> *)
    (match lf2 with
    | F.LF(h2,F.AP(F.PT(e4,_))) ->
    (* | F.LF(h2,F.AP(F.PT2(e4,_,_))) -> *)
      if (siblings g h1 h2) && (e1 = e4) then true else false
    | _ -> false)
  | _ -> false;;

(* find two formulae with different labels that are the same pointer *)
(* in a list of formulae lf *)
(* assume that lf are all atomic pointsto formulae to save search space *)
let rec findinconspointer g lf =
  let rec find f lf =
    match lf with
    | h::t -> if sameaddrpointer g f h then (f,h) else find f t
    | _ -> (F.nulllf,F.nulllf)
  in 
  match lf with
  | h::t -> 
    let (f1,f2) = find h t in 
    if (f1,f2) = (F.nulllf,F.nulllf) then 
      findinconspointer g t 
    else (f1,f2)
  | _ -> (F.nulllf,F.nulllf);;

(***** pointstoL3 rule *****)
let pointstol3 seq =
  let F.SEQ(g,lf,rf) = seq in
  (*let ptl = (findallform "PT" lf)@(findallform "PT2" lf) in*)
  let (pf1,pf2) = findinconspointer g lf in
  if (F.nulllf,F.nulllf) = (pf1,pf2) then (F.NULLI,[])
  else ((F.UINF F.empseq),[pf1;pf2]);;

(* given two fields fl1 and fl2, fine their differences *)
(* that is, return a list of expression subs (e1,e2) list *)
(* that can unify them *)
let rec fielddiff fl1 fl2 =
  match fl1 with
  | h1::t1 ->
    (match fl2 with
    | h2::t2 ->
      if h1 = h2 then fielddiff t1 t2 else (fielddiff t1 t2)@[(h1,h2)]
    | _ -> [])
  | _ -> [];;

(* test if two pointers are labelled by the same heap *)
(* but have different expressions *)
(* return the list of exp subs if they have the same label *)
(* otherwise return [] *)
let sameheap lf1 lf2 =
  match lf1 with
  | F.LF(h1,F.AP(F.PT(e1,fl1))) ->
    (match lf2 with
    | F.LF(h2,F.AP(F.PT(e2,fl2))) ->
      if h1 = h2 then fielddiff ([e1]@fl1) ([e2]@fl2)
      else []
    | _ -> [])
  | _ -> [];;

(* test if a list of labelled formulae lfl contains *)
(* two pointers labelled by the same heap but with differnt expressions *)
(* return [] if false, otherwise return the list of exp subs *)
let rec findsameheap lfl =
  let rec find f fl =
    match fl with
    | h::t -> 
      let expsubs = sameheap f h in
      if expsubs = [] then find f t else (expsubs,f,h)
    | _ -> ([],F.nulllf,F.nulllf)
  in 
  match lfl with
  | h::t -> 
    let (expsubs,f1,f2) = find h t in 
    if expsubs = [] then findsameheap t
    else (expsubs,f1,f2)
  | _ -> ([],F.nulllf,F.nulllf);;

(***** pointstoL4 rule *****)
let pointstol4 seq =
  let F.SEQ(g,lf,rf) = seq in
  (*let ptl = (findallform "PT" lf)@(findallform "PT2" lf) in*)
  let (expsubs,pf1,pf2) = findsameheap lf in
  if expsubs = [] then (seq,[],[])
  else 
    if invalidexpsubl expsubs then (seq,[("1","2")],[pf1;pf2])
    else 
      let F.SEQ(gt,lft,rft) = subsexplseq seq expsubs in
      let nseq = F.SEQ(gt,(deltrivialeqaf lft),rft) in
      (nseq,expsubs,[pf1;pf2]);;

(* test if two singleton heaps are the same pointer *)
(* i.e., the addresses are the same, the fields of one include the other *)
(* but with differnt labels *)
let samepointer lf1 lf2 =
  match lf1 with
  | F.LF(h1,F.AP(F.PT(e1,fl1))) ->
    (match lf2 with
    | F.LF(h2,F.AP(F.PT(e2,fl2))) -> 
      if h1 <> h2 && (e1 = e2) && ((fieldinc fl1 fl2) || (fieldinc fl2 fl1)) then
	true
      else false
    | _ -> false)
  | _ -> false;; 

(* test if a list of labelled formulae lfl contains *)
(* two identical pointers with different labels  *)
(* assume lfl only contains atomic pointsto formulae *)
let rec findsamepointer lfl =
  let rec find f fl =
    match fl with
    | h::t -> if samepointer f h then (f,h) else find f t
    | _ -> (F.nulllf,F.nulllf)
  in 
  match lfl with
  | h::t -> 
    let (f1,f2) = find h t in
    if (f1,f2) = (F.nulllf,F.nulllf) then findsamepointer t
    else (f1,f2)
  | _ -> (F.nulllf,F.nulllf);;

(***** pointstoL5 rule *****)
let pointstol5 seq =
  let F.SEQ(g,lf,rf) = seq in
  (*let ptl = (findallform "PT" lf)@(findallform "PT2" lf) in*)
  let (pf1,pf2) = findsamepointer lf in
  if (F.nulllf,F.nulllf) = (pf1,pf2) then (seq,[],[])
  else 
    match pf1 with 
    | F.LF(h1,F.AP(F.PT(e1,fl1))) ->
      (match pf2 with
      | F.LF(h2,F.AP(F.PT(e2,fl2))) ->
	let nseq = subsseq seq h1 h2 in
	(nseq,[(h1,h2)],[pf1;pf2])
      | _ -> failwith "pointstol5(): pf2 and pf1 don't match")
    | _ -> failwith "pointstol5(): pf1 not a valid pointsto formula";;

(* test if a pointsto atomic formula has address nil *)
let nilpointer lf =
  match F.fm lf with
  | F.AP(F.PT(e1,_)) -> if e1 = "nil" then true else false
  | _ -> false;;

(* test if a list of formulae contains a nil pointer *)
let rec hasnilpointer lfl =
  match lfl with
  | h::t -> if nilpointer h then h else hasnilpointer t
  | _ -> F.nulllf;;

(***** pointstonil rule *****)
let pointstonil seq =
  let F.SEQ(g,lf,rf) = seq in
  let nilpt = hasnilpointer lf in 
  if nilpt = F.nulllf then (F.NULLI,F.nulllf)
  else ((F.UINF F.empseq),nilpt);;

(* test if a labelled formula lf is a pointer with address e *)
let ptbyaddr lf e =
  match F.fm lf with
  | F.AP(F.PT(e1,_)) -> if e1 = e then true else false
  | _ -> false;;

(* test if a list lfl of labelled formuale contains *)
(* a pointer with address e *)
let rec hasptbyaddr lfl e =
  match lfl with
  | h::t -> if ptbyaddr h e then h else hasptbyaddr t e
  | _ -> F.nulllf;;    

(*********************************************************************)
(*********** The following rules are for data structures *************)
(*********** such as singly linked list and binary tree **************)
(*********************************************************************)

(* test if a sll formula is labelled by epsilon *)
let badsll lf =
  match F.fm lf with
  | F.AP(F.LS(_,_)) -> if (F.lb lf) = "epsilon" then true else false
  | _ -> false;;

(* test if a list of formulae contains a bad singly linked list *)
let rec hasbadsll lfl =
  match lfl with
  | h::t -> if badsll h then h else hasbadsll t
  | _ -> F.nulllf;;

(* test if a formula is an empty list *)
(* i.e., of the form epsilon:ls(e,e) *)
let isemptyls lf =
  match F.fm lf with
  | F.AP(F.LS(e1,e2)) -> if (F.lb lf) = "epsilon" && e1 = e2 then true else false
  | _ -> false;;

(* delete empty ls formula of the form epsilon:ls(e,e) *)
(* from a list lfl of labelled formulae *)
let rec delemptyls lfl =
  match lfl with
  | h::t -> if isemptyls h then delemptyls t else [h]@(delemptyls t)
  | _ -> [];;
    
(***** LS1 rule *****)
(* return the unary inf, the list of exp subs, and the principal formula *)
let slinkedlist1 seq =
  let F.SEQ(g,lf,rf) = seq in
  let lft = delemptyls lf in
  let pf = hasbadsll lft in
  if pf = F.nulllf then (F.NULLI,[],F.nulllf)
  else 
    let F.LF(label,F.AP(F.LS(e1,e2))) = pf in
    let expsubs = [(e1,e2)] in
    if invalidexpsubl expsubs then (F.UINF(seq),[("1","2")],pf)
    else     
      let F.SEQ(gf,lff,rff) = subsexplseq (F.SEQ(g,lft,rf)) expsubs in
      let nseq = F.SEQ(gf,(delemptyls lff),rff) in
      (F.UINF(nseq),expsubs,pf);;

(* test if a list of formulae contains an empty singly linked list *)
let rec hasemptyls lfl =
  match lfl with
  | h::t -> if isemptyls h then h else hasemptyls t
  | _ -> F.nulllf;;

(***** LS2 rule *****)
(* return the unary inf, and principal formula *)
let slinkedlist2 seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasemptyls rf in
  if pf = F.nulllf then (F.NULLI,F.nulllf)
  else ((F.UINF F.empseq),pf);;

(* test if a labelled formula is empty list but not labelled by epsilon *)
let isempnels lf =
  match F.fm lf with
  | F.AP(F.LS(e1,e2)) -> if (F.lb lf) <> "epsilon" && e1 = e2 then true else false 
  | _ -> false;;

(* test if a list of formulae contains an empty list *)
(* but not labelled by epsilon *)
(* return the formula if found, otherwise return F.nulllr *)
let rec hasempnels lfl =
  match lfl with
  | h::t -> if isempnels h then h else hasempnels t 
  | _ -> F.nulllf;;

(***** LS3 rule *****)
let slinkedlist3 seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasempnels lf in
  if pf = F.nulllf then (F.NULLI,F.nulllf)
  else 
    let nlf = M.subtlist pf lf in
    (F.UINF(F.SEQ(g,(nlf@[F.LF((F.lb pf),F.MTRUE)]),rf)),pf);;

(* test if a formula is a list starts with nil *)
let nilsll lf =
  match F.fm lf with
  | F.AP(F.LS(e1,e2)) -> if e1 <> e2 && e1 = "nil" then true else false
  | _ -> false;;

(* test if a list of formulae contains a list that starts with nil *)
let rec hasnilsll lfl =
  match lfl with
  | h::t -> if nilsll h then h else hasnilsll t
  | _ -> F.nulllf;;

(***** LS4 rule *****)
let slinkedlist4 seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasnilsll lf in
  if pf = F.nulllf then (F.NULLI,[],F.nulllf)
  else 
    let F.LF(label,F.AP(F.LS(e1,e2))) = pf in
    let expsubs = [(e1,e2)] in
    if invalidexpsubl expsubs then (F.UINF(seq),[("1","2")],pf)
    else 
      let lf1 = (M.subtlist pf lf)@[F.LF(label,F.MTRUE)] in
      let F.SEQ(gt,lft,rft) = subsexplseq (F.SEQ(g,lf1,rf)) expsubs in
      let nseq = F.SEQ(gt,(M.setlist lft),rft) in
      (F.UINF(nseq),expsubs,pf);;

(* test if two labelled formulae are the same sll *)
(* but with different labels *)
let samesll lf1 lf2 =
  match lf1 with
  | F.LF(label1,F.AP(F.LS(e1,e2))) ->
    (match lf2 with
    | F.LF(label2,F.AP(F.LS(e3,e4))) -> 
      if label1 <> label2 && e1 = e3 && e2 = e4 then true
      else false
    | _ -> false)
  | _ -> false;;

(* given a list of labelled formulae lfl *)
(* find the pair of labelled formulae that have different labels *)
(* but are the same sll *)
let rec findsamesll lfl =
  let rec find f fl =
    match fl with
    | h::t -> if samesll f h then (f,h) else find f t
    | _ -> (F.nulllf,F.nulllf)
  in 
  match lfl with
  | h::t -> 
    let (f1,f2) = find h t in
    if (f1,f2) = (F.nulllf,F.nulllf) then findsamesll t
    else (f1,f2)
  | _ -> (F.nulllf,F.nulllf);;

(* (\***** LS5 rule *****\) *)
(* (\* return the binary inf, the list of label subs, *\) *)
(* (\* the list of exp subs, and the list of principal formulae *\) *)
(* let slinkedlist5 seq = *)
(*   let F.SEQ(g,lf,rf) = seq in *)
(*   let (pf1,pf2) = findsamesll lf in *)
(*   if (F.nulllf,F.nulllf) = (pf1,pf2) then (F.NULLI,[],[],[]) *)
(*   else (\* e1 = e3 and e2 = e4 *\) *)
(*     let F.LF(label1,F.AP(F.LS(e1,e2))) = pf1 in *)
(*     let F.LF(label2,F.AP(F.LS(e3,e4))) = pf2 in *)
(*     let expsubs = [(e1,e2)] in *)
(*     let lsubs = [(label1,label2)] in *)
(*     let lft = M.subtalllist pf2 (M.subtalllist pf1 lf) in *)
(*     let lft2 = lft@[F.LF(label1,F.MTRUE);F.LF(label2,F.MTRUE)] in *)
(*     let nseq2 = subslseq seq lsubs in *)
(*     if invalidexpsubl expsubs then *)
(*       (F.BINF(seq,nseq2),[("1","2")],lsubs,[pf1;pf2]) *)
(*     else  *)
(*       let nseq1 = subsexplseq (F.SEQ(g,lft2,rf)) expsubs in *)
(*       (F.BINF(nseq1,nseq2),expsubs,lsubs,[pf1;pf2]);; *)

(* test if two labelled formulae have the same label *)
(* but are two different sll *)
let sameldiffsll lf1 lf2 =
  match lf1 with
  | F.LF(label1,F.AP(F.LS(e1,e2))) ->
    (match lf2 with
    | F.LF(label2,F.AP(F.LS(e3,e4))) ->
      if label1 = label2 && (e1 <> e3 || e2 <> e4) then true
      else false
    | _ -> false)
  | _ -> false;;

(* given a list of labelled formulae lfl *)
(* find the pair that have the same label but are different sll *)
let rec findsameldiffsll lfl =
  let rec find f fl =
    match fl with
    | h::t -> if sameldiffsll f h then (f,h) else find f t
    | _ -> (F.nulllf,F.nulllf)
  in 
  match lfl with
  | h::t -> 
    let (f1,f2) = find h t in 
    if (f1,f2) = (F.nulllf,F.nulllf) then findsameldiffsll t
    else (f1,f2)
  | _ -> (F.nulllf,F.nulllf);;

(***** LS5 *****)
(* return the binary inf, exp subs for left branch, *)
(* exp subs for the right branch, and principal formulae *)
let slinkedlist5 seq =
  let F.SEQ(g,lf,rf) = seq in
  let (pf1,pf2) = findsameldiffsll lf in 
  if (F.nulllf,F.nulllf) = (pf1,pf2) then (F.NULLI,[],[],[])
  else (* label1 = label2, e1 <> e3 or e2 <> e4 *)
    (* this rule is supposed to be applied after unary rules, *)
    (* so e1 <> e2 and e3 <> e4 *)
    let F.LF(label1,F.AP(F.LS(e1,e2))) = pf1 in
    let F.LF(label2,F.AP(F.LS(e3,e4))) = pf2 in
    let expsubsl = 
      if e1 = e2 && e3 = e4 then 
	if label1 = "epsilon" then []
	else failwith "slinkedlist5: label isn't epsilon, but the two lists are empty"
      else if e1 = e2 then [(e3,e4)]
      else if e3 = e4 then [(e1,e2)]
      else [(e1,e2);(e3,e4)] 
    in
    let expsubsr =
      if e1 <> e3 && e2 <> e4 then [(e1,e3);(e2,e4)] 
      else if e1 <> e3 then [(e1,e3)]
      else if e2 <> e4 then [(e2,e4)]
      else failwith "slinkedlist5: the two principal formulae are the same!"
    in 
    let lft = M.subtalllist pf2 (M.subtalllist pf1 lf) in
    let lft2 = lft@[F.LF(label1,F.MTRUE)] in
    if invalidexpsubl expsubsl && invalidexpsubl expsubsr then
      (F.UINF(seq),[("1","2")],[("1","2")],[pf1;pf2])
    else if invalidexpsubl expsubsl then
      let nseq2 = subsexplseq seq expsubsr in
      (F.BINF(seq,nseq2),[("1","2")],expsubsr,[pf1;pf2])
    else if invalidexpsubl expsubsr then
      let nseq1 = subsexplseq (F.SEQ(g,lft2,rf)) expsubsl in
      (F.BINF(nseq1,seq),expsubsl,[("1","2")],[pf1;pf2])
    else 
    let nseq1 = subsexplseq (F.SEQ(g,lft2,rf)) expsubsl in
    let nseq2 = subsexplseq seq expsubsr in
    (F.BINF(nseq1,nseq2),expsubsl,expsubsr,[pf1;pf2]);;

(* test if a labelled formula lf is either a sll or pointer *)
(* with address e *)
let sllorptbyaddr lf e =
  match F.fm lf with
  | F.AP(F.PT(e1,_))
  | F.AP(F.LS(e1,_)) -> if e1 = e then true else false
  | _ -> false;;

(* given a labelled formula lf, a list g of ternary relations *)
(* a list lfl of labelled formulae *)
(* find a sll or pointer in lfl labelled *)
(* by the direct children of the label of lf *)
(* and has the same address *)
(* lf must be a sll *)
let finddirchlfsameaddr lf g lfl =
  let rec find lfl ll e =
    match lfl with
    | h::t -> 
      if List.mem (F.lb h) ll && sllorptbyaddr h e then h 
      else find t ll e 
    | _ -> F.nulllf 
  in 
  let dirchdl = (dirchd g (F.lb lf))@["epsilon";(F.lb lf)] in
  let F.AP(F.LS(e1,e2)) = F.fm lf in
  find (M.subtalllist lf lfl) dirchdl e1;;

(* given a list lfl of labelled formulae *)
(* and a list g of ternary relations *)
(* find a triple (pf,df1,df2) such that (1) pf is a sll, *)
(* (2) df1 is either a sll or a pointer *)
(* (3) pf and df1 have the same address *)
(* (4) label of df1 is a direct child of label of pf *)
(* (5) df2 is the formula to be created by LS6 rule *)
(* do not return applied apps! *)
let findls6app lfl g = 
  let rec find slll lfl g = 
    match slll with
    | h::t -> 
      let rec findchd sll lfl lflo g =
	let dch = finddirchlfsameaddr sll g lfl in
	if dch = F.nulllf then (F.nulllf,F.nulllf,F.nulllf) 
	else (* check if this app is applied before *)
	  (let F.AP(F.LS(e1,e2)) = F.fm sll in
	   match F.fm dch with
	   | F.AP(F.PT(e3,(e4::_)))
	   | F.AP(F.LS(e3,e4)) -> 
	     let slllb = F.lb sll in
	     let nl = otherdirchd (idrel (g@[F.RT(slllb,"epsilon",slllb)])) slllb (F.lb dch) in
	     if nl = "-1" then 
	       failwith "findls6app: label of dch is not a child of label of sll!"
	     else 
	       let nlf = F.LF(nl,F.AP(F.LS(e4,e2))) in
	       if (List.mem nlf lflo) || (nl = "epsilon" && e4 = e2) then (* find other apps for this sll *)
		 findchd sll (M.subtalllist dch (M.subtalllist nlf lfl)) lflo g
	       else (sll,dch,nlf) 
	   | _ -> failwith "findls6app: dch is not sll nor pointer!")
      in 
      let (pf,df1,df2) = findchd h lfl lfl g in
      if pf = F.nulllf then find t lfl g 
      else (pf,df1,df2)
    | _ -> (F.nulllf,F.nulllf,F.nulllf)
  in 
  let allsll = findallform "LS" lfl in
  find allsll lfl g;;

(***** LS6 rule *****)
(* return the unary inf and the principal formulae *)
(* will not return repeated applications *)
(* i.e., df2 is guaranteed not in the LHS *)
let slinkedlist6 seq =
  let F.SEQ(g,lf,rf) = seq in
  let (pf,df1,df2) = findls6app lf g in
  if pf = F.nulllf then (F.NULLI,[],F.nulllf)
  else (F.UINF(F.SEQ(g,(lf@[df2]),rf)),[pf;df1],df2);;

(* test if a labelled formula lf is either a sll or pointer *)
(* that points to e *)
let sllorptbyend lf e =
  match F.fm lf with
  | F.AP(F.PT(_,(e2::_)))
  | F.AP(F.LS(_,e2)) -> if e2 = e then true else false
  | _ -> false;;

(* given a labelled formula lf, a list g of ternary relations *)
(* a list lfl of labelled formulae *)
(* find a sll or pointer in lfl labelled *)
(* by the direct children of the label of lf *)
(* and points to the same exp/value *)
(* lf must be a sll *)
let finddirchlfsameend lf g lfl =
  let rec find lfl ll e =
    match lfl with
    | h::t -> 
      if List.mem (F.lb h) ll && sllorptbyend h e then h
      else find t ll e
    | _ -> F.nulllf
  in 
  let dirchdl = (dirchd g (F.lb lf))@["epsilon";(F.lb lf)] in
  let F.AP(F.LS(e1,e2)) = F.fm lf in
  find (M.subtalllist lf lfl) dirchdl e2;;

(* given a list lfl of labelled formulae *)
(* and a list g of ternary relations *)
(* find a triple (pf,df1,df2) such that (1) pf is a sll *)
(* (2) df1 is either a sll or a pointer *)
(* (3) pf and df1 points to the same exp/value *)
(* (4) label of df1 is a direct child of label of pf *)
(* (5) df2 is the formula to be created by LS7 rule *)
(* do not return applied apps! *)
let findls7app lfl g =
  let rec find slll lfl g =
    match slll with
    | h::t -> 
      let rec findchd sll lfl lflo g =
	let dch = finddirchlfsameend sll g lfl in
	if dch = F.nulllf then (F.nulllf,F.nulllf,F.nulllf)
	else (* check if this app is applied before *)
	  (let F.AP(F.LS(e1,e2)) = F.fm sll in 
	  match F.fm dch with
	  | F.AP(F.PT(e3,(e4::_)))
	  | F.AP(F.LS(e3,e4)) ->
	    let slllb = F.lb sll in
	    let nl = otherdirchd (idrel (g@[F.RT(slllb,"epsilon",slllb)])) slllb (F.lb dch) in
	    if nl = "-1" then 
	      failwith "findls7app: label of dch is not a child of label of sll!"
	    else 
	      let nlf = F.LF(nl,F.AP(F.LS(e1,e3))) in
	      if (List.mem nlf lflo) || (nl = "epsilon" && e1 = e3) then (* find other apps for this sll *)
		findchd sll (M.subtalllist dch (M.subtalllist nlf lfl)) lflo g
	      else (sll,dch,nlf)
	  | _ -> failwith "findls7app: dch is not sll nor pointer!")
      in
      let (pf,df1,df2) = findchd h lfl lfl g in
      if pf = F.nulllf then find t lfl g
      else (pf,df1,df2)
    | _ -> (F.nulllf,F.nulllf,F.nulllf)
  in 
  let allsll = findallform "LS" lfl in
  find allsll lfl g;;

(***** LS7 rule *****)
(* return the unary inf and the principal formulae *)
(* will not return repeated applications *)
(* i.e., df2 is guaranteed not in the LHS *)
let slinkedlist7 seq =
  let F.SEQ(g,lf,rf) = seq in
  let (pf,df1,df2) = findls7app lf g in
  if pf = F.nulllf then (F.NULLI,[],F.nulllf)
  else (F.UINF(F.SEQ(g,(lf@[df2]),rf)),[pf;df1],df2);;

(* test if a labelled formula is a data structure that *)
(* has address e *)
(* data structure includes: pointer, linked list, binary tree *)
let hasaddr lf e =
  match F.fm lf with
  | F.AP(F.PT(e1,_))
  | F.AP(F.LS(e1,_))
  | F.AP(F.TR(e1)) -> if e1 = e then true else false
  | _ -> false;;

(* given a list lfl of labelled formula, find all labelle formulae *)
(* that is a data structure containing address e *)
let rec findallbyaddr lfl e =
  match lfl with
  | h::t -> if hasaddr h e then [h]@(findallbyaddr t e) else findallbyaddr t e
  | _ -> [];;

(* given a list g of ternar relations, *)
(* a label l, find all its siblings *)
let findallsib g l =
  let rec find g l =
    match g with
    | h::t -> 
      let F.RT(a1,a2,a3) = h in 
      if a1 = l then [a2]@(find t l)
      else if a2 = l then [a1]@(find t l)
      else find t l
    | _ -> []
  in 
  M.setlist (find g l);;

(* given a list lfl of labelled formulae *)
(* find all formulae with label l *)
let findallformbylabel lfl l =
  let rec find lfl l =
    match lfl with
    | h::t -> if (F.lb h) = l then [h]@(find t l) else find t l 
    | _ -> []
  in 
  M.setlist (find lfl l);;

(* given a labelled formula f that is a data structure *)
(* test if it's empty according to rf *)
(* return the guardian formula if f is an non-empty *)
(* pointer, list, or tree *)
(* otherwise return F.nulllf *)
let nonempds f rf =
  match F.fm f with
  | F.AP(F.PT(_,_)) -> F.LF("0",F.FALSE)
  | F.AP(F.LS(e1,e2)) ->
    let label1 = containsf (F.AP(F.EQ(e1,e2))) rf in
    let label2 = containsf (F.AP(F.EQ(e2,e1))) rf in
    if label1 <> "-1" then F.LF(label1,F.AP(F.EQ(e1,e2)))
    else if label2 <> "-1" then F.LF(label2,F.AP(F.EQ(e2,e1)))
    else F.nulllf
  | F.AP(F.TR(e1)) ->
    let label1 = containsf (F.AP(F.EQ(e1,"nil"))) rf in
    let label2 = containsf (F.AP(F.EQ("nil",e1))) rf in
    if label1 <> "-1" then F.LF(label1,F.AP(F.EQ(e1,"nil")))
    else if label2 <> "-1" then F.LF(label2,F.AP(F.EQ("nil",e1))) 
    else F.nulllf
  | _ -> F.nulllf;;

(* test if a (unlabelled) formula is a pointer from e1 to e2 *)
let isptform f e1 e2 =
  match f with
  | F.AP(F.PT(e3,(e4::_))) -> if e1 = e3 && e2 = e4 then true else false
  | _ -> false;;

(* given a list ll of labels, check if there is a label with a formula on LHS *)
(* that contains address e, which is non-empty according to RHS *)
(* if there is, return the formula and it's guard *)
(* otherwise return (F.nulllf,F.nulllf) *)
let rec hasnempaddr ll lf rf e =
  match ll with
  | h::t -> 
    let allforml = findallformbylabel lf h in
    let formsbyaddr = findallbyaddr allforml e in
    let rec nonemp lfl rf =
      match lfl with
      | h::t -> 
	let gf = nonempds h rf in
	if gf <> F.nulllf then (h,gf) 
	else nonemp t rf
      | _ -> (F.nulllf,F.nulllf)
    in 
    let (f,gf) = nonemp formsbyaddr rf in
    if f = F.nulllf then hasnempaddr t lf rf e
    else (f,gf)
  | _ -> (F.nulllf,F.nulllf);;

(* given a sequent seq, find an application for LS8 *)
(* return the formula to be created *)
(* do not return applid apps! *)
let findls8app seq =
  let rec findlhsseg slll lf rf g =
    match slll with
    | h::t -> 
      let rec findchdlhs sllr lf rf g =
	let dch = finddirchlfsameaddr sllr g lf in
	if dch = F.nulllf then (F.nulllf,F.nulllf,F.nulllf,F.nulllf,F.nulllf)
	else 
	  (let F.AP(F.LS(e1,e2)) = F.fm sllr in
	   match F.fm dch with
	   | F.AP(F.PT(e3,(e4::_)))
	   | F.AP(F.LS(e3,e4)) ->
	     let sllrlb = F.lb sllr in
	     let nl = otherdirchd (idrel (g@[F.RT(sllrlb,"epsilon",sllrlb)])) sllrlb (F.lb dch) in
	     if nl = "-1" then 
	       failwith "findls8app: label of dch is not a child of label of sllr!"
	     else 
	       let nlf = F.LF(nl,F.AP(F.LS(e4,e2))) in
	       if List.mem nlf rf then (* find other apps for this sillr *)
		 findchdlhs sllr (M.subtalllist dch lf) rf g
	       else if e2 = "nil" then (* don't need disjf and gf *)
		 (dch,F.nulllf,sllr,F.nulllf,nlf)
	       else if isptform (F.fm dch) e3 e4 then 
	       (* don't need disjf and gf, but need (e3 = e2) in RHS *)
		 let rpf2 = 
		   let t1 = findulform (F.AP(F.EQ(e3,e2))) rf in
		   let t2 = findulform (F.AP(F.EQ(e2,e3))) rf in
		   if t1 = F.nulllf && t2 = F.nulllf then F.nulllf
		   else if t1 <> F.nulllf then t1
		   else t2
		 in 
		 if rpf2 = F.nulllf then findchdlhs sllr (M.subtalllist dch lf) rf g
		 else (dch,F.nulllf,sllr,rpf2,nlf)
	       else 
		 let allsib = findallsib g (F.lb dch) in
		 let (disjf,gf) = hasnempaddr allsib lf rf e2 in 
		 if disjf <> F.nulllf then (dch,disjf,sllr,gf,nlf)
		 else findchdlhs sllr (M.subtalllist dch lf) rf g 
	   | _ -> failwith "findls8app: dch is not sll nor pointer!")
      in 
      let (lf1,lf2,rf1,rf2,nf) = findchdlhs h lf rf g in
      if lf1 = F.nulllf then findlhsseg t lf rf g 
      else (lf1,lf2,rf1,rf2,nf)
    | _ -> (F.nulllf,F.nulllf,F.nulllf,F.nulllf,F.nulllf)
  in 
  let F.SEQ(g,lf,rf) = seq in
  let allsllr = findallform "LS" rf in
  findlhsseg allsllr lf rf g;;

(***** LS8 rule *****)
(* return the unary inf and the CREATED formula *)
(* will not return repeated applications *)
(* i.e., df2 is guaranteeed not in the RHS *)
let slinkedlist8 seq =
  let F.SEQ(g,lf,rf) = seq in 
  let (lpf1,lpf2,rpf1,rpf2,nf) = findls8app seq in
  if lpf1 = F.nulllf then (F.NULLI,[],[],F.nulllf)
  else if lpf2 = F.nulllf && rpf2 = F.nulllf then 
    (F.UINF(F.SEQ(g,lf,(rf@[nf]))),[lpf1],[rpf1],nf)
  else if lpf2 = F.nulllf && rpf2 <> F.nulllf then
    (F.UINF(F.SEQ(g,lf,(rf@[nf]))),[lpf1],[rpf1;rpf2],nf)
  else (F.UINF(F.SEQ(g,lf,(rf@[nf]))),[lpf1;lpf2],[rpf1;rpf2],nf);;

(* test if two labelled formulae are diff data structures *)
(* that has the same address *)
(* and the two labels are siblings *)
let sibsameaddr g lf1 lf2 =
  match lf1 with
  | F.LF(label1,F.AP(F.PT(e1,_)))
  | F.LF(label1,F.AP(F.LS(e1,_)))
  | F.LF(label1,F.AP(F.TR(e1))) ->
    (match lf2 with
    | F.LF(label2,F.AP(F.PT(e2,_)))
    | F.LF(label2,F.AP(F.LS(e2,_)))
    | F.LF(label2,F.AP(F.TR(e2))) ->
      if (siblings g label1 label2) && (e1 = e2) then true else false
    | _ -> false)
  | _ -> false;;

(* find two formulae from lf with sibling labels that are data structures *)
(* with the same pointer *)
let rec findinconsds g lf rf =
  let rec find f lf rf =
    let gf1 = nonempds f rf in (* check if f is non-empty ds *)
    if gf1 <> F.nulllf then
      match lf with
      | h::t -> 
	if sibsameaddr g f h then (* check if h is non-empty ds *)
	  let gf2 = nonempds h rf in 
	  if gf2 <> F.nulllf then (f,h,gf1,gf2)
	  else find f t rf
	else find f t rf
      | _ -> (F.nulllf,F.nulllf,F.nulllf,F.nulllf)
    else (F.nulllf,F.nulllf,F.nulllf,F.nulllf)
  in 
  match lf with
  | h::t -> 
    let (f1,f2,gf1,gf2) = find h t rf in
    if f1 = F.nulllf then
      findinconsds g t rf 
    else (f1,f2,gf1,gf2)
  | _ -> (F.nulllf,F.nulllf,F.nulllf,F.nulllf);;

(***** DS rule *****)
(* this rule includes |->L3 *)
let inconsisds seq =
  let F.SEQ(g,lf,rf) = seq in
  let (pfl1,pfl2,gf1,gf2) = findinconsds g lf rf in
  if pfl1 = F.nulllf then (F.NULLI,[],[])
  else
    let pfrl = 
      if gf1 = F.LF("0",F.FALSE) && gf2 = F.LF("0",F.FALSE) then []
      else if gf1 = F.LF("0",F.FALSE) then [gf2]
      else if gf2 = F.LF("0",F.FALSE) then [gf1]
      else [gf1;gf2]
    in 
    ((F.UINF F.empseq),[pfl1;pfl2],pfrl);;

(* test if a tree formula is labelled by epsilon *)
(* but the address is not nil *)
let badtr lf =
  match F.fm lf with
  | F.AP(F.TR(e)) -> if (F.lb lf) = "epsilon" && e <> "nil" then true else false
  | _ -> false;;

(* given a list lfl of labelled formuale *)
(* return a bad tree of the form epsilon:tr(e) where *)
(* e is not epsilon *)
let rec hasbadtr lfl =
  match lfl with
  | h::t -> if badtr h then h else hasbadtr t
  | _ -> F.nulllf;;

(* test if a tree formula is an emoty tree *)
(* i.e., epsilon:tr(nil) *)
let isemptytr lf =
  match F.fm lf with
  | F.AP(F.TR(e)) -> if (F.lb lf) = "epsilon" && e = "nil" then true else false
  | _ -> false;;

(* delete empty tr formuale of the form epsilon:tr(nil) *)
(* from a list lfl of labelled formulae *)
let rec delemptytr lfl =
  match lfl with
  | h::t -> if isemptytr h then delemptytr t else [h]@(delemptytr t)
  | _ -> [];;

(***** TR1 rule *****)
(* return the unar yinf, the list of exp subs, *)
(* and the principal formula *)
let btree1 seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasbadtr lf in
  if pf = F.nulllf then (F.NULLI,[],F.nulllf)
  else 
    let F.LF(label,F.AP(F.TR(e))) = pf in
    let expsubs = [(e,"nil")] in
    if invalidexpsubl expsubs then
      (F.UINF(seq),[("1","2")],pf)
    else 
      let F.SEQ(gf,lff,rff) = subsexplseq seq expsubs in
      let nseq = F.SEQ(gf,(delemptytr lff),rff) in
      (F.UINF(nseq),expsubs,pf);;

(* test if a list lfl of labelled formuale *)
(* contains an empty tree epsilon:tr(nil) *)
let rec hasemptytr lfl =
  match lfl with
  | h::t -> if isemptytr h then h else hasemptytr t
  | _ -> F.nulllf;;

(***** TR2 rule *****)
(* return the unary inf, and principal formula *)
let btree2 seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasemptytr rf in
  if pf = F.nulllf then (F.NULLI,F.nulllf)
  else ((F.UINF F.empseq),pf);;

(* test if a labelled formula is empty tree but no labelled by epsilon *)
let isempnetr lf =
  match F.fm lf with
  | F.AP(F.TR(e)) -> if (F.lb lf) <> "epsilon" && e = "nil" then true else false
  | _ -> false;;

(* test if a list lfl of labelled formulae contains an empty tree *)
(* but not labelled by epsilon *)
(* return the formula if found, otherwise return F.nulllr *)
let rec hasempnetr lfl =
  match lfl with
  | h::t -> if isempnetr h then h else hasempnetr t
  | _ -> F.nulllf;;

(***** TR3 rule *****)
let btree3 seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasempnetr lf in
  if pf = F.nulllf then (F.NULLI,F.nulllf)
  else 
    let nlf = M.subtalllist pf lf in
    (F.UINF(F.SEQ(g,(nlf@[F.LF((F.lb pf),F.MTRUE)]),rf)),pf);;

(* test if two labelled formulae have the same label *)
(* but are two different btr *)
let rec samelidffbtr lf1 lf2 =
  match lf1 with
  | F.LF(label1,F.AP(F.TR(e1))) ->
    (match lf2 with
    | F.LF(label2,F.AP(F.TR(e2))) ->
      if label1 = label2 && e1 <> e2 then true
      else false
    | _ -> false)
  | _ -> false;;

(* given a list lfl of labelled formulae *)
(* find teh pair that have the same label but are different btr *)
let rec findsameldiffbtr lfl =
  let rec find f fl =
    match fl with
    | h::t -> if samelidffbtr f h then (f,h) else find f t
    | _ -> (F.nulllf,F.nulllf)
  in 
  match lfl with
  | h::t -> 
    let (f1,f2) = find h t in
    if (f1,f2) = (F.nulllf,F.nulllf) then findsameldiffbtr t
    else (f1,f2)
  | _ -> (F.nulllf,F.nulllf);;

(***** TR4 rule *****)
(* return the binary inf, exp subs for left branch, *)
(* exp subs for the right branch, and principal formulae *)
let btree4 seq =
  let F.SEQ(g,lf,rf) = seq in
  let (pf1,pf2) = findsameldiffbtr lf in
  if (F.nulllf,F.nulllf) = (pf1,pf2) then (F.NULLI,[],[])
  else (* label1 = label 2 and e1 <> e2*)
    let F.LF(label1,F.AP(F.TR(e1))) = pf1 in
    let F.LF(label2,F.AP(F.TR(e2))) = pf2 in
    let expsubs = [(e1,e2)] in
    if invalidexpsubl expsubs then
      (F.UINF(seq),[("1","2")],[pf1;pf2])
    else 
      let nseq = subsexplseq seq expsubs in
      (F.UINF(nseq),expsubs,[pf1;pf2]);;

(* test if a labelled formula lf is a pointer with address e *)
let pt2byaddr lf e =
  match F.fm lf with
  | F.AP(F.PT(e1,fl)) -> if e1 = e && (List.length fl > 1) then true else false
  | _ -> false;;

(* given a labelled formula lf, which is btr with root e *)
(* a list g of ternary relations, *)
(* a list lfl of labelled formulae *)
(* find a 2-field pointer in lfl labelled by the *)
(* direct children of the label of lf *)
(* and has address e *)
let finddirchpt2sameroot lf g lfl =
  let rec find lfl ll e =
    match lfl with
    | h::t -> 
      if List.mem (F.lb h) ll && pt2byaddr h e then h
      else find t ll e
    | _ -> F.nulllf
  in 
  let dirchdl = (dirchd g (F.lb lf))@["epsilon";(F.lb lf)] in
  let F.AP(F.TR(e1)) = F.fm lf in
  find (M.subtalllist lf lfl) dirchdl e1;;

(* find a ternary relation that has children c1,c2 in g *)
let rec findtr_bychd c1 c2 g =
  match g with
  | h::t -> 
    let F.RT(a1,a2,a3) = h in
    if (a1 = c1 && a2 = c2) || (a1 = c2 && a2 = c1) then a3
    else findtr_bychd c1 c2 t
  | _ -> "-1";;

(* given a list lfl of labelled formulae *)
(* and a list g of ternary relations *)
(* find a triple (pf,df1,df2) such that (1) pf is a btr with root e *)
(* (2) df1 is a 2-field pointer with address e *)
(* (3) label pf df1 is a direct child of label of pf *)
(* (4) df2 is the formula to be created by TR5 rule *)
(* do not return applied apps! *)
let findtr5app lfl g =
  let rec find btrl lfl g =
    match btrl with
    | h::t ->
      let rec findchd btr lfl lflo g =
	let dch = finddirchpt2sameroot btr g lfl in
	if dch = F.nulllf then (F.nulllf,F.nulllf,F.nulllf)
	else (* check if this app is applied before *)
	  let F.AP(F.TR(e1)) = F.fm btr in
	  let F.AP(F.PT(e2,(e3::e4::_))) = F.fm dch in
	  let btrlb = F.lb btr in
	  let nl = otherdirchd (idrel (g@[F.RT(btrlb,"epsilon",btrlb)])) btrlb (F.lb dch) in
	  if nl = "-1" then 
	    failwith "findtr5app: label of dch is not a child of label of btr!"
	  else 
	    let nlf = F.LF(nl,F.MAND(F.AP(F.TR(e3)),F.AP(F.TR(e4)))) in
	    let applied lf lfl g =
	      match lf with
	      | F.LF(label,F.MAND(F.AP(F.TR(e1)),F.AP(F.TR(e2)))) ->
		let l1 = containsf (F.AP(F.TR(e1))) lfl in
		let l2 = containsf (F.AP(F.TR(e2))) lfl in
		if l1 = "-1" || l2 = "-1" then false
		else 
		  let l3 = findtr_bychd l1 l2 g in
		  if l3 = label then true else false 
	      | _ -> failwith "findtr5app: lf not a legit *-tr formula!"
	    in 
	    if (List.mem nlf lflo) || (applied nlf lfl g) then (* find other apps for this btr *)
	      findchd btr (M.subtalllist dch (M.subtalllist nlf lfl)) lflo g
	    else (btr,dch,nlf)
      in
      let (pf,df1,df2) = findchd h lfl lfl g in
      if pf = F.nulllf then find t lfl g 
      else (pf,df1,df2)
    | _ -> (F.nulllf,F.nulllf,F.nulllf)
  in 
  let allbtr = findallform "TR" lfl in
  find allbtr lfl g;;

(***** TR5 rule *****)
(* return the unary inf and the principal formulae *)
(* will not return repeated applications *)
(* i.e., df2 is guaranteeed not in the LHS *)
let btree5 seq =
  let F.SEQ(g,lf,rf) = seq in
  let (pf,df1,df2) = findtr5app lf g in
  if pf = F.nulllf then (F.NULLI,[],F.nulllf)
  else (F.UINF(F.SEQ(g,(lf@[df2]),rf)),[pf;df1],df2);;

(* given a sequent seq, find an application for TR6 *)
(* return the formula to be created *)
(* do not return applied apps! *)
let findtr6app seq =
  let rec findlhspt2 btrl lf rf g =
    match btrl with
    | h::t ->
      let rec findchdlhs btr lf rf g =
	let dch = finddirchpt2sameroot btr g lf in
	if dch = F.nulllf then (F.nulllf,F.nulllf,F.nulllf)
	else (* check if this app is applied before *)
	  let F.AP(F.TR(e1)) = F.fm btr in
	  let F.AP(F.PT(e2,(e3::e4::_))) = F.fm dch in
	  let btrlb = F.lb btr in
	  let nl = otherdirchd (idrel (g@[F.RT(btrlb,"epsilon",btrlb)])) btrlb (F.lb dch) in
	  if nl = "-1" then 
	    failwith "findtr6app: label of dch is not a child of label of btr!"
	  else 
	    let nlf = F.LF(nl,F.MAND(F.AP(F.TR(e3)),F.AP(F.TR(e4)))) in
	    if List.mem nlf rf then (* find other apps for this btr *)
	      findchdlhs btr (M.subtalllist dch lf) rf g
	    else (btr,dch,nlf)
      in 
      let (pf,df1,df2) = findchdlhs h lf rf g in
      if pf = F.nulllf then findlhspt2 t lf rf g
      else (pf,df1,df2)
    | _ -> (F.nulllf,F.nulllf,F.nulllf)
  in
  let F.SEQ(g,lf,rf) = seq in
  let allbtr = findallform "TR" rf in
  findlhspt2 allbtr lf rf g;;

(***** TR6 rule *****)
(* return the unary inf, the left principal formula, *)
(* and the right principal formula *)
(* will not return repeated applications *)
(* i.e., df2 is guaranteed not in the RHS *)
let btree6 seq =
  let F.SEQ(g,lf,rf) = seq in
  let (pf,df1,df2) = findtr6app seq in
  if df2 = F.nulllf then (F.NULLI,F.nulllf,F.nulllf,F.nulllf)
  else (F.UINF(F.SEQ(g,lf,(rf@[df2]))),df1,pf,df2);;

(*********************************************************************)
(* The following functions are for rewrite rules *********************)
(*********************************************************************)

(* given a formula form, rewrite its subformula *)
(* ls(e,e) or ls(nil,_) or tr(nil) into mtrue *)
(* rewrite mtrue -* A into A *)
(* rewrite A*mtrue or mtrue*A into A *)
let rec rewrite_form form =
  match form with
  | F.TRUE -> F.TRUE
  | F.FALSE -> F.FALSE
  | F.AP(F.EQ(e1,e2)) -> F.AP(F.EQ(e1,e2))
  | F.AP(F.PT(e1,fl)) -> F.AP(F.PT(e1,fl))
  | F.AP(F.LS(e1,e2)) -> if e1 = e2 then F.MTRUE else F.AP(F.LS(e1,e2))
  | F.AP(F.TR(e1)) -> if e1 = "nil" then F.MTRUE else F.AP(F.TR(e1))
  | F.NOT(f) -> F.NOT(rewrite_form f)
  | F.EQU(f1,f2) -> F.EQU((rewrite_form f1),(rewrite_form f2))
  | F.IMP(f1,f2) -> F.IMP((rewrite_form f1),(rewrite_form f2))
  | F.OR(f1,f2) -> F.OR((rewrite_form f1),(rewrite_form f2))
  | F.AND(f1,f2) -> F.AND((rewrite_form f1),(rewrite_form f2))
  | F.MTRUE -> F.MTRUE
  | F.MAND(f1,f2) -> 
    if f1 = F.MTRUE then rewrite_form f2
    else if f2 = F.MTRUE then rewrite_form f1
    else F.MAND((rewrite_form f1),(rewrite_form f2))
  | F.MIMP(f1,f2) -> 
    if f1 = F.MTRUE then rewrite_form f2
    else F.MIMP((rewrite_form f1),(rewrite_form f2))
  | F.FORALL(e,f) -> F.FORALL(e,(rewrite_form f))
  | F.EXISTS(e,f) -> F.EXISTS(e,(rewrite_form f))
  | _ -> failwith "rewrite_emp_list: not a valid SL formula";;

(* use the rewrite rules to rewrite a sequent *)
let rec rewrite_seq seq =
  let F.SEQ(g,lf,rf) = seq in
  let rec rewrite_lfl lfl =
    match lfl with
    | h::t -> [F.LF((F.lb h),(rewrite_form (F.fm h)))]@(rewrite_lfl t)
    | _ ->[]
  in 
  let nseq = F.SEQ(g,(rewrite_lfl lf),(rewrite_lfl rf)) in
  if nseq <> seq then rewrite_seq nseq else nseq;;

(*********************************************************************)
(* The following functions are needed when building derivations ******)
(*********************************************************************)

(* recorver the unsat core (lf,rf) from seq and subs *)
(* lf and rf are labelled_form lists, seq is the sequent in the conclusion *)
(* subs is a list of label substitutions (x,y), where x and y are strings *)
(* return a pair (lft,rft) as the new unsat core *)
let recunsat seq unsat subs =
  let rec recover fl1 fl2 subs acc =
    match fl1 with
    | h::t -> 
      if List.mem (List.hd (subslflist [h] subs)) fl2 then recover t fl2 subs (acc@[h])
      else recover t fl2 subs acc
    | _ -> acc
  in 
  let F.SEQ(g1,lf1,rf1) = seq in
  let (lf2,rf2) = unsat in
  ((recover lf1 lf2 subs []),(recover rf1 rf2 subs []));;

(* recorver the unsat core (lf,rf) from seq and expsubs *)
(* lf and rf are labelled_form lists, seq is the sequent in the conclusion *)
(* subs is a list of exp/value substitutions (e1,e2), where e1 and e2 are strings *)
(* return a pair (lft,rft) as the new unsat core *)
let recunsatesubs seq unsat subs =
  let rec recover fl1 fl2 subs acc =
    match fl1 with
    | h::t -> 
      if List.mem (F.subsexpllf h subs) fl2 then recover t fl2 subs (acc@[h])
      else recover t fl2 subs acc
    | _ -> acc
  in 
  let F.SEQ(g1,lf1,rf1) = seq in
  let (lf2,rf2) = unsat in
  ((recover lf1 lf2 subs []),(recover rf1 rf2 subs []));;

(* recover the unsat core from seq *)
(* only used for H, HE, and (left premise of) HC *)
(* delete those in lu but not in lf *)
(* i.e., those formulae created by H,HE,HC *)
let recunsath seq unsat =
  let F.SEQ(g,lf,rf) = seq in
  let (lu,ru) = unsat in
  let rec filterunsat u fl =
    match u with
    | h::t -> if List.mem h fl then [h]@(filterunsat t fl) else filterunsat t fl
    | _ -> []
  in 
  ((filterunsat lu lf),ru);;

(* check if the sequent seq contains the unsat core (lf,rf) *)
let containsunsat seq unsat =
  let F.SEQ(g,lf,rf) = seq in
  let (lu,ru) = unsat in 
  if (M.listsubset lu lf) && (M.listsubset ru rf) then true else false;;

(* given a formula, a relation and the corresponding rule *)
(* extract the unsat core (lf,rf) on the conclusion *)
(* only deal with andl, impr, mandl, mimpr *)
(* notl, notr, orr *)
(* when unsat is not a subset of the premise *)
let nextunsat_u rule pf r unsat =
  let (lu,ru) = unsat in
  match rule with
  | "andL" -> 
    let F.LF(l,F.AND(f1,f2)) = pf in 
    let nlu0 = delf (F.LF(l,f1)) lu in
    let nlu1 = delf (F.LF(l,f2)) nlu0 in
    let nlu2 = if List.mem pf nlu1 then nlu1 else nlu1@[pf] in
    (nlu2,ru)
  | "impR" -> 
    let F.LF(l,F.IMP(f1,f2)) = pf in 
    let nlu0 = delf (F.LF(l,f1)) lu in
    let nru0 = delf (F.LF(l,f2)) ru in
    let nru1 = if List.mem pf nru0 then nru0 else nru0@[pf] in
    (nlu0,nru1)
  | "mandL" ->
    let F.RT(t1,t2,t3) = r in
    let F.LF(l,F.MAND(f1,f2)) = pf in
    let nlu0 = delf (F.LF(t1,f1)) lu in
    let nlu1 = delf (F.LF(t2,f2)) nlu0 in
    let nlu2 = if List.mem pf nlu1 then nlu1 else nlu1@[pf] in
    (nlu2,ru)
  | "mimpR" ->
    let F.RT(t1,t2,t3) = r in
    let F.LF(l,F.MIMP(f1,f2)) = pf in
    let nlu0 = delf (F.LF(t1,f1)) lu in
    let nru0 = delf (F.LF(t2,f2)) ru in
    let nru1 = if List.mem pf nru0 then nru0 else nru0@[pf] in
    (nlu0,nru1)
  | "notL" -> 
    let F.LF(l,F.NOT(f)) = pf in
    let nru = delf (F.LF(l,f)) ru in
    let nlu = if List.mem pf lu then lu else lu@[pf] in
    (nlu,nru)
  | "notR" -> 
    let F.LF(l,F.NOT(f)) = pf in
    let nlu = delf (F.LF(l,f)) lu in
    let nru = if List.mem pf ru then ru else ru@[pf] in
    (nlu,nru)    
  | "orR" -> 
    let F.LF(l,F.OR(f1,f2)) = pf in 
    let nru0 = delf (F.LF(l,f1)) ru in
    let nru1 = delf (F.LF(l,f2)) nru0 in
    let nru2 = if List.mem pf nru1 then nru1 else nru1@[pf] in
    (lu,nru2);;

(* given a formula, a value, and the rule *)
(* extract the unsat core (lf,rf) on the conclusion *)
(* only deal with existsl, existsr *)
(* when unsat is not a subset of the premise *)
let nextunsat_qt rule pf v unsat =
  let (lu,ru) = unsat in
  match rule with
  | "existsL" -> 
    let F.LF(l,F.EXISTS(x,f)) = pf in 
    let nlu0 = delf (F.LF(l,(F.subsexpf f v x))) lu in
    let nlu1 = if List.mem pf nlu0 then nlu0 else nlu0@[pf] in
    (nlu1,ru)
  | "existsR" ->
    let F.LF(l,F.EXISTS(x,f)) = pf in
    let nru0 = delf (F.LF(l,(F.subsexpf f v x))) ru in
    let nru1 = if List.mem pf nru0 then nru0 else nru0@[pf] in
    (lu,nru1)
  | "forallR" -> 
    let F.LF(l,F.FORALL(x,f)) = pf in 
    let nru0 = delf (F.LF(l,(F.subsexpf f v x))) ru in
    let nru1 = if List.mem pf nru0 then nru0 else nru0@[pf] in
    (lu,nru1)
  | "forallL" ->
    let F.LF(l,F.FORALL(x,f)) = pf in
    let nlu0 = delf (F.LF(l,(F.subsexpf f v x))) lu in
    let nlu1 = if List.mem pf nlu0 then nlu0 else nlu0@[pf] in
    (nlu1,ru);;


(* given a formula, a relation, and the corresponding rule *)
(* extract the unsat core (lf,rf) on the conclusion *)
(* only deal with andr, impl, mandr, mimpl *)
(* orl *)
(* when unsat is not a subset of any premises *) 
let nextunsat_b rule pf r unsatl unsatr =
  let (l1,r1) = unsatl in
  let (l2,r2) = unsatr in
  match rule with
  | "andR" -> 
    let F.LF(l,F.AND(f1,f2)) = pf in
    let nr0 = delf (F.LF(l,f1)) (r1@r2) in
    let nr1 = delf (F.LF(l,f2)) nr0 in
    let nl = M.setlist (l1@l2) in
    let nr = M.setlist (nr1@[pf]) in
    (nl,nr)
  | "orL" -> 
    let F.LF(l,F.OR(f1,f2)) = pf in
    let nl0 = delf (F.LF(l,f1)) (l1@l2) in
    let nl1 = delf (F.LF(l,f2)) nl0 in
    let nr = M.setlist (r1@r2) in
    let nl = M.setlist (nl1@[pf]) in
    (nl,nr)
  | "impL" ->
    let F.LF(l,F.IMP(f1,f2)) = pf in
    let nl0 = delf (F.LF(l,f2)) (l1@l2) in
    let nr0 = delf (F.LF(l,f1)) (r1@r2) in 
    let nl = M.setlist (nl0@[pf]) in
    let nr = M.setlist nr0 in
    (nl,nr)
  | "mandR" ->
    let F.LF(l,F.MAND(f1,f2)) = pf in
    let F.RT(t1,t2,t3) = r in
    let nr0 = delf (F.LF(t1,f1)) (r1@r2) in
    let nr1 = delf (F.LF(t2,f2)) nr0 in
    let nl = M.setlist (l1@l2) in
    let nr = M.setlist (nr1@[pf]) in
    (nl,nr)
  | "mimpL" ->
    let F.LF(l,F.MIMP(f1,f2)) = pf in
    let F.RT(t1,t2,t3) = r in
    let nl0 = delf (F.LF(t3,f2)) (l1@l2) in
    let nr0 = delf (F.LF(t1,f1)) (r1@r2) in 
    let nl = M.setlist (nl0@[pf]) in
    let nr = M.setlist nr0 in
    (nl,nr);;

(* apply a list sl of label substitutions [x/y] *)
(* on a list usedl of pairs (relation * labelled_form) *)
let rec subsusedlist usedl sl =
  let rec subs usedl s acc =
    match usedl with
    | h::t -> 
      let (x,y) = s in
      let (r,lf) = h in
      let ([r1],[lf1]) = ((subsrlist [r] x y),(subsflist [lf] x y)) in
      subs t s (acc@[(r1,lf1)])
    | _ -> acc
  in 
  match sl with
  | h::t -> subsusedlist (subs usedl h []) t 
  | _ -> usedl;;

(* apply a list sl of label substitutions [x/y] *)
(* to a list ll of pairs (label * label) *)
let rec subsusedlpl lpl sl = 
  let rec subs lpl s acc =
    match lpl with
    | h::t -> 
      let (x,y) = s in
      let (l1,l2) = h in
      subs t s (acc@[((subslabel l1 x y),(subslabel l2 x y))])
    | _ -> acc
  in 
  match sl with
  | h::t -> subsusedlpl (subs lpl h []) t
  | _ -> lpl;;

(* apply a list sl of label substitutions [x/y] *)
(* to a list hccnd of pairs (F.LF * [label]) *)
let rec subshccnd hccnd sl =
  match hccnd with
  | h::t -> 
    let (lf,ll) = h in [((subslf lf sl),(subslll ll sl))]@(subshccnd t sl)
  | _ -> [];;
    
(* apply a list sl of label substitutions [x,y] *)
(*on a list usedel of pairs (exp/value * labelled_form) *)
let rec subsusedelist usedel sl =
  match usedel with
  | h::t -> let (e,lf) = h in [(e,(subslf lf sl))]@(subsusedelist t sl)
  | _ -> [];;

(* apply a list expsl of exp/value substitutions [e1,e2] *)
(* on a list of usedrl of pairs (relation * labelled_form) *)
let rec expsubsusedrl usedrl expsl =
  match usedrl with
  | h::t -> [((fst h),(F.subsexpllf (snd h) expsl))]@(expsubsusedrl t expsl)
  | _ -> [];;

(* apply a list expsl of exp/value substitutions [e1/e2] *)
(* on a list of usedel of pairs (exp/value * labelled_form) *)
let rec expsubsusedel usedel expsl =
  match usedel with
  | h::t -> [((F.subsexple (fst h) expsl),(F.subsexpllf (snd h) expsl))]@(expsubsusedel t expsl)
  | _ -> [];;

(* apply a list expsl of exp/value substitutions [e1/e2] *)
(* on a list hccnd of HC candidates (F.LF,[label]) *)
let rec expsubshccnd hccnd expsl =
  match hccnd with
  | h::t -> 
    let (lf,ll) = h in
    [((F.subsexpllf lf expsl),ll)]@(expsubshccnd t expsl)
  | _ -> [];;

(* print of a list of used pairs of relations and labelled formulae *)
let rec printusedlist usedl =
  match usedl with
  | h::t -> let (r,lf) = h in F.print_rel r;print_string " , ";F.print_lf lf;print_endline "";printusedlist t
  | _ -> ();;

(* print an unsat core *)
let rec printunsatcore unsat =
  let (fl1,fl2) = unsat in
  F.print_lfl fl1;print_string " |- ";F.print_lfl fl2;print_endline "";;

(* print hccnd *)
let rec printhccnd hccnd =
  match hccnd with
  | h::t ->let (f,ll) = h in 
    print_string "(";F.print_lf f;print_string ",";F.printlist ll;print_endline ")"
  | _ -> ();;

(*********************************************************************)
(************ The function buildptree builds derivations *************)
(*********************************************************************)

let rec buildptree seq umr uml uer ual uhc hccnd vb sh =
  if seq = F.empseq then 
    let _ = if vb = "-v" then print_endline "This branch is closed\n" else () in
    (F.NULLD,([],[])) (* end of this branch *)
  else    
    let F.SEQ(g,lf,rf) = seq in
    let seq0 = F.SEQ((M.setlist g),(M.setlist lf),(M.setlist rf)) in
    let _ = 
      if vb = "-v" then 
	(print_endline "Trying to find a derivation for the sequent: \n";
	 F.print_seq seq0; print_endline "";
	 (*print_endline "hccnd = ";printhccnd hccnd*))
      else ()
    in
    (* let testprint =  *)
    (*   let F.SEQ(g0,lf0,rf0) = seq0 in *)
    (*   print_endline "The set of leaves in this sequent is: ";F.printlist (getleaves g0);print_endline "\nThe set of roots in this sequent is: ";F.printlist (getroots g0);print_endline ("\nThe number of labels are: "^(string_of_int (List.length (getrllabels g0)))); *)
    (*   (\* print_endline "The pairs of labels with the same set of leaves are:";F.printpairlist (getisolabel g0) *\) *)
    (* in *) 
    let rec tryrules rule seq umr uml uer ual uhc hccnd =
      (*let _ = print_endline ("Tring the rule "^rule) in*)
      match rule with
      | "id" -> 
	let app = id_f seq in 
	if app = (F.NULLI,F.nulllf) then tryrules "trueR" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied id")
	    else ()
	  in 
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in 
	  (F.UD("id",seq,dev),([snd app],[snd app]))
      | "trueR" ->
	let app = truer seq in
	if app = (F.NULLI,F.nulllf) then tryrules "falseL" seq umr uml uer ual uhc hccnd
	else
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied TrueR")
	    else ()
	  in
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("trueR",seq,dev),([],[snd app]))
      | "falseL" ->
	let app = falsel seq in
	if app = (F.NULLI,F.nulllf) then tryrules "mtrueR" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied FalseL")
	    else ()
	  in
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("falseL",seq,dev),([snd app],[]))
      | "mtrueR" ->
	let app = mtruer seq in
	if app = (F.NULLI,F.nulllf) then tryrules "equalityR" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied MtrueR")
	    else ()
	  in
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("mtrueR",seq,dev),([],[snd app]))
      | "equalityR" -> 
	let app = equalityr seq in
	if app = (F.NULLI,F.nulllf) then tryrules "pointstoL1" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied =R")
	    else ()
	  in
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("equalityR",seq,dev),([],[snd app]))
      | "pointstoL1" -> 
	let app = pointstol1 seq in
	if app = (F.NULLI,F.nulllf) then tryrules "id2" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied |->L1")
	    else ()
	  in
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("pointstoL1",seq,dev),([snd app],[]))
      | "id2" ->
      	let (inf,lpf,rpf) = id2 seq in
      	if inf = F.NULLI then tryrules "ds" seq umr uml uer ual uhc hccnd
      	else
      	  let _ =
      	    if vb = "-v" then
      	      (print_endline "Applied id2")
      	    else ()
      	  in
      	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
      	  (F.UD("id2",seq,dev),([lpf],[rpf]))
      | "ds" ->
	let (inf,pfll,pflr) = inconsisds seq in 
	if inf = F.NULLI then tryrules "pointstonil" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied DS")
	    else ()
	  in
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("ds",seq,dev),(pfll,pflr))
      | "pointstonil" ->
	let app = pointstonil seq in
	if app = (F.NULLI,F.nulllf) then tryrules "sll2" seq umr uml uer ual uhc hccnd 
	else 
	  let _ = 
	    if vb = "-v" then
	      (print_endline "Applied |->nil")
	    else ()
	  in
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("pointstonil",seq,dev),([snd app],[]))
      | "sll2" -> 
	let (inf,pf) = slinkedlist2 seq in
	if inf = F.NULLI then tryrules "btr2" seq umr uml uer ual uhc hccnd 
	else 
	  let _ =
	    if vb = "-v" then
	      (print_endline "Applied LS2")
	    else ()
	  in 
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("sll2",seq,dev),([],[pf]))
      | "btr2" ->
	let (inf,pf) = btree2 seq in
	if inf = F.NULLI then tryrules "equalityL" seq umr uml uer ual uhc hccnd 
	else 
	  let _ =
	    if vb = "-v" then
	      (print_endline "Applied TR2")
	    else ()
	  in 
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("btr2",seq,dev),([],[pf]))
      | "equalityL" -> (* equalityl applies to multiple formulae each time *)
	let (nseq,expsubs,pfl) = equalityl seq in
	if expsubs = [] then tryrules "pointstoL4" seq umr uml uer ual uhc hccnd
	else if invalidexpsubl expsubs then 
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("invexpsub",seq,dev),(pfl,[]))
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied =L")
	    else ()
	  in
	  let numr = expsubsusedrl umr expsubs in
	  let numl = expsubsusedrl uml expsubs in
	  let nuer = expsubsusedel uer expsubs in
	  let nual = expsubsusedel ual expsubs in
	  let nhccnd = expsubshccnd hccnd expsubs in 
	  let (dev,unsat) = buildptree nseq numr numl nuer nual uhc nhccnd vb sh in
	  let (ul,ur) = recunsatesubs seq unsat expsubs in
	  (F.UD("equalityL",seq,dev),((M.setlist (ul@pfl)),ur))
      | "pointstoL4" -> 
	let (nseq,expsubs,pfl) = pointstol4 seq in
	if expsubs = [] then tryrules "pointstoL5" seq umr uml uer ual uhc hccnd
	else if invalidexpsubl expsubs then 
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("invexpsub",seq,dev),(pfl,[]))
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied |->L4")
	    else ()
	  in
	  let numr = expsubsusedrl umr expsubs in
	  let numl = expsubsusedrl uml expsubs in
	  let nuer = expsubsusedel uer expsubs in
	  let nual = expsubsusedel ual expsubs in
	  let nhccnd = expsubshccnd hccnd expsubs in
	  let (dev,unsat) = buildptree nseq numr numl nuer nual uhc nhccnd vb sh in
	  let (ul,ur) = recunsatesubs seq unsat expsubs in
	  (F.UD("pointstoL4",seq,dev),((M.setlist (ul@pfl)),ur))
      | "pointstoL5" ->
	let (nseq,subs,pfl) = pointstol5 seq in
	if subs = [] then tryrules "eqclose" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied |->L5")
	    else ()
	  in
	  let numr = subsusedlist umr subs in
	  let numl = subsusedlist uml subs in
	  let nuer = subsusedelist uer subs in
	  let nual = subsusedelist ual subs in
	  let nuhc = subsusedlpl uhc subs in
	  let nhccnd = subshccnd hccnd subs in
	  let (dev,unsat) = buildptree nseq numr numl nuer nual nuhc nhccnd vb sh in
	  let (ul,ur) = recunsat seq unsat subs in
	  (F.UD("pointstoL5",seq,dev),((M.setlist (ul@pfl)),ur))
      | "eqclose" -> 
	let (seq1,subs) = eqclosure seq vb in
	if subs = [] then tryrules "mtrueL" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied other structural rules with substitutions")
	    else ()
	  in
	  let numr = subsusedlist umr subs in
	  let numl = subsusedlist uml subs in
	  let nuer = subsusedelist uer subs in
	  let nual = subsusedelist ual subs in
	  let nuhc = subsusedlpl uhc subs in 
	  let nhccnd = subshccnd hccnd subs in
	  (*let _ = print_endline "numr = ";printusedlist numr;print_endline "" in
	  let _ = print_endline "numl = ";printusedlist numl;print_endline "" in*)
	  let (dev,unsat) = buildptree seq1 numr numl nuer nual nuhc nhccnd vb sh in
	  let newunsat = recunsat seq unsat subs in
	  (F.UD("eqclose",seq,dev),newunsat)
      | "mtrueL" ->
	let app = mtruel seq in
	if app = (F.NULLI,F.nulllf) then tryrules "sll1" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied MtrueL")
	    else ()
	  in
	  let F.UINF(nseq) = fst app in
	  let pf = snd app in
	  let numr = subsusedlist umr [("epsilon",(F.lb pf))] in
	  let numl = subsusedlist uml [("epsilon",(F.lb pf))] in
	  let nuer = subsusedelist uer [("epsilon",(F.lb pf))] in
	  let nual = subsusedelist ual [("epsilon",(F.lb pf))] in
	  let nuhc = subsusedlpl uhc [("epsilon",(F.lb pf))] in
	  let nhccnd = subshccnd hccnd [("epsilon",(F.lb pf))] in
	  (*let _ = print_endline "numr = ";printusedlist numr;print_endline "" in
	  let _ = print_endline "numl = ";printusedlist numl;print_endline "" in*)
	  let (dev,unsat) = buildptree (nseq) numr numl nuer nual nuhc nhccnd vb sh in
	  let (ul,ur) = recunsat seq unsat [("epsilon",(F.lb pf))] in
	  (F.UD("mtrueL",seq,dev),((M.setlist (ul@[pf])),ur))
      | "sll1" -> 
	let (inf,expsubs,pf) = slinkedlist1 seq in
	if inf = F.NULLI then tryrules "btr1" seq umr uml uer ual uhc hccnd
	else if invalidexpsubl expsubs then 
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("invexpsub",seq,dev),([pf],[]))
	else 
	  let _ = 
	    if vb = "-v" then
	      (print_endline "Applied LS1")
	    else ()
	  in 
	  let F.UINF(nseq) = inf in
	  let numr = expsubsusedrl umr expsubs in
	  let numl = expsubsusedrl uml expsubs in
	  let nuer = expsubsusedel uer expsubs in
	  let nual = expsubsusedel ual expsubs in
	  let nhccnd = expsubshccnd hccnd expsubs in
	  let (dev,unsat) = buildptree nseq numr numl nuer nual uhc nhccnd vb sh in
	  let (ul,ur) = recunsatesubs seq unsat expsubs in
	  (F.UD("sll1",seq,dev),((M.setlist (ul@[pf])),ur))
      | "btr1" -> 
	let (inf,expsubs,pf) = btree1 seq in
	if inf = F.NULLI then tryrules "andL" seq umr uml uer ual uhc hccnd 
	else if invalidexpsubl expsubs then 
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("invexpsub",seq,dev),([pf],[]))
	else 
	  let _ = 
	    if vb = "-v" then
	      (print_endline "Applied TR1")
	    else ()
	  in 
	  let F.UINF(nseq) = inf in
	  let numl = expsubsusedrl umr expsubs in
	  let numr = expsubsusedrl uml expsubs in
	  let nuer = expsubsusedel uer expsubs in
	  let nual = expsubsusedel ual expsubs in
	  let nhccnd = expsubshccnd hccnd expsubs in
	  let (dev,unsat) = buildptree nseq numr numl nuer nual uhc nhccnd vb sh in
	  let (ul,ur) = recunsatesubs seq unsat expsubs in
	  (F.UD("btr1",seq,dev),((M.setlist (ul@[pf])),ur))
      | "andL" ->
	let app = andl seq in
	if app = (F.NULLI,F.nulllf) then tryrules "impR" seq umr uml uer ual uhc hccnd
	else
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied &L")
	    else ()
	  in
	  let F.UINF(nseq) = fst app in
	  let pf = snd app in
	  let (dev,unsat) = (buildptree (nseq) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat then (F.UD("andL",seq,dev),unsat)
	  else (F.UD("andL",seq,dev),(nextunsat_u "andL" pf F.nullr unsat))
      | "impR" ->
	let app = impr seq in
	if app = (F.NULLI,F.nulllf) then tryrules "notL" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied ->R")
	    else ()
	  in
	  let F.UINF(nseq) = fst app in
	  let pf = snd app in
	  let (dev,unsat) = (buildptree (nseq) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat then (F.UD("impR",seq,dev),unsat)
	  else (F.UD("impR",seq,dev),(nextunsat_u "impR" pf F.nullr unsat))
      | "notL" ->
	let app = notl seq in 
	if app = (F.NULLI,F.nulllf) then tryrules "notR" seq umr uml uer ual uhc hccnd
	else
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied ~L")
	    else ()
	  in
	  let F.UINF(nseq) = fst app in
	  let pf = snd app in
	  let (dev,unsat) = (buildptree (nseq) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat then (F.UD("notL",seq,dev),unsat)
	  else (F.UD("notL",seq,dev),(nextunsat_u "notL" pf F.nullr unsat))
      | "notR" ->
	let app = notr seq in 
	if app = (F.NULLI,F.nulllf) then tryrules "orR" seq umr uml uer ual uhc hccnd
	else
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied ~R")
	    else ()
	  in
	  let F.UINF(nseq) = fst app in
	  let pf = snd app in
	  let (dev,unsat) = (buildptree (nseq) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat then (F.UD("notR",seq,dev),unsat)
	  else (F.UD("notR",seq,dev),(nextunsat_u "notR" pf F.nullr unsat))
      | "orR" ->
	let app = orr seq in
	if app = (F.NULLI,F.nulllf) then tryrules "mandL" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied |R")
	    else ()
	  in
	  let F.UINF(nseq) = fst app in
	  let pf = snd app in
	  let (dev,unsat) = (buildptree (nseq) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat then (F.UD("orR",seq,dev),unsat)
	  else (F.UD("orR",seq,dev),(nextunsat_u "orR" pf F.nullr unsat))
      | "mandL" ->
	let app = mandl seq in
	if app = (F.NULLI,(F.nullr,F.nulllf)) then tryrules "mimpR" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied *L")
	    else ()
	  in
	  let F.UINF(nseq) = fst app in
	  let (r,pf) = snd app in
	  let (dev,unsat) = (buildptree (nseq) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat then (F.UD("mandL",seq,dev),unsat)
	  else (F.UD("mandL",seq,dev),(nextunsat_u "mandL" pf r unsat))
      | "mimpR" ->  
	if sh = "-sh" then (* don't apply this rule *)
	  tryrules "existsL" seq umr uml uer ual uhc hccnd
	else 
	  let app = mimpr seq in
	  if app = (F.NULLI,(F.nullr,F.nulllf)) then tryrules "existsL" seq umr uml uer ual uhc hccnd
	  else 
	    let _ = 
	      if vb = "-v" then 
		(print_endline "Applied -*R")
	      else ()
	    in
	    let F.UINF(nseq) = fst app in
	    let (r,pf) = snd app in
	    let (dev,unsat) = (buildptree (nseq) umr uml uer ual uhc hccnd vb sh) in
	    if containsunsat seq unsat then (F.UD("mimpR",seq,dev),unsat)
	    else (F.UD("mimpR",seq,dev),(nextunsat_u "mimpR" pf r unsat))
      | "existsL" -> 
	let app = existsl seq in
	if app = (F.NULLI,("",F.nulllf)) then tryrules "forallR" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied ExistsL")
	    else ()
	  in
	  let F.UINF(nseq) = fst app in
	  let (v,pf) = snd app in
	  let (dev,unsat) = (buildptree (nseq) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat then (F.UD("existsL",seq,dev),unsat)
	  else (F.UD("existsL",seq,dev),(nextunsat_qt "existsL" pf v unsat))
      | "forallR" -> 
	let app = forallr seq in
	if app = (F.NULLI,("",F.nulllf)) then tryrules "sll3" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied ForallR")
	    else ()
	  in
	  let F.UINF(nseq) = fst app in
	  let (v,pf) = snd app in
	  let (dev,unsat) = (buildptree (nseq) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat then (F.UD("forallR",seq,dev),unsat)
	  else (F.UD("forallR",seq,dev),(nextunsat_qt "forallR" pf v unsat))
      | "sll3" -> 
	let (inf,pf) = slinkedlist3 seq in
	if inf = F.NULLI then tryrules "sll4" seq umr uml uer ual uhc hccnd
	else 
	  let _ =
	    if vb = "-v" then
	      (print_endline "Applied LS3")
	    else ()
	  in 
	  let F.UINF(nseq) = inf in
	  let (dev,unsat) = buildptree nseq umr uml uer ual uhc hccnd vb sh in
	  if containsunsat seq unsat then (F.UD("sll3",seq,dev),unsat)
	  else
	    let (ul,ur) = unsat in 
	    (F.UD("sll3",seq,dev),((M.setlist ((M.subtalllist (F.LF((F.lb pf),F.MTRUE)) ul)@[pf])),ur))
      | "sll4" -> 
	let (inf,expsubs,pf) = slinkedlist4 seq in
	if inf = F.NULLI then tryrules "sll6" seq umr uml uer ual uhc hccnd 
	else if invalidexpsubl expsubs then 
	  let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	  (F.UD("invexpsub",seq,dev),([pf],[]))  
	else 
	  let _ = 
	    if vb = "-v" then
	      (print_endline "Applied LS4")
	    else ()
	  in 
	  let F.UINF(nseq) = inf in
	  let numr = expsubsusedrl umr expsubs in
	  let numl = expsubsusedrl uml expsubs in
	  let nuer = expsubsusedel uer expsubs in
	  let nual = expsubsusedel ual expsubs in
	  let nhccnd = expsubshccnd hccnd expsubs in
	  let (dev,unsat) = buildptree nseq numr numl nuer nual uhc nhccnd vb sh in
	  let (ul,ur) = recunsatesubs seq unsat expsubs in
	  (F.UD("sll4",seq,dev),((M.setlist ((M.subtalllist (F.LF((F.lb pf),F.MTRUE)) ul)@[pf])),ur))
      | "sll6" -> 
	let (inf,pfl,nf) = slinkedlist6 seq in
	if inf = F.NULLI then tryrules "sll7" seq umr uml uer ual uhc hccnd 
	else 
	  let _ =
	    if vb = "-v" then
	      (print_endline "Applied LS6")
	    else ()
	  in 
	  let F.UINF(nseq) = inf in
	  let (dev,unsat) = buildptree nseq umr uml uer ual uhc hccnd vb sh in
	  if containsunsat seq unsat then (F.UD("sll6",seq,dev),unsat)
	  else 
	    let (ul,ur) = unsat in
	    (F.UD("sll6",seq,dev),((M.setlist ((M.subtalllist nf ul)@pfl)),ur))
      | "sll7" ->
	let (inf,pfl,nf) = slinkedlist7 seq in
	if inf = F.NULLI then tryrules "sll8" seq umr uml uer ual uhc hccnd 
	else 
	  let _ = 
	    if vb = "-v" then
	      (print_endline "Applied LS7")
	    else ()
	  in 
	  let F.UINF(nseq) = inf in
	  let (dev,unsat) = buildptree nseq umr uml uer ual uhc hccnd vb sh in
	  if containsunsat seq unsat then (F.UD("sll7",seq,dev),unsat)
	  else 
	    let (ul,ur) = unsat in
	    (F.UD("sll7",seq,dev),((M.setlist ((M.subtalllist nf ul)@pfl)),ur))
      | "sll8" -> 
	let (inf,pfll,pflr,nf) = slinkedlist8 seq in
	if inf = F.NULLI then tryrules "btr3" seq umr uml uer ual uhc hccnd 
	else 
	  let _ = 
	    if vb = "-v" then
	      (print_endline "Applied LS8")
	    else ()
	  in 
	  let F.UINF(nseq) = inf in
	  let (dev,unsat) = buildptree nseq umr uml uer ual uhc hccnd vb sh in
	  if containsunsat seq unsat then (F.UD("sll8",seq,dev),unsat)
	  else 
	    let (ul,ur) = unsat in 
	    (F.UD("sll8",seq,dev),((M.setlist (ul@pfll)),(M.setlist ((M.subtalllist nf ur)@pflr))))
      | "btr3" -> 
	let (inf,pf) = btree3 seq in
	if inf = F.NULLI then tryrules "btr5" seq umr uml uer ual uhc hccnd 
	else 
	  let _ = 
	    if vb = "-v" then
	      (print_endline "Applied TR3")
	    else ()
	  in 
	  let F.UINF(nseq) = inf in
	  let (dev,unsat) = buildptree nseq umr uml uer ual uhc hccnd vb sh in
	  if containsunsat seq unsat then (F.UD("btr3",seq,dev),unsat)
	  else 
	    let (ul,ur) = unsat in
	    (F.UD("btr3",seq,dev),((M.setlist ((M.subtalllist (F.LF((F.lb pf),F.MTRUE)) ul)@[pf])),ur))
      | "btr5" -> 
	let (inf,pfl,nf) = btree5 seq in
	if inf = F.NULLI then tryrules "btr6" seq umr uml uer ual uhc hccnd 
	else 
	  let _ =
	    if vb = "-v" then
	      (print_endline "Applied TR5")
	    else ()
	  in 
	  let F.UINF(nseq) = inf in
	  let (dev,unsat) = buildptree nseq umr uml uer ual uhc hccnd vb sh in
	  if containsunsat seq unsat then (F.UD("btr5",seq,dev),unsat)
	  else 
	    let (ul,ur) = unsat in
	    (F.UD("btr5",seq,dev),((M.setlist ((M.subtalllist nf ul)@pfl)),ur))
      | "btr6" ->
	let (inf,lpf,rpf,nf) = btree6 seq in
	if inf = F.NULLI then tryrules "mimpL_q" seq umr uml uer ual uhc hccnd 
	else 
	  let _ = 
	    if vb = "-v" then
	      (print_endline "Applied TR6")
	    else ()
	  in 
	  let F.UINF(nseq) = inf in
	  let (dev,unsat) = buildptree nseq umr uml uer ual uhc hccnd vb sh in
	  if containsunsat seq unsat then (F.UD("btr6",seq,dev),unsat)
	  else 
	    let (ul,ur) = unsat in
	    (F.UD("btr6",seq,dev),((M.setlist (ul@[lpf])),(M.setlist ((M.subtalllist nf ur)@[rpf]))))
      | "mimpL_q" ->
	let app = quick_mimpl seq uml in 
	if app = (F.NULLI,(F.nullr,F.nulllf,F.nulllf)) then tryrules "pointstoL2" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then
	      (print_endline "Applied -*L (fast)")
	    else ()
	  in 
	  let F.UINF(nseq) = fst app in
	  let (r,pf,nf) = snd app in
	  let numl = uml@[(r,pf)] in
	  let (dev,(ul,ur)) = buildptree nseq umr numl uer ual uhc hccnd vb sh in
	  let nunsat = 
	    if List.mem nf ul then (((M.subtlist nf ul)@[pf]),ur) else (ul,ur)
	  in 
	  (F.UD("mimpL_q",seq,dev),nunsat)
      | "pointstoL2" -> 
	let app = pointstol2 seq in
	if app = (F.NULLI,(F.nullr,F.nulllf)) then tryrules "sll5" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied |->L2")
	    else ()
	  in
	  let (F.BINF(nseq1,nseq2),(F.RT(l1,l2,l3),pf)) = app in
	  let numr1 = subsusedlist umr [("epsilon",l1)] in
	  let numl1 = subsusedlist uml [("epsilon",l1)] in
	  let nuer1 = subsusedelist uer [("epsilon",l1)] in
	  let nual1 = subsusedelist ual [("epsilon",l1)] in
	  let nuhc1 = subsusedlpl uhc [("epsilon",l1)] in
	  let nhccnd1 = subshccnd hccnd [("epsilon",l1)] in
	  let numr2 = subsusedlist umr [("epsilon",l2)] in
	  let numl2 = subsusedlist uml [("epsilon",l2)] in
	  let nuer2 = subsusedelist uer [("epsilon",l2)] in
	  let nual2 = subsusedelist ual [("epsilon",l2)] in
	  let nuhc2 = subsusedlpl uhc [("epsilon",l2)] in
	  let nhccnd2 = subshccnd hccnd [("epsilon",l2)] in
	  let (dev1,unsat1) = (buildptree (nseq1) numr1 numl1 nuer1 nual1 nuhc1 nhccnd1 vb sh) in
	  let (newunsat1l,newunsat1r) = recunsat seq unsat1 [("epsilon",l1)] in
	  let (dev2,unsat2) = (buildptree (nseq2) numr2 numl2 nuer2 nual2 nuhc2 nhccnd2 vb sh) in
	  let (newunsat2l,newunsat2r) = recunsat seq unsat2 [("epsilon",l2)] in
	  let newunsat = ((M.setlist (newunsat1l@newunsat2l@[pf])),(M.setlist (newunsat1r@newunsat2r))) in
	  (F.BD("pointstoL2",seq,dev1,dev2),newunsat)
      (* | "sll5" -> *)
      (* 	let (inf,expsubs,lsubs,pfl) = slinkedlist5 seq in *)
      (* 	if inf = F.NULLI then tryrules "sll5" seq umr uml uer ual uhc hccnd  *)
      (* 	else  *)
      (* 	  let _ =  *)
      (* 	    if vb = "-v" then *)
      (* 	      (print_endline "Applied LS5") *)
      (* 	    else () *)
      (* 	  in *)
      (* 	  let F.BINF(nseq1,nseq2) = inf in *)
      (* 	  if invalidexpsubl expsubs then (\* left branch is closed*\) *)
      (* 	    let (dev1,unsat1) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in *)
      (* 	    let ful1 = pfl in *)
      (* 	    let fur1 = [] in *)
      (* 	    let numr2 = subsusedlist umr lsubs in *)
      (* 	    let numl2 = subsusedlist uml lsubs in *)
      (* 	    let nuer2 = subsusedelist uer lsubs in *)
      (* 	    let nual2 = subsusedelist ual lsubs in *)
      (* 	    let nuhc2 = subsusedlpl uhc lsubs in *)
      (* 	    let nhccnd2 = subshccnd hccnd lsubs in   *)
      (* 	    let (dev2,unsat2) = buildptree nseq2 numr2 numl2 nuer2 nual2 nuhc2 nhccnd2 vb sh in *)
      (* 	    let (nul2,nur2) = recunsat seq unsat2 lsubs in *)
      (* 	    let (ful2,fur2) = ((nul2@pfl),nur2) in *)
      (* 	    (F.BD("sll5",seq,dev1,dev2),((M.setlist (ful1@ful2)),(M.setlist (fur1@fur2)))) *)
      (* 	  else  *)
      (* 	    let [pf1;pf2] = pfl in *)
      (* 	    let numr1 = expsubsusedrl umr expsubs in *)
      (* 	    let numl1 = expsubsusedrl uml expsubs in *)
      (* 	    let nuer1 = expsubsusedel uer expsubs in *)
      (* 	    let nual1 = expsubsusedel ual expsubs in *)
      (* 	    let nhccnd1 = expsubshccnd hccnd expsubs in *)
      (* 	    let numr2 = subsusedlist umr lsubs in *)
      (* 	    let numl2 = subsusedlist uml lsubs in *)
      (* 	    let nuer2 = subsusedelist uer lsubs in *)
      (* 	    let nual2 = subsusedelist ual lsubs in *)
      (* 	    let nuhc2 = subsusedlpl uhc lsubs in *)
      (* 	    let nhccnd2 = subshccnd hccnd lsubs in *)
      (* 	    let (dev1,unsat1) = buildptree nseq1 numr1 numl1 nuer1 nual1 uhc nhccnd1 vb sh in *)
      (* 	    let (nul1,nur1) = recunsatesubs seq unsat1 expsubs in *)
      (* 	    let nul1t = M.subtalllist (F.LF((F.lb pf2),F.MTRUE)) (M.subtalllist (F.LF((F.lb pf1),F.MTRUE)) nul1) in *)
      (* 	    let (ful1,fur1) = ((nul1t@pfl),nur1) in  *)
      (* 	    let (dev2,unsat2) = buildptree nseq2 numr2 numl2 nuer2 nual2 nuhc2 nhccnd2 vb sh in *)
      (* 	    let (nul2,nur2) = recunsat seq unsat2 lsubs in *)
      (* 	    let (ful2,fur2) = ((nul2@pfl),nur2) in *)
      (* 	    (F.BD("sll5",seq,dev1,dev2),((M.setlist (ful1@ful2)),(M.setlist (fur1@fur2)))) *)
      | "sll5" ->
	let (inf,expsubsl,expsubsr,pfl) = slinkedlist5 seq in
	if inf = F.NULLI then tryrules "btr4" seq umr uml uer ual uhc hccnd 
	else 
	  let _ = 
	    if vb = "-v" then
	      (print_endline "Applied LS5")
	    else ()
	  in
	  let F.BINF(nseq1,nseq2) = inf in
	  let [pf1;pf2] = pfl in
	  if invalidexpsubl expsubsl && invalidexpsubl expsubsr then (* both branch are closed *)
	    let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	    (F.UD("invexpsub",seq,dev),(pfl,[]))
	  else if invalidexpsubl expsubsl then (* left branch is closed *)
	    let (dev1,unsat1) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	    let ful1 = pfl in
	    let fur1 = [] in
	    let numr2 = expsubsusedrl umr expsubsr in
	    let numl2 = expsubsusedrl uml expsubsr in
	    let nuer2 = expsubsusedel uer expsubsr in
	    let nual2 = expsubsusedel ual expsubsr in
	    let nhccnd2 = expsubshccnd hccnd expsubsr in
            let (dev2,unsat2) = buildptree nseq2 numr2 numl2 nuer2 nual2 uhc nhccnd2 vb sh in
	    let (nul2,nur2) = recunsatesubs seq unsat2 expsubsr in
	    let (ful2,fur2) = ((nul2@pfl),nur2) in
	    (F.BD("sll5",seq,dev1,dev2),((M.setlist (ful1@ful2)),(M.setlist (fur1@fur2))))
	  else if invalidexpsubl expsubsr then (* right branch is closed *)
	    let numr1 = expsubsusedrl umr expsubsl in
	    let numl1 = expsubsusedrl uml expsubsl in
	    let nuer1 = expsubsusedel uer expsubsl in
	    let nual1 = expsubsusedel ual expsubsl in
	    let nhccnd1 = expsubshccnd hccnd expsubsl in
	    let (dev1,unsat1) = buildptree nseq1 numr1 numl1 nuer1 nual1 uhc nhccnd1 vb sh in
	    let (nul1,nur1) = recunsatesubs seq unsat1 expsubsl in
	    let nul1t = M.subtalllist (F.LF((F.lb pf1),F.MTRUE)) nul1 in
	    let (ful1,fur1) = ((nul1t@pfl),nur1) in
	    let ful2 = pfl in
	    let fur2 = [] in
	    let (dev2,unsat2) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	    (F.BD("sll5",seq,dev1,dev2),((M.setlist (ful1@ful2)),(M.setlist (ful2@fur2))))
	  else 
	    let numr1 = expsubsusedrl umr expsubsl in
	    let numl1 = expsubsusedrl uml expsubsl in
	    let nuer1 = expsubsusedel uer expsubsl in
	    let nual1 = expsubsusedel ual expsubsl in
	    let nhccnd1 = expsubshccnd hccnd expsubsl in
	    let numr2 = expsubsusedrl umr expsubsr in
	    let numl2 = expsubsusedrl uml expsubsr in
	    let nuer2 = expsubsusedel uer expsubsr in
	    let nual2 = expsubsusedel ual expsubsr in
	    let nhccnd2 = expsubshccnd hccnd expsubsr in
	    let (dev1,unsat1) = buildptree nseq1 numr1 numl1 nuer1 nual1 uhc nhccnd1 vb sh in
	    let (nul1,nur1) = recunsatesubs seq unsat1 expsubsl in
	    let nul1t = M.subtalllist (F.LF((F.lb pf1),F.MTRUE)) nul1 in
	    let (ful1,fur1) = ((nul1t@pfl),nur1) in
	    let (dev2,unsat2) = buildptree nseq2 numr2 numl2 nuer2 nual2 uhc nhccnd2 vb sh in
	    let (nul2,nur2) = recunsatesubs seq unsat2 expsubsr in
	    let (ful2,fur2) = ((nul2@pfl),nur2) in
	    (F.BD("sll5",seq,dev1,dev2),((M.setlist (ful1@ful2)),(M.setlist (ful2@fur2))))
      | "btr4" -> 
	let (inf,expsubs,pfl) = btree4 seq in
	if inf = F.NULLI then tryrules "andR" seq umr uml uer ual uhc hccnd 
	else 
	  let _ =
	    if vb = "-v" then
	      (print_endline "Applied TR4")
	    else ()
	  in
	  let F.UINF(nseq) = inf in
	  let [pf1;pf2] = pfl in
	  if invalidexpsubl expsubs then (* close the branch *)
	    let (dev,unsat) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	    (F.UD("invexpsub",seq,dev),(pfl,[]))
	  else 
	    let numr = expsubsusedrl umr expsubs in
	    let numl = expsubsusedrl uml expsubs in
	    let nuer = expsubsusedel uer expsubs in
	    let nual = expsubsusedel ual expsubs in
	    let nhccnd = expsubshccnd hccnd expsubs in
            let (dev,unsat) = buildptree nseq numr numl nuer nual uhc nhccnd vb sh in
	    let (nul,nur) = recunsatesubs seq unsat expsubs in
	    let (ful,fur) = ((nul@pfl),nur) in
	    (F.UD("btr4",seq,dev),((M.setlist ful),(M.setlist fur)))
      | "andR" ->
	let app = andr seq in
	if app = (F.NULLI,F.nulllf) then tryrules "orL" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied &R")
	    else ()
	  in
	  let F.BINF(nseq1,nseq2) = fst app in
	  let pf = snd app in
	  let (dev1,unsat1) = (buildptree (nseq1) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat1 then (F.BD("andR",seq,dev1,F.backjump),unsat1)
	  else 
	    let (dev2,unsat2) = (buildptree (nseq2) umr uml uer ual uhc hccnd vb sh) in
	    if containsunsat seq unsat2 then (F.BD("andR",seq,dev1,dev2),unsat2)
	    else (F.BD("andR",seq,dev1,dev2),(nextunsat_b "andR" pf F.nullr unsat1 unsat2))
      | "orL" ->
	let app = orl seq in
	if app = (F.NULLI,F.nulllf) then tryrules "impL" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied |L")
	    else ()
	  in
	  let F.BINF(nseq1,nseq2) = fst app in
	  let pf = snd app in
	  let (dev1,unsat1) = (buildptree (nseq1) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat1 then (F.BD("orL",seq,dev1,F.backjump),unsat1)
	  else 
	    let (dev2,unsat2) = (buildptree (nseq2) umr uml uer ual uhc hccnd vb sh) in
	    if containsunsat seq unsat2 then (F.BD("orL",seq,dev1,dev2),unsat2)
	    else (F.BD("orL",seq,dev1,dev2),(nextunsat_b "orL" pf F.nullr unsat1 unsat2))
      | "impL" ->
	let app = impl seq in
	if app = (F.NULLI,F.nulllf) then tryrules "mandR_q" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied ->L")
	    else ()
	  in
	  let F.BINF(nseq1,nseq2) = fst app in
	  let pf = snd app in
	  let (dev1,unsat1) = (buildptree (nseq1) umr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat1 then (F.BD("impL",seq,dev1,F.backjump),unsat1)
	  else 
	    let (dev2,unsat2) = (buildptree (nseq2) umr uml uer ual uhc hccnd vb sh) in
	    if containsunsat seq unsat2 then (F.BD("impL",seq,dev1,dev2),unsat2)
	    else (F.BD("impL",seq,dev1,dev2),(nextunsat_b "impL" pf F.nullr unsat1 unsat2))
      | "mandR_q" -> 
	let app = quick_mandr2 seq umr in
	if app = (F.NULLI,(F.nullr,F.nulllf)) then tryrules "noninvert" seq umr uml uer ual uhc hccnd
	else 
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied *R (fast)")
	    else ()
	  in
	  let F.BINF(nseq1,nseq2) = fst app in
	  let (r,pf) = snd app in
	  let numr = umr@[snd app] in
	  (*let _ = print_endline "numr = ";printusedlist numr;print_endline "" in*)
	  let (dev1,unsat1) = (buildptree (nseq1) numr uml uer ual uhc hccnd vb sh) in
	  if containsunsat seq unsat1 then (F.BD("mandR_q",seq,dev1,F.backjump),unsat1)
	  else 
	    let (dev2,unsat2) = (buildptree (nseq2) numr uml uer ual uhc hccnd vb sh) in
	    if containsunsat seq unsat2 then (F.BD("mandR_q",seq,dev1,dev2),unsat2)
	    else (F.BD("mandR_q",seq,dev1,dev2),(nextunsat_b "mandR" pf r unsat1 unsat2))
      | "noninvert" ->
	let applymandr seq umr =
	  let app = mandr seq umr in
	  if app = (F.NULLI,(F.nullr,F.nulllf)) then (F.NULLD,([],[]))
	  else 
	    let _ = 
	      if vb = "-v" then 
		(print_endline "Applied *R")
	      else ()
	    in
	    let F.BINF(nseq1,nseq2) = fst app in
	    let (r,pf) = snd app in
	    let numr = umr@[(r,pf)] in
	  (*let _ = print_endline "numr = ";printusedlist numr;print_endline "" in*)
	    let (dev1,unsat1) = buildptree nseq1 numr uml uer ual uhc hccnd vb sh in
	    if containsunsat seq unsat1 then (F.BD("mandR",seq,dev1,F.backjump),unsat1)
	    else 
	      let (dev2,unsat2) = buildptree nseq2 numr uml uer ual uhc hccnd vb sh in
	      if containsunsat seq unsat2 then (F.BD("mandR",seq,dev1,dev2),unsat2)
	      else (F.BD("mandR",seq,dev1,dev2),(nextunsat_b "mandR" pf r unsat1 unsat2))
	in 
	let applymimpl seq uml = 
	  let app = mimpl seq uml in
	  if app = (F.NULLI,(F.nullr,F.nulllf)) then (F.NULLD,([],[]))
	  else 
	    let _ = 
	      if vb = "-v" then 
		(print_endline "Applied -*L")
	      else ()
	    in
	    let F.BINF(nseq1,nseq2) = fst app in
	    let (r,pf) = snd app in
	    let numl = uml@[(r,pf)] in
	  (*let _ = print_endline "numl = ";printusedlist numl;print_endline "" in*)
	    let (dev1,unsat1) = buildptree nseq1 umr numl uer ual uhc hccnd vb sh in
	    if containsunsat seq unsat1 then (F.BD("mimpL",seq,dev1,F.backjump),unsat1)
	    else 
	      let (dev2,unsat2) = buildptree nseq2 umr numl uer ual uhc hccnd vb sh in
	      if containsunsat seq unsat2 then (F.BD("mimpL",seq,dev1,dev2),unsat2)
	      else (F.BD("mimpL",seq,dev1,dev2),(nextunsat_b "mimpL" pf r unsat1 unsat2))
	in
	let applyexistsr1 seq uer =
	  let app = existsr1 seq uer in
	  if app = (F.NULLI,("",F.nulllf)) then (F.NULLD,([],[]))
	  else 
	    let _ = 
	      if vb = "-v" then 
		(print_endline "Applied ExistsR (choose existing expressions)")
	      else ()
	    in
	    let F.UINF(nseq) = fst app in
	    let (v,pf) = snd app in
	    let nuer = uer@[(v,pf)] in
	    let (dev,unsat) = buildptree nseq umr uml nuer ual uhc hccnd vb sh in
	    if containsunsat seq unsat then (F.UD("existsR",seq,dev),unsat)
	    else (F.UD("existsR",seq,dev),(nextunsat_qt "existsR" pf v unsat))
	in
	let applyforalll1 seq ual =
	  let app = foralll1 seq ual in
	  if app = (F.NULLI,("",F.nulllf)) then (F.NULLD,([],[]))
	  else
	    let _ = 
	      if vb = "-v" then 
		(print_endline "Applied ForallL (choose existing expressions)")
	      else ()
	    in
	    let F.UINF(nseq) = fst app in
	    let (v,pf) = snd app in
	    let nual = ual@[(v,pf)] in
	    let (dev,unsat) = buildptree nseq umr uml uer nual uhc hccnd vb sh in
	    if containsunsat seq unsat then (F.UD("forallL",seq,dev),unsat)
	    else (F.UD("forallL",seq,dev),(nextunsat_qt "forallL" pf v unsat))
	in
	let applyninvrules num seq umr uml uer ual =
	  if num = 0 then (* apply mandr *)
	    applymandr seq umr 
	  else if num = 1 then (* apply mimpl *)
	    applymimpl seq uml 
	  else if num = 2 then (* apply existsr1 *)
	    applyexistsr1 seq uer
	  else if num = 3 then (* apply foralll1 *)
	    applyforalll1 seq ual
	  else failwith "applyninvrules(): undefined rules!\n"
	in  
	let rec applyninv chosen rnum seq umr uml uer ual = 
	  if chosen <> -1 && (not(sh = "-sh") || not(List.mem rnum [1;3])) then (* apply the chosen one *)
	    let (dev,unsat) = applyninvrules chosen seq umr uml uer ual in
	    if dev = F.NULLD then
	      applyninv (-1) rnum seq umr uml uer ual
	    else (dev,unsat)
	  else (* the chosen app doesn't work *)
	    if rnum < 4 then (* try the 4 non-invertible rules *)
	      (* don't apply the chosen rule again, and *)
	      (* if sh = "-sh", don't apply mimpl and foralll1 *)
	      if rnum <> chosen && (not(sh = "-sh") || not(List.mem rnum [1;3])) then 
		let (dev,unsat) = applyninvrules rnum seq umr uml uer ual in
		if dev = F.NULLD then
		  applyninv (-1) (rnum+1) seq umr uml uer ual
		else (dev,unsat)
	      else applyninv (-1) (rnum+1) seq umr uml uer ual
	    else tryrules "cs" seq umr uml uer ual uhc hccnd
	in 
	let rand = Random.int 3 in 
	applyninv rand 0 seq umr uml uer ual
      | "cs" ->
	if sh = "-sh" then (* don't apply this rule *)
	  tryrules "str" seq umr uml uer ual uhc hccnd
	else 
	  let app = cs seq in
	  if app = F.NULLI then tryrules "str" seq umr uml uer ual uhc hccnd
	  else
	    let _ = 
	      if vb = "-v" then 
		(print_endline "Applied CS")
	      else ()
	    in
	    let F.UINF(nseq) = app in 
	    let (dev,unsat) = buildptree nseq umr uml uer ual uhc hccnd vb sh in
	    (F.UD("cs",seq,dev),unsat)
      | "str" -> (* compute an iteration of structural rules U',E *)
	let F.UINF(seq1) = comm seq in
	let F.UINF(seq2) = assoc seq1 in
	let F.UINF(seq3) = comm seq2 in
	let F.UINF(seq4) = unit seq3 in
	let F.SEQ(g,lf,rf) = seq in
	let F.SEQ(g4,lf4,rf4) = seq4 in
	if M.equalsetlist g g4 then (* structural rules are not applicable *)
	  tryrules "others" seq umr uml uer ual uhc hccnd
	  (*(F.UD("NORULE",F.empseq,F.NULLD),([],[]))*)
	else
	  let _ = 
	    if vb = "-v" then 
	      (print_endline "Applied a round of E,A,E,U")
	    else ()
	  in
	  let (dev,unsat) = buildptree seq4 umr uml uer ual uhc hccnd vb sh in
	  (F.UD("str",seq,dev),unsat)
      | _ -> (*(F.UD("NORULE",F.empseq,F.NULLD),([],[]))*)
	(* apply HE, HC, existsR2, forallL2, and cut= here *)
	let applyrhe seq uml hccnd = 
	  let (inf,pf,nfl) = restrictedhe seq uml in
	  if inf = F.NULLI then 
	    (F.NULLD,([],[]))
	  else (* applied HE *) 
	    let _ =
	      if vb = "-v" then
		(print_endline "Applied HE")
	      else ()
	    in
	    let F.UINF(nseq) = inf in
	    (* mark this -* formula as applied with HE *)
	    let numl = uml@[(F.nullr,pf)] in
	    let F.SEQ(ng,nlf,nrf) = nseq in
	    let ptsubflabels = psubflabels pf nlf in
	    let nhccnd = hccnd@[(pf,((getfllabels nfl)@ptsubflabels))] in
	    let (dev,unsat) = buildptree nseq umr numl uer ual uhc nhccnd vb sh in
	    let (ul,ur) = recunsath seq unsat in 
	    (* pf may not necessary to be in the unsat core *)
	    (F.UD("rhe",seq,dev),((ul@[pf]),ur))
	in (* forbid h labels being substituted by non-h labels. write an unrestricted hc app that combines any two h labels *)
	let applyhc seq uml uhc hccnd = 
	  (* pick a random -*L formula *)
	  let usefulhccnd = filterhccnd hccnd uml in
	  if (List.length usefulhccnd) <= 0 then 
	  (* no labels created by H,HE, don't apply HC on this sequent *)
	    (F.NULLD,([],[]))
	  else 
	    let F.SEQ(g,lf,rf) = seq in
	    (*let rand2 = Random.int mlfnum in*)
	    let randhccnd = M.rand_listmem usefulhccnd in
	    let pf = fst randhccnd in
	    let hccndlabels = (snd randhccnd)@[F.lb pf] in
	    let (l1,l2) = randhcapp g hccndlabels uhc in
	    (*let testprint = print_endline ("l1 = "^l1^"; l2 = "^l2) in*)
	    if l1 <> "-1" && l2 <> "-1" then 
	      let _ =
		if vb = "-v" then
		  (print_endline "Applied HC")
		else ()
	      in 
	      let ((nseq1,nseq2),nl) = combhps l1 l2 seq in
	      (* insert nl into proper place in hccnd *)
	      let nhccnd = addlhccnd hccnd pf nl in
	      let (dev1,unsat1) = buildptree nseq1 umr uml uer ual (uhc@[(l1,l2)]) hccnd vb sh in
	      let (dev2,unsat2) = buildptree nseq2 umr uml uer ual (uhc@[(l1,l2)]) nhccnd vb sh in
	      let nunsat1 = recunsath seq unsat1 in
	      (* pf may not necessary to be in the unsat core *)
	      (F.BD("hc",seq,dev1,dev2),((M.setlist ((fst nunsat1)@(fst unsat2)@[pf])),(M.setlist ((snd nunsat1)@(snd unsat2)))))
	    else
	      (* can't find candidates from pf doesn't mean there are *)
	      (* no other -*L formulae. Keep searching, add pf to "used for HC" *)
	      tryrules "others" seq umr (uml@[(F.nullr2,pf)]) uer ual uhc hccnd 
	in 
	let applyer2 seq uer =
	  let app = existsr2 seq in
	  if app = (F.NULLI,("",F.nulllf)) then (F.NULLD,([],[]))
	    (*(F.UD("NORULE",seq,F.NULLD),([],[]))*)
	  else 
	    let _ = 
	      if vb = "-v" then 
		(print_endline "Applied ExistsR (use fresh expression)")
	      else ()
	    in
	    let F.UINF(nseq) = fst app in
	    let (v,pf) = snd app in
	    let nuer = uer@[(v,pf)] in
	    let (dev,unsat) = buildptree nseq umr uml nuer ual uhc hccnd vb sh in
	    if containsunsat seq unsat then (F.UD("existsR",seq,dev),unsat)
	    else (F.UD("existsR",seq,dev),(nextunsat_qt "existsR" pf v unsat))
	in
	let applyal2 seq ual =
	  let app = foralll2 seq in
	  if app = (F.NULLI,("",F.nulllf)) then (F.NULLD,([],[]))
	  else
	    let _ = 
	      if vb = "-v" then 
		(print_endline "Applied ForallL (use fresh expression)")
	      else ()
	    in
	    let F.UINF(nseq) = fst app in
	    let (v,pf) = snd app in
	    let nual = ual@[(v,pf)] in
	    let (dev,unsat) = buildptree nseq umr uml uer nual uhc hccnd vb sh in
	    if containsunsat seq unsat then (F.UD("forallL",seq,dev),unsat)
	    else (F.UD("forallL",seq,dev),(nextunsat_qt "forallL" pf v unsat))
	in
	let applycuteq seq =
	  let (inf,expsubs,nf) = cuteq seq in
	  if inf = F.NULLI then (F.NULLD,([],[]))
	  else 
	    let _ =
	      if vb = "-v" then
		(print_endline "Applied Cut=")
	      else ()
	    in
	    let F.BINF(nseq1,nseq2) = inf in
	    if invalidexpsubl expsubs then (* left branch is closed*)
	      let (dev1,unsat1) = buildptree F.empseq umr uml uer ual uhc hccnd vb sh in
	      let nul1 = [] in
	      let nur1 = [] in
	      let (dev2,unsat2) = buildptree nseq2 umr uml uer ual uhc hccnd vb sh in
	      let (ul2,ur2) = unsat2 in
	      if containsunsat seq unsat2 then
		(F.BD("cut=",seq,dev1,dev2),((M.setlist (nul1@ul2)),(M.setlist (nur1@ur2))))
	      else 
		let (nul2,nur2) = (ul2,(M.subtalllist nf ur2)) in
		(F.BD("cut=",seq,dev1,dev2),((M.setlist (nul1@nul2)),(M.setlist (nur1@nur2))))
	    else 
	      let numr1 = expsubsusedrl umr expsubs in
	      let numl1 = expsubsusedrl uml expsubs in
	      let nuer1 = expsubsusedel uer expsubs in
	      let nual1 = expsubsusedel ual expsubs in
	      let nhccnd1 = expsubshccnd hccnd expsubs in
	      let (dev1,unsat1) = buildptree nseq1 numr1 numl1 nuer1 nual1 uhc nhccnd1 vb sh in
	      let (nul1,nur1) = recunsatesubs seq unsat1 expsubs in
	      let (dev2,unsat2) = buildptree nseq2 umr uml uer ual uhc hccnd vb sh in
	      let (ul2,ur2) = unsat2 in
	      if containsunsat seq unsat2 then
		(F.BD("cut=",seq,dev1,dev2),((M.setlist (nul1@ul2)),(M.setlist (nur1@ur2))))
	      else 
		let (nul2,nur2) = (ul2,(M.subtalllist nf ur2)) in
		(F.BD("cut=",seq,dev1,dev2),((M.setlist (nul1@nul2)),(M.setlist (nur1@nur2))))
	in 
	let applylastrules num seq uer ual uhc hccnd =
	  if num = 0 then (* apply rhe *)
	    applyrhe seq uml hccnd
	  else if num = 1 then (* apply hc *)
	    applyhc seq uml uhc hccnd
	  else if num = 2 then (* apply existsr2 *)
	    applyer2 seq uer 
	  else if num = 3 then (* apply foralll2 *)
	    applyal2 seq ual
	  else if num = 4 then (* apply cut= *)
	    applycuteq seq 
	  else failwith "applylastrules: undefined rules!"
	in 
	let rec applylast chosen rnum seq uer ual uhc hccnd =
	  if chosen <> -1  && (not(sh = "-sh") || not(List.mem rnum [0;1;2;3])) then (* apply the chosen one *)
	    let (dev,unsat) = applylastrules chosen seq uer ual uhc hccnd in
	    if dev = F.NULLD then
	      applylast (-1) rnum seq uer ual uhc hccnd
	    else (dev,unsat)
	  else (* the chosen app doesn't work *)
	    if rnum < 5 then (* try the 5 last rules *)
	      (* don't apply the chosen rule again, and *)
	      (* if sh = "-sh", then don't apply rhe, hc, existsr2, foralll2 *)
	      if rnum <> chosen && (not(sh = "-sh") || not(List.mem rnum [0;1;2;3])) then
		let (dev,unsat) = applylastrules rnum seq uer ual uhc hccnd in
		if dev = F.NULLD then
		  applylast (-1) (rnum+1) seq uer ual uhc hccnd
		else (dev,unsat)
	      else applylast (-1) (rnum+1) seq uer ual uhc hccnd
	    else
	      let _ = 
		if vb = "-v" then (print_endline "No rules appliacble!")
		else ()
	      in 
	      (F.UD("NORULE",seq,F.NULLD),([],[]))
	in 
	let rand = Random.int 5 in
	applylast rand 0 seq uer ual uhc hccnd
    in 
    tryrules "id" seq0 umr uml uer ual uhc hccnd;;

(* search for a proof of formula f *)
(* return a derivation tree *)
let proofserach f pscr sh = fst (buildptree (rewrite_seq (F.SEQ([],[],[F.LF(("a"^(string_of_int !labelnum)),f)]))) [] [] [] [] [] [] pscr sh);;
  
(* Test if a derivation is closed *)
let rec closeddev dev =
  match dev with
  | F.UD(rule,seq,dev) -> if rule = "NORULE" then false else closeddev dev
  | F.BD(rule,seq,dev1,dev2) -> if rule = "NORULE" then false else ((closeddev dev1) && (closeddev dev2))
  | _ -> true;;

(* start a proof procedure *)
let prove f ptex pscr sh =
  let _ =  
    print_endline "\nTrying to find a derivation for the formula: ";
    F.print_justbi_formula f;print_endline "" in
  let starttime = Unix.gettimeofday () in 
  let dev = proofserach f pscr sh in
  let finishtime = Unix.gettimeofday () in
  let time = finishtime -. starttime in
  let solved = closeddev dev in
  let infos = if solved then "Proof found:)\n" else "Can't find a proof:(\n" in
  let _ = print_string infos;print_endline ("Time used: "^(string_of_float time)^"s") in
  if ptex = "-p" || ptex = "-p-g" then 
    let fptex = open_out "ptree.tex" in
    let _ =
      let info = if solved then "Proof found" else "Can't find a proof" in
      F.writetexhead fptex;output_string fptex info;
      output_string fptex " for the formula $";F.print_latexbi_formula fptex f;output_string fptex "$\\\\\n";
      output_string fptex "The derivation is:\\\\\n";
      output_string fptex "\\begin{center}\n\\tiny\n";
      F.print_latexdev dev fptex ptex;
      output_string fptex "\DisplayProof\n\end{center}\n";
      output_string fptex ("\ \\\nTime used: "^(string_of_float time)^" s\n\\");
      F.writetexend fptex;close_out fptex;
      Sys.command "pdflatex ptree.tex > latex_output.tmp"
    in
    (solved,time)
  else 
    (solved,time);;

(* prove a list of formulae fl *)
let rec provelist fl pscr sh = 
  match fl with
  | h::t -> 
    let (solved,time) = prove (F.simpvacquant (F.renamevar h)) "" pscr sh in
    provelist t pscr sh 
  | _ -> (true,0.0);;
   
let helpinfo p =
  if p = true then
    (print_endline "Usage:\n./lssl [-sh] [-verbose] [-r] filename";
     print_endline "or\n./lssl [-sh] [-verbose] -o [-g] filename\n";
     print_endline "-sh: restrict the prover to only use rules for symbolic heaps.";
     print_endline "-verbose   display details on screen";
     print_endline "-r   prove a list of formulae separated by 1 line in filename";
     print_endline "-o   output the derivation in a pdf file called ptree.pdf (requires pdflatex)";
     print_endline "-g   display ternary relational atoms in each sequent in the pdf file";
     print_endline "NOTE THAT (1) -r cannot be used with -o or -g, and vice versa. (2) -g must follow -o.")
  else ();;

let lspsl = 
  if (Array.length Sys.argv) = 2 then 
    let infile = Sys.argv.(1) in
    if infile = "-help" then
      helpinfo true
    else 
    let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in
    let _ = prove f "" "" "" in ()
  else if (Array.length Sys.argv) = 3 then 
    (let param1 = Sys.argv.(1) in
     let infile = Sys.argv.(2) in
     if param1 = "-o" then 
       let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in 
       let _ = prove f "-p" "" "" in ()
     else if param1 = "-r" then 
       let fl = F.parselist (M.readfileall infile) in 
       let _ = provelist fl "" "" in ()
     else if param1 = "-verbose" then (* print details on screen *)
       let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in 
       let _ = prove f "" "-v" "" in ()
     else if param1 = "-sh" then (* restrict to symbolic heaps *)
       let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in
       let _ = prove f "" "" "-sh" in ()
     else helpinfo true)
  else if (Array.length Sys.argv) = 4 then 
    (let param1 = Sys.argv.(1) in
    let param2 = Sys.argv.(2) in
    let infile = Sys.argv.(3) in
    if param1 = "-o" && param2 = "-g" then
      let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in
      let _ = prove f "-p-g" "" "" in ()
    else if param1 = "-verbose" && param2 = "-o" then 
      let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in
      let _ = prove f "-p" "-v" "" in ()
    else if param1 = "-verbose" && param2 = "-r" then
      let fl = F.parselist (M.readfileall infile) in
      let _ = provelist fl "-v" "" in ()
    else if param1 = "-sh" && param2 = "-verbose" then
      let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in
      let _ = prove f "" "-v" "-sh" in ()
    else if param1 = "-sh" && param2 = "-o" then
      let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in
      let _ = prove f "-p" "" "-sh" in ()
    else if param1 = "-sh" && param2 = "-r" then
      let fl = F.parselist (M.readfileall infile) in
      let _ = provelist fl "" "-sh" in ()
    else helpinfo true)
  else if (Array.length Sys.argv) = 5 then
    (let param1 = Sys.argv.(1) in
    let param2 = Sys.argv.(2) in
    let param3 = Sys.argv.(3) in
    let infile = Sys.argv.(4) in
    if param1 = "-verbose" && param2 = "-o" && param3 = "-g" then
      let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in
      let _ = prove f "-p-g" "-v" "" in ()
    else if param1 = "-sh" && param2 = "-verbose" && param3 = "-r" then
      let fl = F.parselist (M.readfileall infile) in
      let _ = provelist fl "-v" "-sh" in ()
    else if param1 = "-sh" && param2 = "-verbose" && param3 = "-o" then
      let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in
      let _ = prove f "-p" "-v" "-sh" in ()
    else if param1 = "-sh" && param2 = "-o" && param3 = "-g" then
      let f = (F.simpvacquant (F.renamevar (F.parse (M.readfile infile)))) in
      let _ = prove f "-p-g" "-v" "-sh" in ()
    else helpinfo true)
  else helpinfo true;;
