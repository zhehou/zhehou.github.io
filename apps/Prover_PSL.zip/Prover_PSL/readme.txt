use "make" to compile and generate the executable file

Specify a formula in a file (e.g., input.txt), the syntax is:
f ::= true | false | mtrue | f & f | f -> f | f * f | f -* f |

and a logic for the prover:
logic ::= -b: BBI | -p: BBI+P | -c: BBI+C | -i: BBI+IU | -d: BBI+D | -pc: BBI+P+C | -pi: BBI+P+IU | -ci: BBI+C+IU | -pd: BBI+P+D | -cd: BBI+C+D | -pci: BBI+P+C+IU | -pcd: BBI+P+C+D

Two provers are implemented: (1) lspsli chooses the principal formulae for *R and -*L iteratively (in turn); and (2) lspslr chooses principal formulae for *R and -*L randomly.

Use the following commands, where prover is lspsli or lspslr:

just try to prove a formula
./prover logic filname 

e.g., "./lspsli -pcd input.txt" runs the prover lspsli with the logic BBI+P+C+D on the (first) formula in the file input.txt

prove a list of formula in the file separated by one empty line
./prover logic -r filename

simplify a formula then prove it
./prover logic -s filename

simplify a list of formulae then prove them
./prover logic -r -s filename

prove a formula and generate a pdf file that contains the derivation tree without ternary relations
./prover logic -o filename

prove a formula and generate a pdf file that contains the derivation tree with ternary relations 
./prover logic -o -g filename

simplify a formula, prove it and generate a pdf file that contains the derivation tree without ternary relations
./prover logic -s -o filename

simplify a formula, prove it and generate a pdf file that contains the derivation tree with ternary relations 
./prover logic -s -o -g filename

See example formulae in files *.bi
