module F = BIformulae
module M = Misc

(* A global variable for the number of labels *)
let labelnum = ref 0;;

(*************** the following are for inference rules ***************)
(* each rule takes a sequent as input, and output a inference, i.e., *)
(* UINF for a singel sequent, and BINF for a pair of sequents        *)
(* each rule also output the principal formulae *)
(*********************************************************************)

(* Find the formula f in the list of labelled formulae l. *)
(* Return the label (a number) if found, otherwise return "-1". *)
let rec findf f l =
  match l with 
    | h::t -> if (F.fm h) = f then (F.lb h) else findf f t
    | _ -> "-1";;

(* Find a labelled formula in l that matches lf in the id rule *)
let rec findlf lf l =
  match l with
  | h::t -> if ((F.fm h) = (F.fm lf)) && ((F.lb h) = (F.lb lf)) then (F.lb h) else findlf lf t
  | _ -> "-1";;

(* Find the identical formulae with the same label in lf and rf *)
(* if found, return the labelled formula, *) 
(* otherwise return LF.nulllf. *)
let rec findidpair_f l r =
  match l with 
    | h::t ->
      let label2 = findlf h r in
      if label2 = "-1" then findidpair_f t r else h
    | _ -> F.nulllf;;

(***** the id rule *****)
(* A simplified id rule that only deal with formulae with the same label *)
let id_f seq = 
  let F.SEQ(g,lf,rf) = seq in
  let pf = findidpair_f lf rf in
  if pf = F.nulllf then (F.NULLI,F.nulllf)
  else ((F.UINF F.empseq),pf);;
  
(***** the falseL rule *****)
let falsel seq = 
  let F.SEQ(g,lf,rf) = seq in
  let label = findf F.FALSE lf in
  if label = "-1" then (F.NULLI,F.nulllf) 
  else ((F.UINF F.empseq),F.LF(label,F.FALSE));;

(***** the trueR rule *****)
let truer seq = 
  let F.SEQ(g,lf,rf) = seq in
  let label = findf F.TRUE rf in
  if label = "-1" then (F.NULLI,F.nulllf) 
  else ((F.UINF F.empseq),F.LF(label,F.TRUE));;

(***** the mtrueR rule *****)
let mtruer seq =
  let F.SEQ(g,lf,rf) = seq in
  let label = findlf (F.LF("epsilon",F.MTRUE)) rf in 
  if label = "-1" then (F.NULLI,F.nulllf) 
  else ((F.UINF F.empseq),F.LF("epsilon",F.MTRUE));;

(* Substitution [x/y] in a list of relations *)
let subsrlist l x y =
  let rec subsrl l x y acc =
    match l with
      | h::t ->
	let F.RT(s3,s4,s5) = h in 
	if s3 = y then 
	  if s4 = y then
	    if s5 = y then subsrl t x y (acc@[F.RT(x,x,x)])
	    else subsrl t x y (acc@[F.RT(x,x,s5)])
	  else (if s5 = y then subsrl t x y (acc@[F.RT(x,s4,x)])
	    else subsrl t x y (acc@[F.RT(x,s4,s5)]))
	else (if s4 = y then 
	    if s5 = y then subsrl t x y (acc@[F.RT(s3,x,x)])
	    else subsrl t x y (acc@[F.RT(s3,x,s5)])
	  else (if s5 = y then subsrl t x y (acc@[F.RT(s3,s4,x)])
	    else subsrl t x y (acc@[F.RT(s3,s4,s5)])))
      | _ -> acc 
  in
  if y <> "epsilon" then subsrl l x y [] 
  else if (y = "epsilon") && (x <> "epsilon") then subsrl l y x []
  else failwith "subsrlist(): x and y are both epsilon in [x/y]";;

(* Substitution [x/y] in a list of labelled formulae *)
let subsflist l x y =
  let rec subsfl l x y acc =
    match l with
      | h::t -> 
	  if (F.lb h) = y then subsfl t x y (acc@[F.LF(x,(F.fm h))])
	  else subsfl t x y (acc@[h]) 
      | _ -> acc 
  in
  if y <> "epsilon" then subsfl l x y []
  else if (y = "epsilon") && (x <> "epsilon") then subsfl l y x []
  else failwith "subsflist(): x and y are both epsilon in [x/y]";;

(* perform a list of substitutions (x,y) list on a list of formulae fl *)
let rec subslflist fl subs =
  match subs with
  | h::t -> subslflist (subsflist fl (fst h) (snd h)) t
  | _ -> fl;;

(***** the mtrueL rule *****)
let mtruel seq =
  let F.SEQ(g,lf,rf) = seq in
  let label = findf F.MTRUE lf in
  if ((label = "-1") or (label = "epsilon")) then (F.NULLI,F.nulllf)
  else 
    let g1 = subsrlist g "epsilon" label in
    let lft = M.subtlist (F.LF(label,F.MTRUE)) lf in
    let lf1 = subsflist lft "epsilon" label in
    let rf1 = subsflist rf "epsilon" label in
    ((F.UINF(F.SEQ((M.setlist g1),lf1,rf1))),F.LF(label,F.MTRUE));;

(* test if a formula with the main connective con is in the list l *)
(* return the formula is found, otherwise return nulllf *)
let rec hasform con l =
  match l with
  | h::t -> 
    begin
      match (F.fm h) with
      | F.AND(f1,f2) -> if con = "AND" then h else hasform con t
      | F.IMP(f1,f2) -> if con = "IMP" then h else hasform con t
      | F.MAND(f1,f2) -> if con = "MAND" then h else hasform con t
      | F.MIMP(f1,f2) -> if con = "MIMP" then h else hasform con t
      | _ -> hasform con t
    end 
  | _ -> F.nulllf;;

(* find all formulae with the main connective con in the list l *)
(* return a list of formulae with the same main connective *)
let findallform con l =
  let rec findall con l acc =
    match l with
    | h::t -> 
      begin
	match (F.fm h) with
	| F.AND(f1,f2) -> 
	  if con = "AND" 
	  then findall con t (acc@[h]) else findall con t acc
	| F.IMP(f1,f2) -> 
	  if con = "IMP"
	  then findall con t (acc@[h]) else findall con t acc
	| F.MAND(f1,f2) ->
	  if con = "MAND"
	  then findall con t (acc@[h]) else findall con t acc
	| F.MIMP(f1,f2) -> 
	  if con = "MIMP"
	  then findall con t (acc@[h]) else findall con t acc
	| _ -> findall con t acc
      end 
    | _ -> acc
  in 
  findall con l [];;

(* find all relations in rl that has w as the nth element *)
(* n can only be 1 to 3 *)
let findallrel w n l =
  let rec findall w n l acc =
    match l with
    | h::t -> 
      begin
	match h with
	| F.RT(t1,t2,t3) -> 
	  if n = 1 && w = t1 then findall w n t (acc@[h])
	  else if n = 2 && w = t2 then findall w n t (acc@[h])
	  else if n = 3 && w = t3 then findall w n t (acc@[h])
	  else findall w n t acc
	| _ -> failwith "findallrel(): not a valid relation"
      end 
    | _ -> acc
  in 
  findall w n l [];;

(* find applicable mandR or mimpL applications *)
(* given a list of mand or mimp formula, a list of relations *)
(* and a list of used (relation * labelled_form) *)
(* return a list of applicable pairs (relation * labelled_form) *)
let findallapp rule fl rl used =
  let rec mkpairl a l acc =
    match l with
    | h::t -> mkpairl a t (acc@[(h,a)])
    | _ -> acc
  in 
  let rec unused rl f used acc =
    match rl with
    | h::t -> 
      if List.mem (h,f) used then unused t f used acc 
      else unused t f used (acc@[h]) 
    | _ -> acc
  in 
  let rec findall rule fl rl used acc =
    match fl with
    | h::t -> 
      if rule = "mandr" then 
	let apprl = findallrel (F.lb h) 3 rl in
	let apprlt = unused apprl h used [] in
       	let apppairl = mkpairl h apprlt [] in
	findall rule t rl used (acc@apppairl)
      else 
	let apprl = findallrel (F.lb h) 2 rl in
	let apprlt = unused apprl h used [] in
       	let apppairl = mkpairl h apprlt [] in
	findall rule t rl used (acc@apppairl)
    | _ -> acc
  in 
  findall rule fl rl used [];;

(* Given a list of candidate apps (relation * labelled form) *)
(* For mandR or mimpL, filter out those apps that do not benefit the proof search *)
(* i.e., for (a1,a2|>a0), a0:A*B, if a1:A or a2:B is already in rf *)
(* for (a1,a0|>a2), a0:A-*B, a1:A already in rf or a2:B already in lf *)
let usefulapp rule seq appl =
  let F.SEQ(g,lf,rf) = seq in
  let rec filter rule lf rf appl acc =
    match appl with
    | h::t -> 
      let (r,pf) = h in
      let F.RT(a1,a2,a3) = r in
      if rule = "mandr" then
	let F.MAND(f1,f2) = F.fm pf in
	if (List.mem (F.LF(a1,f1)) rf) || (List.mem (F.LF(a2,f2)) rf) then 
	  filter rule lf rf t acc
	else 
	  filter rule lf rf t (acc@[h])
      else if rule = "mimpl" then
	let F.MIMP(f1,f2) = F.fm pf in
	if (List.mem (F.LF(a1,f1)) rf) || (List.mem (F.LF(a2,f2)) lf) then 
	  filter rule lf rf t acc
	else 
	  filter rule lf rf t (acc@[h])
      else failwith "filter(): Wrong rule\n"
    | _ -> acc
  in 
  filter rule lf rf appl [];;

(***** the andL rule *****)
let andl seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "AND" lf in
  if pf = F.nulllf then (F.NULLI,pf) 
  else 
    let lf1 = M.subtlist pf lf in
    let label = F.lb pf in
    let F.AND(f1,f2) = F.fm pf in
    (F.UINF(F.SEQ(g,([F.LF(label,f1);F.LF(label,f2)]@lf1),rf)),pf);;

(***** the andR rule *****)
let andr seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "AND" rf in
  if pf = F.nulllf then (F.NULLI,pf)
  else 
    let rf1 = M.subtlist pf rf in
    let label = F.lb pf in
    let F.AND(f1,f2) = F.fm pf in
    (F.BINF(F.SEQ(g,lf,([F.LF(label,f1)]@rf1)),F.SEQ(g,lf,([F.LF(label,f2)]@rf1))),pf);;

(***** the impL rule *****)
let impl seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "IMP" lf in
  if pf = F.nulllf then (F.NULLI,pf)
  else 
    let lf1 = M.subtlist pf lf in
    let label = F.lb pf in
    let F.IMP(f1,f2) = F.fm pf in
    (F.BINF(F.SEQ(g,lf1,([F.LF(label,f1)]@rf)),F.SEQ(g,([F.LF(label,f2)]@lf1),rf)),pf);;

(***** the impR rule *****)
let impr seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "IMP" rf in
  if pf = F.nulllf then (F.NULLI,pf)
  else 
    let rf1 = M.subtlist pf rf in
    let label = F.lb pf in
    let F.IMP(f1,f2) = F.fm pf in
    (F.UINF(F.SEQ(g,([F.LF(label,f1)]@lf),([F.LF(label,f2)]@rf1))),pf);;

(***** the mandL rule *****)
(* return a pair (UINF * (relation * labelled_form)) *)
let mandl seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "MAND" lf in
  if pf = F.nulllf then (F.NULLI,(F.nullr,pf))
  else 
    let lf1 = M.subtlist pf lf in 
    let label = F.lb pf in
    let F.MAND(f1,f2) = F.fm pf in
    let _ = labelnum := !labelnum+2 in
    let t = !labelnum in
    let newrel = F.RT(("a"^(string_of_int (t-1))),("a"^(string_of_int t)),label) in
    (F.UINF(F.SEQ((g@[newrel]),([F.LF(("a"^(string_of_int (t-1))),f1);F.LF(("a"^(string_of_int t)),f2)]@lf1),rf)),(newrel,pf));;

(* delete a formula f from a list of formulae fl *)
(* if fl contains more than one f, delete all *)
(* if f not in fl, return fl *)
let rec delf f fl = if List.mem f fl then delf f (M.subtlist f fl) else fl;;

(* find the world where the (unlabelled) formula f is true at, based on the sequent seq *)
(* only consider AND, IMP, and MAND *)
(* if found, return the label, otherwise return "-1" *)
let rec findworld f lfl rl =
  let rec containsf f lfl =
    match lfl with
    | h ::t -> if (F.fm h) = f then F.lb h else containsf f t 
    | _ -> "-1"
  in 
  let label = containsf f lfl in
  if label <> "-1" then (label,[])
  else 
    begin
      match f with
      | F.AND(f1,f2) | F.IMP(f1,f2) -> 
	let (label1,rl1) = findworld f1 lfl rl in
	if label1 <> "-1" then (label1,rl1)
	else 
	  let (label2,rl2) = findworld f2 lfl rl in
	  if label2 <> "-1" then (label2,rl2)
	  else ("-1",rl)
      | F.MAND(f1,f2) ->
	let (label1,rl1) = findworld f1 lfl rl in
	let (label2,rl2) = findworld f2 lfl rl in
	if (label1 <> "-1") && (label2 <> "-1") then 
	  let _ = labelnum := !labelnum+1 in
	  let t = !labelnum in
	  let newlabel = "x"^(string_of_int t) in
	  (newlabel,(rl1@rl2@[F.RT(label1,label2,newlabel)]))
	else ("-1",rl)
      | _ -> ("-1",rl)
    end;;

  (* reads a list of ternary relations, return (sub)trees with the said root *)
let gettreeroot root l =
  let rec gettree root l accl accr acct = 
  (* accl stores unused relations, accr stores leaves, acct stores 2lvl trees *)
    match l with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      if s3 = root && accr = [] then 
	let thisleaves = [s1;s2] in
	gettree root t accl thisleaves (acct@[(root,thisleaves)])
      else if (List.mem s3 accr) then 
	let thisleaves = (M.subtlist s3 accr)@[s1;s2] in
	gettree root t accl thisleaves (acct@[(root,thisleaves)])
      else gettree root t (accl@[h]) accr acct 
    | _ -> (accl,accr,acct)
  in 
  let rec getfinaltree root l last acctree =
    let (lt,accl,acct) = gettree root l [] last [] in
    if acct = [] then (lt,(root,accl),acctree) else getfinaltree root lt accl (acctree@acct)
  in 
  let rec gettrees root l acc =
    let (lt,accl,acct) = getfinaltree root l [] [] in
    if List.length (snd accl) = 0 then acc else gettrees root lt (acc@acct)
  in 
  gettrees root l [];;

(* test is two 2lvl trees tr1 and tr2 are equal *)
(* i.e., contains the same root, and same set of leaves *)
(* tr = (str,[str]) *)
let equaltree tr1 tr2 = 
  if ((fst tr1) = (fst tr2))  && (M.equalsetlist (snd tr1) (snd tr2)) then
    true
  else false;;

(* search a list of ternary relations l find ones with parent node p *)
let getternp p l =
  let rec search p l acc =
    match l with
    | h::t -> let F.RT(s1,s2,s3) = h in if s3 = p then search p t (acc@[h]) else search p t acc
    | _ -> acc 
  in 
  search p l [];;

(* test if w is a leave in the 2lvl tree tr *)
let isleave w tr = if List.mem w (snd tr) then true else false;;

(* test if a ternary relation rl contains a relation with children c1 c2 *)
let rec haschildren rl c1 c2 =
  let rl1 = findallrel c1 1 rl in
  let rl2 = findallrel c2 2 rl1 in
  if rl2 <> [] then let F.RT(s1,s2,s3) = List.hd rl2 in s3
  else 
    let rl3 = findallrel c2 1 rl in
    let rl4 = findallrel c1 2 rl3 in
    if rl4 <> [] then let F.RT(s1,s2,s3) = List.hd rl4 in s3
    else "-1";;

(* generate a set of relational atoms based on g, tr and rl *)
(* rl is a set of relational atoms representing a binary tree tr on RHS *)
(* the root and leaves of tr must occur in g, internal nodes might not *)
(* return (terns,r), terns is a list of generated relations *)
(* r is the principal relation to be used in quick_mandr *)
let quickstr g tr rl =
  let rec terngen root node g tr rl =
    (* return (rl,w), rl is generated relations, w is a label that replaces node *)
    (* if node doesn't need to be replaced, w = "0" *)
    if isleave node tr then ([],"0",F.nullr)
    else 
      let ternpl = getternp node rl in
      if (List.length ternpl) <> 1 then 
	failwith "terngen(): the node is parent in multiple (or 0) ternaery relations"
      else 
	let F.RT(s1,s2,s3) = List.hd ternpl in
	let (rl1,t1,r) = terngen root s1 g tr rl in
	let (rl2,t2,r) = terngen root s2 g tr rl in
	let n1 = if t1 = "0" then s1 else t1 in
	let n2 = if t2 = "0" then s2 else t2 in
	let n3 = haschildren g n1 n2 in
	if n3 = "-1" then 
	  if node = root then ((rl1@rl2@[F.RT(n1,n2,s3)]),"0",F.RT(n1,n2,root))
	  else ((rl1@rl2@[F.RT(n1,n2,s3)]),"0",F.nullr)
	else 
	  if node = root then ((rl1@rl2),n3,F.RT(n1,n2,root))
	  else ((rl1@rl2),n3,F.nullr)
  in 
  let (terns,w,r) = (terngen (fst tr) (fst tr) g tr rl) in
  (terns,r);;

(* given a list of trees, return the largest one *)
let largest_tree trl =
  let rec larger trl maxtr =
    match trl with
    | h::t ->
      if (List.length (snd h)) > (List.length (snd maxtr)) then 
	larger t h
      else larger t maxtr 
    | _ -> maxtr
  in 
  larger trl ("",[]);;

(* test if a list of relatoins rl is implied by g *)
(* root is the root in rl *)
let str_solvable root tr trsg =
  let rec solvable tr trl =
    match trl with
    | h::t -> if equaltree tr h then true else solvable tr t
    | _ -> false
  in 
  if solvable tr trsg then true else false;;

(***** the quick mandR rule *****)
(* using the heuristic method to deal with structural rules *)
let quick_mandr seq usedrt =
  let rec used pf usedrt =
    match usedrt with
    | h::t -> let (r,F.LF(l,f)) = h in if pf = f then true else used pf t
    | _ -> false
  in  
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "MAND" rf in
  if pfl = [] then (F.NULLI,(F.nullr,F.nulllf))
  else 
    let rec tryquick pfl fl g =
      match pfl with
      | h::t -> 
	if used (F.fm h) usedrt then tryquick t fl g 
	else 
	  let flt = delf h fl in
	  let F.MAND(f1,f2) = F.fm h in
	  let (w1,rl1) = findworld f1 flt g in
	  let (w2,rl2) = findworld f2 flt g in
	  let root = F.lb h in
	  let rl = M.setlist (rl1@rl2@[F.RT(w1,w2,root)]) in
	  if F.invalidrell rl then tryquick t fl g
	  else 
	    let trsg = gettreeroot root g in
	    let tr = largest_tree (gettreeroot root rl) in
	    if str_solvable root tr trsg then 
	      let (terns,F.RT(s1,s2,s3)) = quickstr g tr rl in
	      if F.invalidrell (terns@[F.RT(s1,s2,s3)]) then tryquick t fl g
	      else (F.BINF(F.SEQ((g@terns),lf,([F.LF(s1,f1)]@rf)),F.SEQ((g@terns),lf,([F.LF(s2,f2)]@rf))),(F.RT(w1,w2,root),h))
	    else tryquick t fl g 
      | _ -> (F.NULLI,(F.nullr,F.nulllf))
    in 
    tryquick pfl (lf@rf) g;;

(* print a list of rule applications *)
let rec print_appl appl =
  let print_app app = print_string "(";F.print_rel (fst app);print_string ",";F.print_lf (snd app);print_string ")" in
  match appl with
  | h::t -> print_app h;print_string " ";print_appl t 
  | _ -> ();;
    
(***** the mandR rule *****)
(* usedrt is a list of (relation * labelled_form) which is a history record *)
(* to avoid applying the rule on the same formula and relation *)
(* return a pair (BINF * (relation * labelled_form)) *)
let mandr seq usedrt focus = 
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "MAND" rf in
  if pfl = [] then (F.NULLI,(F.nullr,F.nulllf))
  else 
    let apppairl = usefulapp "mandr" seq (findallapp "mandr" pfl g usedrt) in
    if List.length apppairl > 0 then 
      let fstapp = List.hd apppairl in
      let (F.RT(t1,t2,t3),F.LF(l,F.MAND(f1,f2))) = fstapp in
      (if (List.hd rf) = (F.LF(l,F.MAND(f1,f2))) && focus then 
	let rf1 = M.subtlist (F.LF(l,F.MAND(f1,f2))) rf in
	if t3 = l then (F.BINF(F.SEQ(g,lf,([F.LF(t1,f1)]@rf1@[F.LF(l,F.MAND(f1,f2))])),F.SEQ(g,lf,([F.LF(t2,f2)]@rf1@[F.LF(l,F.MAND(f1,f2))]))),fstapp)
	else failwith "mandr(): t3 and l do not match"
      else if (List.hd rf) <> (F.LF(l,F.MAND(f1,f2))) && focus then 
	(F.NULLI,(F.nullr,F.nulllf))
      else (* do not focus on the first applicable formula, i.e., randomly choose *)  
	let randapp = M.rand_listmem apppairl in
	let (F.RT(randt1,randt2,randt3),F.LF(randl,F.MAND(randf1,randf2))) = randapp in
	let rf1 = M.subtlist (F.LF(randl,F.MAND(randf1,randf2))) rf in
	if randt3 = randl then (F.BINF(F.SEQ(g,lf,([F.LF(randt1,randf1)]@rf1@[F.LF(randl,F.MAND(randf1,randf2))])),F.SEQ(g,lf,([F.LF(randt2,randf2)]@rf1@[F.LF(randl,F.MAND(randf1,randf2))]))),randapp)
	else failwith "mandr(): randt3 and randl do not match")
    else (F.NULLI,(F.nullr,F.nulllf));;

(***** the mimpL rule *****)
(* usedrt is a list of (relation * labelled_form) which is a history record *)
(* to avoid applying the rule on the same formula and relation *)
(* return a pair (BINF * (relation * labelled_form)) *)
let mimpl seq usedrt focus = 
  let F.SEQ(g,lf,rf) = seq in
  let pfl = findallform "MIMP" lf in
  if pfl = [] then (F.NULLI,(F.nullr,F.nulllf))
  else 
    let apppairl = usefulapp "mimpl" seq (findallapp "mimpl" pfl g usedrt) in
    if List.length apppairl > 0 then
      let fstapp = List.hd apppairl in
      let (F.RT(t1,t2,t3),F.LF(l,F.MIMP(f1,f2))) = fstapp in
      (if (List.hd lf) = (F.LF(l,F.MIMP(f1,f2))) && focus then 
	let lf1 = M.subtlist (F.LF(l,F.MIMP(f1,f2))) lf in
	if t2 = l then (F.BINF(F.SEQ(g,lf1@[F.LF(l,F.MIMP(f1,f2))],([F.LF(t1,f1)]@rf)),F.SEQ(g,([F.LF(t3,f2)]@lf1@[F.LF(l,F.MIMP(f1,f2))]),rf)),fstapp)
	else failwith "mimpl(): t2 and l do not match"
      else if (List.hd lf) <> (F.LF(l,F.MIMP(f1,f2))) && focus then
	(F.NULLI,(F.nullr,F.nulllf))
      else (* do not focus on the first applicable formula, i.e., randomly choose *)
	let randapp = M.rand_listmem apppairl in
	let (F.RT(randt1,randt2,randt3),F.LF(randl,F.MIMP(randf1,randf2))) = randapp in
	let lf1 = M.subtlist (F.LF(randl,F.MIMP(randf1,randf2))) lf in
	if randt2 = randl then (F.BINF(F.SEQ(g,(lf1@[F.LF(randl,F.MIMP(randf1,randf2))]),([F.LF(randt1,randf1)]@rf)),F.SEQ(g,([F.LF(randt3,randf2)]@lf1@[F.LF(randl,F.MIMP(randf1,randf2))]),rf)),randapp)
	else failwith "mimpl(): randt2 and randl do not match")
    else (F.NULLI,(F.nullr,F.nulllf));;

(***** the mimpR rule *****)
(* return a pair (UINF * (relation * labelled_form)) *)
let mimpr seq =
  let F.SEQ(g,lf,rf) = seq in
  let pf = hasform "MIMP" rf in
  if pf = F.nulllf then (F.NULLI,(F.nullr,pf))
  else 
    let rf1 = M.subtlist pf rf in 
    let label = F.lb pf in
    let F.MIMP(f1,f2) = F.fm pf in
    let _ = labelnum := !labelnum+2 in
    let t = !labelnum in
    let newrel = F.RT(("a"^(string_of_int (t-1))),label,("a"^(string_of_int t))) in
    (F.UINF(F.SEQ((g@[newrel]),([F.LF(("a"^(string_of_int (t-1))),f1)]@lf),([F.LF(("a"^(string_of_int t)),f2)]@rf1))),(newrel,pf));;

(* Find all the eq-relations of the form *)
(* (x,epsilon |> y) or (epsilon,x |> y) from a list l of relations *)
(* return a list of relations *)
let findeqrl l =
  let rec findall l acc = 
    match l with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      if ((s1 = "epsilon") && (s2 <> s3)) || ((s2 = "epsilon") && (s1 <> s3)) 
      then findall t (acc@[h]) else findall t acc 
    | _ -> acc
  in 
  findall l [];;

(* find all relations of the form (x,y |> epsilon) from a list l of relations *)
(* return a list of relations *)
let findiurl l =
  let rec findall l acc =
    match l with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      if (s1 <> "epsilon") && (s2 <> "epsilon") && (s3 = "epsilon")
      then findall t (acc@[h]) else findall t acc
    | _ -> acc
  in 
  findall l [];;

(* find all relations of the form (x,x |> y) from a list l of relations *)
(* return a list of relations *)
let finddjrl l =
  let rec findall l acc =
    match l with
    | h::t ->
      let F.RT(s1,s2,s3) = h in
      if (s1 = s2) && (s1 <> "epsilon") (*&& (s1 <> s3) && (s3 <> "epsilon")*)
      then findall t (acc@[h]) else findall t acc
    | _ -> acc
  in 
  findall l [];;

(* merge two lists of substitutions (x,y) *)
(* delete duplication substitutions *)
(* including (a,b) and (b,a) *)
let mergesubs subs1 subs2 =
  let rec merge subs1 subs2 acc =
    match subs1 with
    | h::t -> 
      let (x,y) = h in
      if (List.mem (x,y) subs2) || (List.mem (y,x) subs2) then 
	merge t subs2 acc
      else merge t subs2 (acc@[h])
    | _ -> subs2@acc
  in 
  merge subs1 subs2 [];;

(* get a list of substitutions (x,y) list from a list of relations *)
(* in the form (x,epsilon |> y) or (epsilon,x |> y) or (x,y |> epsilon) *)
(* return a list of substitutions (x,y), meaning [x/y] *)
let getsubsl rl =
  let rec getsubs rl acc =
    match rl with
    | h::t ->
      let F.RT(s1,s2,s3) = h in
      if s1 = "epsilon" && s2 <> s3 then getsubs t (mergesubs [(s2,s3)] acc)
      else if s2 = "epsilon" && s1 <> s3 then getsubs t (mergesubs [(s1,s3)] acc)
      else if s3 = "epsilon" && s1 <> "epsilon" && s2 <> "epsilon" then 
	if s1 = s2 then getsubs t (mergesubs [("epsilon",s1)] acc)
	else getsubs t (mergesubs [("epsilon",s1);("epsilon",s2)] acc)
      else failwith "getsubs(): not eq-relation nor iu-relation\n"
    | _ -> acc 
  in 
  getsubs rl [];;

(* get a list of substitutions (x,y) list from a list of relations *)
(* in the form (x,x |> y) *)
(* return a list of substitutions (x,y), meaning [x/y] *)
let getsubsdj rl =
  let rec getsubs rl acc =
    match rl with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      getsubs t (mergesubs [("epsilon",s1)] acc)
    | _ -> acc
  in 
  getsubs rl [];;

(* for partiality rule *)
(* find all pairs of relations of the form *)
(* (a,b|>c);(a,b|>d) from a list l of relations *)
(* return a list of substitutions (x,y), meaning [x/y] *)
let getpsubs rl =
  let rec findppairs r rl acc =
    match rl with
    | h::t -> 
      let F.RT(s1,s2,s3) = r in
      let F.RT(t1,t2,t3) = h in
      if (s1 = t1 && s2 = t2 && s3 <> t3) || (s1 = t2 && s2 = t1 && s3 <> t3) then 
	if List.mem (s3,t3) acc || List.mem (t3,s3) acc then
	  findppairs r t acc
	else 
	  findppairs r t (acc@[(s3,t3)])
      else findppairs r t acc
    | _ -> acc
  in 
  let rec findallppairs rl1 rl2 acc =
    match rl1 with
    | h::t -> 
      let subs = findppairs h rl2 [] in
      findallppairs t rl2 (mergesubs subs acc)
    | _ -> acc
  in 
  findallppairs rl rl [];;

(* for cancellativity rule *)
(* find all pairs of relations of the form *)
(* (a,b|>c);(a,d|>c) from a list l of relations *)
(* return a list of substitutions (x,y), meaning [x/y] *)
let getcsubs rl =
  let rec findcpairs r rl acc =
    match rl with
    | h::t -> 
      let F.RT(s1,s2,s3) = r in
      let F.RT(t1,t2,t3) = h in
      if (s1 = t1 && s3 = t3 && s2 <> t2)  then 
	if List.mem (s2,t2) acc || List.mem (t2,s2) acc then
	  findcpairs r t acc
	else 
	  findcpairs r t (acc@[(s2,t2)])
      else if (s1 = t2 && s3 = t3 && s2 <> t1) then 
	if List.mem (s2,t1) acc || List.mem (t1,s2) acc then
	  findcpairs r t acc
	else 
	  findcpairs r t (acc@[(s2,t1)])
      else if (s2 = t1 && s3 = t3 && s1 <> t2) then
	if List.mem (s1,t2) acc || List.mem (t2,s1) acc then
	  findcpairs r t acc
	else 
	  findcpairs r t (acc@[(s1,t2)])
      else if (s2 = t2 && s3 = t3 && s1 <> t1) then 
	if List.mem (s1,t1) acc || List.mem (t1,s1) acc then
	  findcpairs r t acc
	else 
	  findcpairs r t (acc@[(s1,t1)])
      else findcpairs r t acc
    | _ -> acc
  in 
  let rec findallcpairs rl1 rl2 acc =
    match rl1 with
    | h::t -> 
      let subs = findcpairs h rl2 [] in
      findallcpairs t rl2 (mergesubs subs acc)
    | _ -> acc
  in 
  findallcpairs rl rl [];;

(* globally substitute [x/y] on the sequent seq *)
let subsseq seq x y =
  let F.SEQ(g,lf,rf) = seq in
  if y <> "epsilon" then
    let ng = subsrlist g x y in
    let nlf = subsflist lf x y in
    let nrf = subsflist rf x y in
    (F.SEQ(ng,nlf,nrf))
  else if x <> "epsilon" then
    let ng = subsrlist g y x in
    let nlf = subsflist lf y x in
    let nrf = subsflist rf y x in
    (F.SEQ(ng,nlf,nrf))
  else failwith "subsseq(): both x and y are epsilon in [x/y]\n";;

(* gloably perform a list of substitutions sl = (x,y) list on the sequent seq *)
let rec subslseq seq sl =
  match sl with
  | h::t -> let (x,y) = h in subslseq (subsseq seq x y) t
  | _ -> seq;;     

(* apply a rule with substitutions, return the new sequent and *)
(* a list of substitutions *)
let applyeq rule seq =
  let F.SEQ(g,lf,rf) = seq in
  let g0 = M.setlist g in
  let subs = 
    match rule with
    | "eq" -> getsubsl (findeqrl g0)
    | "iu" -> getsubsl (findiurl g0)
    | "dj" -> getsubsdj (finddjrl g0)
    | "p" -> getpsubs g0
    | "c" -> getcsubs g0
    | _ -> failwith "applyeq(): no such rule!"
  in
  let nseq = subslseq (F.SEQ(g0,lf,rf)) subs in
  (nseq,subs);;

(* compute the eq-closure of g in seq *)
(* global substitution is performed when needed *)
(* return a sequent that is eq-closed *)
(* also return the list of substitutions (x,y) list *)
(* to recover the unsat core *)
let eqclosure seq param =
  let rec recsub seq accsubs param =
    if param = "-b" then
      let (seq1,subs1) = applyeq "eq" seq in
      if subs1 = [] then (seq1,accsubs)
      else recsub seq1 (accsubs@subs1) param
    else if param = "-i" then
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "iu" seq1 in
      if (subs1@subs2) = [] then (seq2,accsubs)
      else recsub seq2 (accsubs@subs1@subs2) param
    else if param = "-c" then
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "c" seq1 in
      if (subs1@subs2) = [] then (seq2,accsubs)
      else recsub seq2 (accsubs@subs1@subs2) param
    else if param = "-d" then
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "iu" seq1 in
      let (seq3,subs3) = applyeq "dj" seq2 in
      if (subs1@subs2@subs3) = [] then (seq3,accsubs)
      else recsub seq3 (accsubs@subs1@subs2@subs3) param
    else if param = "-p" then 
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "p" seq1 in
      if (subs1@subs2) = [] then (seq2,accsubs)
      else recsub seq2 (accsubs@subs1@subs2) param
    else if param = "-pc" || param = "-cp" then
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "p" seq1 in
      let (seq3,subs3) = applyeq "c" seq2 in
      if (subs1@subs2@subs3) = [] then (seq3,accsubs)
      else recsub seq3 (accsubs@subs1@subs2@subs3) param
    else if param = "-pi" || param = "-ip" then
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "iu" seq1 in
      let (seq3,subs3) = applyeq "p" seq2 in
      if (subs1@subs2@subs3) = [] then (seq3,accsubs)
      else recsub seq3 (accsubs@subs1@subs2@subs3) param
    else if param = "-ci" || param = "-ic" then
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "iu" seq1 in
      let (seq3,subs3) = applyeq "c" seq2 in
      if (subs1@subs2@subs3) = [] then (seq3,accsubs)
      else recsub seq3 (accsubs@subs1@subs2@subs3) param
    else if param = "-pd" || param = "-dp" then
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "iu" seq1 in
      let (seq3,subs3) = applyeq "dj" seq2 in
      let (seq4,subs4) = applyeq "p" seq3 in
      if (subs1@subs2@subs3@subs4) = [] then (seq4,accsubs)
      else recsub seq4 (accsubs@subs1@subs2@subs3@subs4) param
    else if param = "-cd" || param = "-dc" then
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "iu" seq1 in
      let (seq3,subs3) = applyeq "dj" seq2 in
      let (seq4,subs4) = applyeq "c" seq3 in
      if (subs1@subs2@subs3@subs4) = [] then (seq4,accsubs)
      else recsub seq4 (accsubs@subs1@subs2@subs3@subs4) param
    else if param = "-pci" || param = "-pic" || param = "-cpi" || param = "-cip" || param = "-ipc" || param = "-icp" then
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "iu" seq1 in
      let (seq3,subs3) = applyeq "p" seq2 in
      let (seq4,subs4) = applyeq "c" seq3 in
      if (subs1@subs2@subs3@subs4) = [] then (seq4,accsubs)
      else recsub seq4 (accsubs@subs1@subs2@subs3@subs4) param
    else if param = "-pcd" || param = "-pdc" || param = "-cpd" || param = "-cdp" || param = "-dpc" || param = "-dcp" then
      let (seq1,subs1) = applyeq "eq" seq in
      let (seq2,subs2) = applyeq "iu" seq1 in
      let (seq3,subs3) = applyeq "dj" seq2 in
      let (seq4,subs4) = applyeq "p" seq3 in
      let (seq5,subs5) = applyeq "c" seq4 in
      if (subs1@subs2@subs3@subs4@subs5) = [] then (seq5,accsubs)
      else recsub seq5 (accsubs@subs1@subs2@subs3@subs4@subs5) param
    else failwith "recsub(): unsupported parameter!"
  in 
  recsub seq [] param;;

(* get all labels that occur in a list of relations *)
let getrllabels rl =
  let rec labels rl acc =
    match rl with 
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      let test1 = List.mem s1 acc in
      let test2 = List.mem s2 acc in
      let test3 = List.mem s3 acc in
      if test1 && test2 && test3 then labels t acc
      else if test1 && test2 then labels t (acc@[s3])
      else if test1 && test3 then labels t (acc@[s2])
      else if test2 && test3 then labels t (acc@[s1])
      else if test1 then labels t (acc@[s2;s3])
      else if test2 then labels t (acc@[s1;s3])
      else if test3 then labels t (acc@[s1;s2])
      else labels t (acc@[s1;s2;s3])
    | _ -> acc
  in 
  labels rl [];;

(* get all labels that occur in a list of labelled formulae *)
let getfllabels fl =
  let rec labels fl acc =
    match fl with
    | h::t -> 
      let label = F.lb h in 
      if List.mem label acc then labels t acc else labels t (acc@[label])
    | _ -> acc
  in 
  labels fl [];;

(* get all labels that occur in a sequent *)
let getseqlabels seq =
  let F.SEQ(g,lf,rf) = seq in 
  (getrllabels g)@(getfllabels lf)@(getfllabels rf);;

(* make identity relations based on a list of labels *)
let mkid l =
  let rec makeid l acc =
    match l with
    | h::t -> makeid t (acc@[F.RT("epsilon",h,h)])
    | _ -> acc
  in 
  makeid l [];;

(***** the u rule *****)
(* this rule generates all identity relatins for each label *)
let unit seq =
  let F.SEQ(g,lf,rf) = seq in
  let labels = getseqlabels seq in
  let idrl = mkid labels in
  F.UINF(F.SEQ((M.setlist (g@idrl)),lf,rf));;
    
(* find the commutative variants of relations in g *)
(* return a list of relations that are not in g *)
let commvar g =
  let rec cvar l g acc =
    match l with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      let cv = F.RT(s2,s1,s3) in
      if List.mem cv g then cvar t g acc 
      else cvar t g (acc@[cv])
    | _ -> acc
  in 
  cvar g g [];;

(***** the e rule *****)
(* this rule generates all commutative variants of relations in g *)
let comm seq =
  let F.SEQ(g,lf,rf) = seq in
  F.UINF(F.SEQ((M.setlist (g@(commvar g))),lf,rf));;

(* find pairs of relations from g that are applicable for assoc *)
let assocpairs param g =
  let containsunit r = 
    let F.RT(t1,t2,t3) = r in 
    if t1 = "epsilon" || t2 = "epsilon" || t3 = "epsilon" then true else false
  in 
  let applicable r1 r2 g =
    let F.RT(s1,s2,s3) = r1 in
    let F.RT(t1,t2,t3) = r2 in
    let rec searchg t1 t2 s2 s3 g =
      match g with
      | h::t -> 
	let F.RT(a1,a2,a3) = h in
	if a1 = t1 && a3 = s3 then 
	  if (List.mem (F.RT(s2,t2,a2)) g) || (List.mem (F.RT(t2,s2,a2)) g) then true
	  else searchg t1 t2 s2 s3 t
	else if a2 = t1 && a3 = s3 then
	  if (List.mem (F.RT(s2,t2,a1)) g) || (List.mem (F.RT(t2,s2,a1)) g) then true
	  else searchg t1 t2 s2 s3 t
	else searchg t1 t2 s2 s3 t
      | _ -> false
    in
    if (String.contains param 'i') || (String.contains param 'd') then
      (if containsunit r1 || containsunit r2 then false 
      else if searchg t1 t2 s2 s3 g then false else true)
    else if searchg t1 t2 s2 s3 g then false else true
  in 
  let rec apppairs r rl g acc =
    match rl with
    | h::t -> 
      if applicable r h g then apppairs r t g (acc@[(r,h)]) 
      else apppairs r t g acc
    | _ -> acc
  in 
  let rec getpairs l g acc =
    match l with
    | h::t -> 
      let F.RT(s1,s2,s3) = h in
      let children = findallrel s1 3 g in
      if children = [] then getpairs t g acc 
       else getpairs t g (acc@(apppairs h children g []))
    | _ -> acc
  in 
  getpairs g g [];;

(***** the assoc rule *****)
(* the rule generates all assoc pairs in g *)
let assoc param seq =
  let F.SEQ(g,lf,rf) = seq in
  let apppairs = assocpairs param g in
  let rec mkpairs pairs acc =
    match pairs with
    | h::t -> 
      let (F.RT(s1,s2,s3),F.RT(t1,t2,t3)) = h in 
      let _ = labelnum := !labelnum+1 in
      let n = !labelnum in
      mkpairs t (acc@[F.RT(t1,("a"^(string_of_int n)),s3);F.RT(s2,t2,("a"^(string_of_int n)))])
    | _ -> acc
  in 
  F.UINF(F.SEQ((M.setlist (g@(mkpairs apppairs []))),lf,rf));;

(* recorver the unsat core (lf,rf) from seq1 seq2 and subs *)
(* lf and rf are labelled_form lists, seq1 and se2 are sequents *)
(* seq1 is the conclusion, seq2 is the premise *)
(* subs is a list of substitutions (x,y), where x and y are strings *)
(* return a pair (lft,rft) as the new unsat core *)
let recunsat seq unsat subs =
  let rec recover fl1 fl2 subs acc =
    match fl1 with
    | h::t -> 
      if List.mem (List.hd (subslflist [h] subs)) fl2 then recover t fl2 subs (acc@[h])
      else recover t fl2 subs acc
    | _ -> acc
  in 
  let F.SEQ(g1,lf1,rf1) = seq in
  let (lf2,rf2) = unsat in
  ((recover lf1 lf2 subs []),(recover rf1 rf2 subs []));;

(* check if the sequent seq contains the unsat core (lf,rf) *)
let containsunsat seq unsat =
  let F.SEQ(g,lf,rf) = seq in
  let (lu,ru) = unsat in 
  if (M.listsubset lu lf) && (M.listsubset ru rf) then true else false;;

(* given a formula, a relation and the corresponding rule *)
(* extract the unsat core (lf,rf) on the conclusion *)
(* only deal with andl, impr, mandl, mimpr *)
(* when unsat is not a subset of the premise *)
let nextunsat_u rule pf r unsat =
  let (lu,ru) = unsat in
  match rule with
  | "andL" -> 
    let F.LF(l,F.AND(f1,f2)) = pf in 
    let nlu0 = delf (F.LF(l,f1)) lu in
    let nlu1 = delf (F.LF(l,f2)) nlu0 in
    let nlu2 = if List.mem pf nlu1 then nlu1 else nlu1@[pf] in
    (nlu2,ru)
  | "impR" -> 
    let F.LF(l,F.IMP(f1,f2)) = pf in 
    let nlu0 = delf (F.LF(l,f1)) lu in
    let nru0 = delf (F.LF(l,f2)) ru in
    let nru1 = if List.mem pf nru0 then nru0 else nru0@[pf] in
    (nlu0,nru1)
  | "mandL" ->
    let F.RT(t1,t2,t3) = r in
    let F.LF(l,F.MAND(f1,f2)) = pf in
    let nlu0 = delf (F.LF(t1,f1)) lu in
    let nlu1 = delf (F.LF(t2,f2)) nlu0 in
    let nlu2 = if List.mem pf nlu1 then nlu1 else nlu1@[pf] in
    (nlu2,ru)
  | "mimpR" ->
    let F.RT(t1,t2,t3) = r in
    let F.LF(l,F.MIMP(f1,f2)) = pf in
    let nlu0 = delf (F.LF(t1,f1)) lu in
    let nru0 = delf (F.LF(t2,f2)) ru in
    let nru1 = if List.mem pf nru0 then nru0 else nru0@[pf] in
    (nlu0,nru1);;

(* given a formula, a relation, and the corresponding rule *)
(* extract the unsat core (lf,rf) on the conclusion *)
(* only deal with andr, impl, mandr, mimpl *)
(* when unsat is not a subset of any premises *) 
let nextunsat_b rule pf r unsatl unsatr =
  let (l1,r1) = unsatl in
  let (l2,r2) = unsatr in
  match rule with
  | "andR" -> 
    let F.LF(l,F.AND(f1,f2)) = pf in
    let nr0 = delf (F.LF(l,f1)) (r1@r2) in
    let nr1 = delf (F.LF(l,f2)) nr0 in
    let nl = M.setlist (l1@l2) in
    let nr = M.setlist (nr1@[pf]) in
    (nl,nr)
  | "impL" ->
    let F.LF(l,F.IMP(f1,f2)) = pf in
    let nl0 = delf (F.LF(l,f2)) (l1@l2) in
    let nr0 = delf (F.LF(l,f1)) (r1@r2) in 
    let nl = M.setlist (nl0@[pf]) in
    let nr = M.setlist nr0 in
    (nl,nr)
  | "mandR" ->
    let F.LF(l,F.MAND(f1,f2)) = pf in
    let F.RT(t1,t2,t3) = r in
    let nr0 = delf (F.LF(t1,f1)) (r1@r2) in
    let nr1 = delf (F.LF(t2,f2)) nr0 in
    let nl = M.setlist (l1@l2) in
    let nr = M.setlist (nr1@[pf]) in
    (nl,nr)
  | "mimpL" ->
    let F.LF(l,F.MIMP(f1,f2)) = pf in
    let F.RT(t1,t2,t3) = r in
    let nl0 = delf (F.LF(t3,f2)) (l1@l2) in
    let nr0 = delf (F.LF(t1,f1)) (r1@r2) in 
    let nl = M.setlist (nl0@[pf]) in
    let nr = M.setlist nr0 in
    (nl,nr);;

(* apply a list sl of substitutions (x,y) on a list usedl of pairs (relation * labelled_form) *)
let rec subsusedlist usedl sl =
  let rec subs usedl s acc =
    match usedl with
    | h::t -> 
      let (x,y) = s in
      let (r,lf) = h in
      let ([r1],[lf1]) = ((subsrlist [r] x y),(subsflist [lf] x y)) in
      subs t s (acc@[(r1,lf1)])
    | _ -> acc
  in 
  match sl with
  | h::t -> subsusedlist (subs usedl h []) t 
  | _ -> usedl;;
    
(* print of a list of used pairs of relations and labelled formulae *)
let rec printusedlist usedl =
  match usedl with
  | h::t -> let (r,lf) = h in F.print_rel r;print_string " , ";F.print_lf lf;print_endline "";printusedlist t
  | _ -> ();;

(* print an unsat core *)
let rec printunsatcore unsat =
  let (fl1,fl2) = unsat in
  F.print_lfl fl1;print_string " |- ";F.print_lfl fl2;print_endline "";;

(* build a derivation tree based on a sequent seq *)
(* usedmandr stores a list of (F.RT,F.LF) that has been applied by mandr *)
(* usedmimpl stores a list of (F.RT,F.LF) that has been applied by mimpl *)
(* return a derivation tree and a unsat core sequent (form list * form list) of the end sequent *)
let rec buildptree param seq usedmandr usedmimpl =
  if seq = F.empseq then (F.NULLD,([],[])) (* end of this branch *)
  else    
    let F.SEQ(g,lf,rf) = seq in
    let seq0 = F.SEQ(g,(M.setlist lf),(M.setlist rf)) in
    (*let _ = print_endline "Trying the build a derivation for the sequent:";F.print_seq seq0;print_endline "" in*)
    let rec tryrules rule seq usedmandr usedmimpl =
      (*let _ = print_endline ("Tring the rule "^rule) in*)
      match rule with
      | "id" -> 
	let app = id_f seq in 
	if app = (F.NULLI,F.nulllf) then tryrules "trueR" seq usedmandr usedmimpl 
	else 
	  let (dev,unsat) = buildptree param F.empseq usedmandr usedmimpl in 
	  (F.UD("id",seq,dev),([snd app],[snd app]))
      | "trueR" ->
	let app = truer seq in
	if app = (F.NULLI,F.nulllf) then tryrules "falseL" seq usedmandr usedmimpl 
	else
	  let (dev,unsat) = buildptree param F.empseq usedmandr usedmimpl in
	  (F.UD("trueR",seq,dev),([],[snd app]))
      | "falseL" ->
	let app = falsel seq in
	if app = (F.NULLI,F.nulllf) then tryrules "mtrueR" seq usedmandr usedmimpl
	else 
	  let (dev,unsat) = buildptree param F.empseq usedmandr usedmimpl in
	  (F.UD("falseL",seq,dev),([snd app],[]))
      | "mtrueR" ->
	let app = mtruer seq in
	if app = (F.NULLI,F.nulllf) then tryrules "eqclose" seq usedmandr usedmimpl
	else 
	  let (dev,unsat) = buildptree param F.empseq usedmandr usedmimpl in
	  (F.UD("mtrueR",seq,dev),([],[snd app]))
      | "eqclose" -> 
	let (seq1,subs) = eqclosure seq param in
	if subs = [] then tryrules "mtrueL" seq usedmandr usedmimpl
	else 
	  let nusedmandr = subsusedlist usedmandr subs in
	  let nusedmimpl = subsusedlist usedmimpl subs in
	  (*let _ = print_endline "nusedmandr = ";printusedlist nusedmandr;print_endline "" in
	  let _ = print_endline "nusedmimpl = ";printusedlist nusedmimpl;print_endline "" in*)
	  let (dev,unsat) = buildptree param seq1 nusedmandr nusedmimpl in
	  let newunsat = recunsat seq unsat subs in
	  (F.UD("eqclose",seq,dev),newunsat)
      | "mtrueL" ->
	let app = mtruel seq in
	if app = (F.NULLI,F.nulllf) then tryrules "andL" seq usedmandr usedmimpl
	else 
	  let F.UINF(nseq) = fst app in
	  let pf = snd app in
	  let nusedmandr = subsusedlist usedmandr [("epsilon",(F.lb pf))] in
	  let nusedmimpl = subsusedlist usedmimpl [("epsilon",(F.lb pf))] in
	  (*let _ = print_endline "nusedmandr = ";printusedlist nusedmandr;print_endline "" in
	  let _ = print_endline "nusedmimpl = ";printusedlist nusedmimpl;print_endline "" in*)
	  let (dev,unsat) = (buildptree param (nseq) nusedmandr nusedmimpl) in
	  let newunsat = recunsat seq unsat [("epsilon",(F.lb pf))] in
	  (F.UD("mtrueL",seq,dev),newunsat)
      | "andL" ->
	let app = andl seq in
	if app = (F.NULLI,F.nulllf) then tryrules "impR" seq usedmandr usedmimpl
	else 
	  let F.UINF(nseq) = fst app in
	  let pf = snd app in
	  let (dev,unsat) = (buildptree param (nseq) usedmandr usedmimpl) in
	  if containsunsat seq unsat then (F.UD("andL",seq,dev),unsat)
	  else (F.UD("andL",seq,dev),(nextunsat_u "andL" pf F.nullr unsat))
      | "impR" ->
	let app = impr seq in
	if app = (F.NULLI,F.nulllf) then tryrules "mandL" seq usedmandr usedmimpl
	else 
	  let F.UINF(nseq) = fst app in
	  let pf = snd app in
	  let (dev,unsat) = (buildptree param (nseq) usedmandr usedmimpl) in
	  if containsunsat seq unsat then (F.UD("impR",seq,dev),unsat)
	  else (F.UD("impR",seq,dev),(nextunsat_u "impR" pf F.nullr unsat))
      | "mandL" ->
	let app = mandl seq in
	if app = (F.NULLI,(F.nullr,F.nulllf)) then tryrules "mimpR" seq usedmandr usedmimpl
	else 
	  let F.UINF(nseq) = fst app in
	  let (r,pf) = snd app in
	  let (dev,unsat) = (buildptree param (nseq) usedmandr usedmimpl) in
	  if containsunsat seq unsat then (F.UD("mandL",seq,dev),unsat)
	  else (F.UD("mandL",seq,dev),(nextunsat_u "mandL" pf r unsat))
      | "mimpR" ->  
	let app = mimpr seq in
	if app = (F.NULLI,(F.nullr,F.nulllf)) then tryrules "andR" seq usedmandr usedmimpl
	else 
	  let F.UINF(nseq) = fst app in
	  let (r,pf) = snd app in
	  let (dev,unsat) = (buildptree param (nseq) usedmandr usedmimpl) in
	  if containsunsat seq unsat then (F.UD("mimpR",seq,dev),unsat)
	  else (F.UD("mimpR",seq,dev),(nextunsat_u "mimpR" pf r unsat))
      | "andR" ->
	let app = andr seq in
	if app = (F.NULLI,F.nulllf) then tryrules "impL" seq usedmandr usedmimpl
	else 
	  let F.BINF(nseq1,nseq2) = fst app in
	  let pf = snd app in
	  let (dev1,unsat1) = (buildptree param (nseq1) usedmandr usedmimpl) in
	  if containsunsat seq unsat1 then (F.BD("andR",seq,dev1,F.backjump),unsat1)
	  else 
	    let (dev2,unsat2) = (buildptree param (nseq2) usedmandr usedmimpl) in
	    if containsunsat seq unsat2 then (F.BD("andR",seq,dev1,dev2),unsat2)
	    else (F.BD("andR",seq,dev1,dev2),(nextunsat_b "andR" pf F.nullr unsat1 unsat2))
      | "impL" ->
	let app = impl seq in
	if app = (F.NULLI,F.nulllf) then tryrules "mandR_q" seq usedmandr usedmimpl
	else 
	  let F.BINF(nseq1,nseq2) = fst app in
	  let pf = snd app in
	  let (dev1,unsat1) = (buildptree param (nseq1) usedmandr usedmimpl) in
	  if containsunsat seq unsat1 then (F.BD("impL",seq,dev1,F.backjump),unsat1)
	  else 
	    let (dev2,unsat2) = (buildptree param (nseq2) usedmandr usedmimpl) in
	    if containsunsat seq unsat2 then (F.BD("impL",seq,dev1,dev2),unsat2)
	    else (F.BD("impL",seq,dev1,dev2),(nextunsat_b "impL" pf F.nullr unsat1 unsat2))
      | "mandR_q" -> 
	let app = quick_mandr seq usedmandr in
	if app = (F.NULLI,(F.nullr,F.nulllf)) then tryrules "noninvert" seq usedmandr usedmimpl
	else 
	  let F.BINF(nseq1,nseq2) = fst app in
	  let (r,pf) = snd app in
	  let nusedmandr = usedmandr@[(r,pf)] in
	  (*let _ = print_endline "nusedmandr = ";printusedlist nusedmandr;print_endline "" in*)
	  let (dev1,unsat1) = (buildptree param (nseq1) nusedmandr usedmimpl) in
	  if containsunsat seq unsat1 then (F.BD("mandR_q",seq,dev1,F.backjump),unsat1)
	  else 
	    let (dev2,unsat2) = (buildptree param (nseq2) nusedmandr usedmimpl) in
	    if containsunsat seq unsat2 then (F.BD("mandR_q",seq,dev1,dev2),unsat2)
	    else (F.BD("mandR_q",seq,dev1,dev2),(nextunsat_b "mandR" pf r unsat1 unsat2))
      | "noninvert" ->
	let applymandr seq usedmandr usedmimpl focus =
	  let app = mandr seq usedmandr focus in
	  if app = (F.NULLI,(F.nullr,F.nulllf)) then (F.NULLD,([],[]))
	  else 
	    let F.BINF(nseq1,nseq2) = fst app in
	    let (r,pf) = snd app in
	    let nusedmandr = usedmandr@[(r,pf)] in
	  (*let _ = print_endline "nusedmandr = ";printusedlist nusedmandr;print_endline "" in*)
	    let (dev1,unsat1) = (buildptree param (nseq1) nusedmandr usedmimpl) in
	    if containsunsat seq unsat1 then (F.BD("mandR",seq,dev1,F.backjump),unsat1)
	    else 
	      let (dev2,unsat2) = (buildptree param (nseq2) nusedmandr usedmimpl) in
	      if containsunsat seq unsat2 then (F.BD("mandR",seq,dev1,dev2),unsat2)
	      else (F.BD("mandR",seq,dev1,dev2),(nextunsat_b "mandR" pf r unsat1 unsat2))
	in 
	let applymimpl seq usedmandr usedmimpl focus = 
	  let app = mimpl seq usedmimpl focus in
	  if app = (F.NULLI,(F.nullr,F.nulllf)) then (F.NULLD,([],[]))
	  else 
	    let F.BINF(nseq1,nseq2) = fst app in
	    let (r,pf) = snd app in
	    let nusedmimpl = usedmimpl@[(r,pf)] in
	  (*let _ = print_endline "nusedmimpl = ";printusedlist nusedmimpl;print_endline "" in*)
	    let (dev1,unsat1) = (buildptree param (nseq1) usedmandr nusedmimpl) in
	    if containsunsat seq unsat1 then (F.BD("mimpR",seq,dev1,F.backjump),unsat1)
	    else 
	      let (dev2,unsat2) = (buildptree param (nseq2) usedmandr nusedmimpl) in
	      if containsunsat seq unsat2 then (F.BD("mimpR",seq,dev1,dev2),unsat2)
	      else (F.BD("mimpL",seq,dev1,dev2),(nextunsat_b "mimpL" pf r unsat1 unsat2))
	in
	let rand = Random.int 2 in 
	if rand = 0 then (* apply mandr first*)
	  let (dev1,unsat1) = applymandr seq usedmandr usedmimpl true in
	  if dev1 = F.NULLD then 
	    let (dev2,unsat2) = applymimpl seq usedmandr usedmimpl true in
	    if dev2 = F.NULLD then (* no focus formulae for *R nor -*L *)
	      let (dev3,unsat3) = applymandr seq usedmandr usedmimpl false in
	      if dev3 = F.NULLD then 
		let (dev4,unsat4) = applymimpl seq usedmandr usedmimpl false in
		if dev4 = F.NULLD then (* no applicable formulae for *R nor -*L*)
		  tryrules "str" seq usedmandr usedmimpl
		else (dev4,unsat4)
	      else (dev3,unsat3)
	    else (dev2,unsat2)
	  else (dev1,unsat1)
	else (* apply mimpl first *)
	  let (dev1,unsat1) = applymimpl seq usedmandr usedmimpl true in
	  if dev1 = F.NULLD then 
	    let (dev2,unsat2) = applymandr seq usedmandr usedmimpl true in
	    if dev2 = F.NULLD then (* no focus formulae for *R nor -*L *)
	      let (dev3,unsat3) = applymimpl seq usedmandr usedmimpl false in
	      if dev3 = F.NULLD then 
		let (dev4,unsat4) = applymandr seq usedmandr usedmimpl false in
		if dev4 = F.NULLD then (* no applicable formulae for *R nor -*L*)
		  tryrules "str" seq usedmandr usedmimpl
		else (dev4,unsat4)
	      else (dev3,unsat3)
	    else (dev2,unsat2)
	  else (dev1,unsat1)
      | "str" -> (* compute an iteration of structural rules U',E,A' *)
	let F.UINF(seq1) = comm seq in
	let F.UINF(seq2) = assoc param seq1 in
	let F.UINF(seq3) = comm seq2 in
	let F.UINF(seq4) = unit seq3 in
	if seq4 = seq then (* structural rules are not applicable *)
	  (F.UD("NORULE",F.empseq,F.NULLD),([],[]))
	else 
	  let (dev,unsat) = buildptree param seq4 usedmandr usedmimpl in
	  (F.UD("str",seq,dev),unsat)
      | _ -> (F.UD("NORULE",F.empseq,F.NULLD),([],[]))
    in 
    tryrules "id" seq0 usedmandr usedmimpl;;

(* search for a proof of formula f *)
(* return a derivation tree *)
let proofserach param f = fst (buildptree param (F.SEQ([],[],[F.LF(("a"^(string_of_int !labelnum)),f)])) [] []);;
  
(* Test if a derivation is closed *)
let rec closeddev dev =
  match dev with
  | F.UD(rule,seq,dev) -> if rule = "NORULE" then false else closeddev dev
  | F.BD(rule,seq,dev1,dev2) -> if rule = "NORULE" then false else ((closeddev dev1) && (closeddev dev2))
  | _ -> true;;

(* start a proof procedure *)
let prove param1 f simp ptex =
  let _ =  
    print_endline "\nTrying to find a derivation for the formula: ";
    F.print_justbi_formula f;print_endline "" in
  let starttime = Unix.gettimeofday () in
  let subl = if simp then F.subfsubst f else [] in
  let form = if simp then F.substFormula subl f else f in  
  let dev = proofserach param1 form in
  let finishtime = Unix.gettimeofday () in
  let time = finishtime -. starttime in
  let solved = closeddev dev in
  let infos = if solved then "Proof found:)\n" else "Can't find a proof:(\n" in
  let _ = print_string infos;print_endline ("Time used: "^(string_of_float time)^"s") in
  if ptex = "-o" || ptex = "-o-g" then 
    let fptex = open_out "ptree.tex" in
    let _ =
      let info = if solved then "Proof found" else "Can't find a proof" in
      F.writetexhead fptex;output_string fptex info;
      output_string fptex " for the formula $";F.print_latexbi_formula fptex f;output_string fptex "$\\\\\n";
      (if List.length subl  = 0 then () else (output_string fptex "The sudo formulae are:\\\\$";F.print_latexsudosubs subl fptex;output_string fptex "$\\\\"));
      output_string fptex "The derivation is:\\\\\n";
      output_string fptex "\\begin{center}\n\\tiny\n";
      F.print_latexdev dev fptex ptex;
      output_string fptex "\DisplayProof\n\end{center}\n";
      output_string fptex ("\ \\\nTime used: "^(string_of_float time)^" s\n\\");
      F.writetexend fptex;close_out fptex;
      Sys.command "pdflatex ptree.tex > latex_output.tmp"
    in
    (solved,time)
  else 
    (solved,time);;

(* prove a list of formulae fl *)
let rec provelist param1 fl simp = 
  match fl with
  | h::t -> 
    let (solved,time) = prove param1 h simp "" in
    provelist param1 t simp 
  | _ -> (true,0.0);;

(* parse a list of formulae *)
let parselist sl =
  let rec recparse sl acc =
    match sl with
    | h::t -> recparse t (acc@[(F.parse h)])
    | _ -> acc
  in 
  recparse sl [];;
   
let lspsl = 
  if (Array.length Sys.argv) = 3 then 
    let param1 = Sys.argv.(1) in
    let infile = Sys.argv.(2) in
    let f = F.parse (M.readfile infile) in prove param1 f false ""
  else if (Array.length Sys.argv) = 4 then 
    let param1 = Sys.argv.(1) in
    let param2 = Sys.argv.(2) in
    let infile = Sys.argv.(3) in
    (if param2 = "-o" then 
      let f = F.parse (M.readfile infile) in prove param1 f false "-o"
    else if param2 = "-r" then 
      let fl = parselist (M.readfileall infile) in provelist param1 fl false 
    else if param2 = "-s" then 
      let f = F.parse (M.readfile infile) in prove param1 f true ""
    else failwith "lspsl(): Wrong parameters\nExpect: logic [-r] [-s] [-o] [-g] filename\nwhere logic := -b: BBI, -p: BBI+P, -c: BBI+C, -i: BBI+IU, -d: BBI+D, -pc: BBI+P+C, -pi: BBI+P+IU, -ci: BBI+C+IU, -pd: BBI+P+D, -cd: BBI+C+D, -pci: BBI+P+C+IU, -pcd: BBI+P+C+D")
  else if (Array.length Sys.argv) = 5 then
    let param1 = Sys.argv.(1) in
    let param2 = Sys.argv.(2) in
    let param3 = Sys.argv.(3) in
    let infile = Sys.argv.(4) in
    (if param2 = "-r" && param3 = "-s" then 
      let fl = parselist (M.readfileall infile) in provelist param1 fl true 
    else if param2 = "-s" && param3 = "-o" then
      let f = F.parse (M.readfile infile) in
      prove param1 f true "-o" 
    else if param2 = "-o" && param3 = "-g" then
      let f = F.parse (M.readfile infile) in
      prove param1 f false "-o-g"
    else failwith "lspsl(): Wrong parameters\nExpect: logic [-r] [-s] [-o] [-g] filename\nwhere logic := -b: BBI, -p: BBI+P, -c: BBI+C, -i: BBI+IU, -d: BBI+D, -pc: BBI+P+C, -pi: BBI+P+IU, -ci: BBI+C+IU, -pd: BBI+P+D, -cd: BBI+C+D, -pci: BBI+P+C+IU, -pcd: BBI+P+C+D")
  else if (Array.length Sys.argv) = 6 then
    let param1 = Sys.argv.(1) in
    let param2 = Sys.argv.(2) in
    let param3 = Sys.argv.(3) in
    let param4 = Sys.argv.(4) in
    let infile = Sys.argv.(5) in
    if param2 = "-s" && param3 = "-o" && param4 = "-g" then
      let f = F.parse (M.readfile infile) in
      prove param1 f true "-o-g"
    else failwith "lspsl(): Wrong parameters\nExpect: logic [-r] [-s] [-o] [-g] filename\nwhere logic := -b: BBI, -p: BBI+P, -c: BBI+C, -i: BBI+IU, -d: BBI+D, -pc: BBI+P+C, -pi: BBI+P+IU, -ci: BBI+C+IU, -pd: BBI+P+D, -cd: BBI+C+D, -pci: BBI+P+C+IU, -pcd: BBI+P+C+D"
  else failwith "lspsl(): Wrong parameters\nExpect: logic [-r] [-s] [-o] [-g] filename\nwhere logic := -b: BBI, -p: BBI+P, -c: BBI+C, -i: BBI+IU, -d: BBI+D, -pc: BBI+P+C, -pi: BBI+P+IU, -ci: BBI+C+IU, -pd: BBI+P+D, -cd: BBI+C+D, -pci: BBI+P+C+IU, -pcd: BBI+P+C+D";;
