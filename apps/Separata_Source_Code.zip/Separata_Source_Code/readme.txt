The code in this directory and sub-directories is only for conference
submission purposes. For anonymity we have removed the copyright
notices in our code. The copyright notices in other people's code
remain and they should not be a problem of double blind review.

The code for our tactics is in:
Separation_Algebra/Separata.thy
Separation_Algebra/Separata_Advanced.thy
Separation_Algebra/Separata_Examples.thy

The instantiation of separation algebra into semantics of actions is
in:
Separation_Algebra/Sep_Prod_Instance.thy

Example proofs of properties in semantics of actions is in:
Actions/ActionsSemantics.thy
