module F = BIformulae
module M = Misc

let rec mkcopy flist copynum  =
  let rec copyform f expl expn copyn =
    let rec subsform f expl expn copyn = 
      match expl with
      | h::t -> subsform (F.subsexpf f ("e"^(string_of_int copyn)^(string_of_int expn)) h) t (expn-1) copyn 
      | _ -> f
    in 
    if copyn > 0 then 
      let rint = Random.int 2 in
      if (rint == 0) then
	F.MAND((copyform f expl expn (copyn-1)),(subsform f expl expn copyn))
      else 
	F.MAND((subsform f expl expn copyn),(copyform f expl expn (copyn-1)))
    else F.MTRUE
  in 
  match flist with
  | h::t -> 
     (match h with
     | F.IMP(f1,f2) ->
	let explist = M.setlist (F.findexpf h) in
	let expnum = List.length explist in
	[F.IMP((copyform f1 explist expnum copynum),(copyform f2 explist expnum copynum))]@(mkcopy t copynum)
     | _ -> failwith "the top connective of the input formula should be ->")
  | _ -> [];;
  
let gen = 
  if (Array.length Sys.argv) = 3 then
    let filename = Sys.argv.(1) in
    let copynum = Sys.argv.(2) in
    let fl = F.parselist (M.readfileall filename) in
    let genfl = mkcopy fl (int_of_string copynum) in
    let fp = open_out "gen.txt" in
    let rec printgenfl gfl = 
      match gfl with
      | h::t ->
	 F.print_filebi_formula fp h;
	 output_string fp "\n\n";
	 printgenfl t
      | _ -> ()
    in 
    printgenfl genfl;close_out fp
  else failwith "expected parameters: filename copynum";;
    
    
		     
