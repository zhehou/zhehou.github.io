module F = BIformulae
module M = Misc

let rec printlist l =
  match l with
  | h::t -> print_string ((string_of_int h)^",");printlist t
  | _ -> ();;

let test = 
  if (Array.length Sys.argv) = 4 then
    let solver = Sys.argv.(1) in
    let infile = Sys.argv.(2) in
    let timeout = Sys.argv.(3) in
    let fl = F.parselist (M.readfileall infile) in 
    let rec testfl solver timeout fl acc accfail acctime =
      match fl with
      | h::t -> 
	let fp = open_out "tmp.txt" in
	let _ = F.print_filebi_formula fp h;close_out fp in
	let starttime = Unix.gettimeofday () in
	let ret = Sys.command ("timeout "^timeout^" ./"^solver^" tmp.txt") in
	let finishtime = Unix.gettimeofday () in
	if ret = 0 then 
	  let thistime = finishtime -. starttime in
	  let _ = print_endline ("proof search finished in "^(string_of_float thistime)^"s") in
	  testfl solver timeout t (acc+1) accfail (acctime +. thistime)
	else
	  let _ = print_endline "time out" in
	  testfl solver timeout t (acc+1) (accfail@[acc]) acctime
      | _ -> (acc,accfail,acctime)
    in 
    let (num,fail,time) = testfl solver timeout fl 0 [] 0.0 in
    let failnum = List.length fail in
    let sucnum = num - failnum in
    print_endline ("solver "^solver^" timed out for "^(string_of_int failnum)^" problems:");
    printlist fail;print_endline "";
    print_endline ("average time on successful attempts is: "^(string_of_float (time /. (float_of_int sucnum)))^"s")
  else failwith "expected parameters: solvername [-s] inputfile timeout";;
