module F = BIformulae
module M = Misc

(* let str1 = "mtrue & ls(e1,e2) -> (e1 = e2)";; *)

(* let str2 = "((e1 |-> e2) * true) -> ((e1 |-> e2) -* false)";; *)

(* let str3 = "~((ls(e1,e2) * ~ls(e2,e3)) & ls(e1,e3))";; *)

(* let str4 = "~(ls(e1,e2) & ls(e1,e3) & ~mtrue & ~(e2 = e3))";; *)

(* let str5 = "~(~(ls(e1,e2) -* ~(ls(e1,e2))) & ~mtrue)";; *)

(* let str6 = "~(~((e3 |-> e4) -* ~(ls(e1,e4))) & ((e3 = e4) | ~(ls(e1,e3))))";; *)

(* let str7 = "~(~(~((e2 |-> e3) -* ~(ls(e2,e4))) -* ~(ls(e1,e4))) & ~(ls(e1,e3)))";; *)

(* let str8 = "~(~(~((e2 |-> e3) -* ~(ls(e2,e4))) -* ~(ls(e3,e1))) & (e2 = e4))";; *)

(* let str9 = "~(~((e1 |-> e2) -* ~(ls(e1,e3))) & (~(ls(e2,e3)) | (true & ((e1 |-> e4) * true)) | (e1 = e3)))";; *)

(* let str10 = "~(~((ls(e1,e2) & ~(e1 = e2)) -* ~(ls(e3,e4))) & ~(e3 = e1) & (e4 = e2) & ~(ls(e3,e1)))";; *)

(* let str11 = "~(~(e3 = e4) & ~(ls(e3,e4) -* ~(ls(e1,e2))) & (e4 = e2) & ~(ls(e1,e3)))";; *)

(* let str12 = "~(~((ls(e1,e2) & ~(e1 = e2)) -* ~(ls(e3,e4))) & ~(e3 = e2) & (e3 = e1) & ~(ls(e2,e4)))";; *)

(* let str13 = "~(~(~((e2 |-> e3) -* ~(ls(e2,e4))) -* ~(ls(e3,e1))) & (~(ls(e4,e1)) | (e2 = e4)))";; *)

let rec mkcopy flist copynum  =
  let rec copyform f expl expn copyn =
    let rec subsform f expl expn copyn = 
      match expl with
      | h::t -> subsform (F.subsexpf f ("e"^(string_of_int copyn)^(string_of_int expn)) h) t (expn-1) copyn 
      | _ -> f
    in 
    if copyn > 0 then 
      F.MAND((copyform f expl expn (copyn-1)),(subsform f expl expn copyn))
    else F.MTRUE
  in 
  match flist with
  | h::t -> 
     let explist = M.setlist (F.findexpf h) in
     let expnum = List.length explist in
     [copyform h explist expnum copynum]@(mkcopy t copynum)
  | _ -> [];;
  
let gen = 
  if (Array.length Sys.argv) = 3 then
    let filename = Sys.argv.(1) in
    let copynum = Sys.argv.(2) in
    let fl = F.parselist (M.readfileall filename) in
    let genfl = mkcopy fl (int_of_string copynum) in
    let fp = open_out "gen.txt" in
    let rec printgenfl gfl = 
      match gfl with
      | h::t ->
	 F.print_filebi_formula fp h;
	 output_string fp "\n\n";
	 printgenfl t
      | _ -> ()
    in 
    printgenfl genfl;close_out fp
  else failwith "expected parameters: filename copynum";;
    
    
		     
