(*Lexing*)

let explode s =
  let rec f acc = function
    | -1 -> acc
    | k -> f (s.[k] :: acc) (k - 1)
  in f [] (String.length s - 1)

let matches s = 
  let chars = 
    explode s in 
    fun c -> List.mem c chars;;

let space = matches " \t\n\r"
and punctuation = matches "()[]{},"
and symbolic = matches "~`!@#$%^&*-+=|\\:;<>.?/"
and numeric = matches "0123456789"
and alphanumeric = matches
  "abcdefghijklmnopqrstuvwxyz_'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";;

let isnumstr str = 
  let rec check str n =
    if n < String.length str then
      if numeric str.[n] then check str (n+1)
      else false
    else true
  in 
  check str 0;;

let rec lexwhile prop inp =
  match inp with
  | c::cs when prop c -> let tok,rest = 
      lexwhile prop cs in 
      (Char.escaped c)^tok,rest
  | _ -> "",inp;;


let rec lex inp =
  match snd(lexwhile space inp) with
    [] -> []
  | c::cs -> let prop = if alphanumeric(c) then alphanumeric
                        else if symbolic(c) then symbolic
                        else fun c -> false in
             let toktl,rest = lexwhile prop cs in
             ((Char.escaped c)^toktl)::lex rest;;

(*Parsing*)

type ('a)atom =
| NULL
| EQ of ('a) * ('a) (* = between expressions *)
| PT of ('a) * ('a) (* |-> with 1 field *)
| PT2 of ('a) * ('a) * ('a) (* |-> with 2 fields *)
| LS of ('a) * ('a) (* singly linked list *)
| TR of ('a);; (* binary tree *)
(*| ADD of exp * exp
| SUB of exp * exp
| MLT of exp * exp
| DIV of exp * exp;;*)

type ('a)formula = 
  | TRUE
  | FALSE
  | AP of ('a)atom
  | NOT of ('a)formula
  | EQU of ('a)formula * ('a)formula
  | IMP of ('a)formula * ('a)formula
  | OR of ('a)formula * ('a)formula
  | AND of ('a)formula * ('a)formula
  | MTRUE
  | MFALSE
  | MAND of ('a)formula * ('a)formula
  | MIMP of ('a)formula * ('a)formula
  | MOR of ('a)formula * ('a)formula
  | MNOT of ('a)formula
  | FORALL of string * ('a)formula
  | EXISTS of string * ('a)formula;;

let rec sizeFormula f =
  match f with
  | TRUE 
  | FALSE 
  | MTRUE
  | MFALSE
  | AP _ -> 1
  | NOT f1
  | MNOT f1 
  | FORALL (_,f1) 
  | EXISTS (_,f1) -> succ (sizeFormula f1)
  | EQU (f1, f2) 
  | IMP (f1, f2)
  | OR (f1, f2)  
  | AND (f1, f2)
  | MAND (f1, f2)
  | MOR (f1, f2)
  | MIMP (f1, f2) -> succ (sizeFormula f1 + sizeFormula f2);;

(* computes the size of a formula based on Calcagno's method *)
(* specifically in separaiont logic *)
let rec sizeform f =
  match f with
  | TRUE 
  | FALSE 
  | AP (EQ(_,_)) -> 0
  | MTRUE 
  | AP (LS(_,_))
  | AP (TR(_))
  | AP (PT(_,_)) 
  | AP (PT2(_,_,_)) -> 1
  | FORALL (_,f1)
  | EXISTS (_,f1)
  | NOT f1 -> sizeform f1
  | EQU (f1, f2) 
  | IMP (f1, f2)
  | OR (f1, f2)  
  | AND (f1, f2) -> max (sizeform f1) (sizeform f2)
  | MAND (f1, f2) -> sizeform f1 + sizeform f2
  | MIMP (f1, f2) -> sizeform f2
  | _ -> failwith "sizeform: not a valid separation logic formula!";;

let numConnectives f =
  let num = ref 0 in
  let rec reccheck f =
    match f with
    | TRUE 
    | FALSE 
    | MTRUE
    | MFALSE
    | AP _ -> ()
    | NOT f1
    | MNOT f1 
    | FORALL (_,f1) 
    | EXISTS (_,f1) -> let _ = num := !num + 1 in reccheck f1
    | EQU (f1, f2) 
    | IMP (f1, f2)
    | OR (f1, f2)  
    | AND (f1, f2)
    | MAND (f1, f2)
    | MOR (f1, f2)
    | MIMP (f1, f2) -> let _ = num := !num +1 in reccheck f1; reccheck f2
  in 
  let _ = reccheck f in
  !num;;

(* ------------------------------------------------------------------------- *)
(* General parsing of iterated infixes.                                      *)
(* ------------------------------------------------------------------------- *)

let rec parse_ginfix opsym opupdate sof subparser inp =
  let e1,inp1 = subparser inp in
  if inp1 <> [] & List.hd inp1 = opsym then
     parse_ginfix opsym opupdate (opupdate sof e1) subparser (List.tl inp1)
  else sof e1,inp1;;

let parse_left_infix opsym opcon =
  parse_ginfix opsym (fun f e1 e2 -> opcon(f e1,e2)) (fun x -> x);;

let parse_right_infix opsym opcon =
  parse_ginfix opsym (fun f e1 e2 -> f(opcon(e1,e2))) (fun x -> x);;

let parse_list opsym =
  parse_ginfix opsym (fun f e1 e2 -> (f e1)@[e2]) (fun x -> [x]);;

(* ------------------------------------------------------------------------- *)
(* Other general parsing combinators.                                        *)
(* ------------------------------------------------------------------------- *)

let papply f (ast,rest) = (f ast,rest);;

let nextin inp tok = inp <> [] & List.hd inp = tok;;

let parse_bracketed subparser cbra inp =
  let ast,rest = subparser inp in
  if nextin rest cbra then ast,(List.tl rest)
  else failwith "Closing bracket expected";;

(* ------------------------------------------------------------------------- *)
(* Parsing of formulas, parametrized by atom parser "pfn".                   *)
(* ------------------------------------------------------------------------- *)

let rec parse_atomic_formula (ifn,afn) vs inp =
  match inp with
    [] -> failwith "formula expected"
  | "false"::rest -> FALSE,rest
  | "true"::rest -> TRUE,rest
  | "("::rest -> (try ifn vs inp with Failure _ ->
                  parse_bracketed (parse_formula (ifn,afn) vs) ")" rest)
  | "~"::rest -> papply (fun p -> NOT p)
                        (parse_atomic_formula (ifn,afn) vs rest)
  | "mtrue"::rest -> MTRUE,rest
  | "mfalse"::rest -> MFALSE,rest
  | "-"::rest -> papply (fun p -> MNOT p)
                        (parse_atomic_formula (ifn,afn) vs rest)
  | "forall"::x::rest ->
        parse_quant (ifn,afn) (x::vs) (fun (x,p) -> FORALL(x,p)) x rest
  | "exists"::x::rest ->
        parse_quant (ifn,afn) (x::vs) (fun (x,p) -> EXISTS(x,p)) x rest
  | _ -> afn vs inp
and parse_quant (ifn,afn) vs qcon x inp =
   match inp with
     [] -> failwith "Body of quantified term expected"
   | y::rest ->
        papply (fun fm -> qcon(x,fm))
               (if y = "." then parse_formula (ifn,afn) vs rest
                else parse_quant (ifn,afn) (y::vs) qcon y rest)
and parse_formula (ifn,afn) vs inp = (* right associativity is used here*)
   parse_right_infix "<->" (fun (p,q) -> EQU(p,q))
     (parse_right_infix "-*" (fun (p,q) -> MIMP(p,q))
         (parse_right_infix "->" (fun (p,q) -> IMP(p,q))
             (parse_right_infix "+" (fun (p,q) -> MOR(p,q))
		(parse_right_infix "|" (fun (p,q) -> OR(p,q))
		   (parse_right_infix "*" (fun (p,q) -> MAND(p,q))
		      (parse_right_infix "&" (fun (p,q) -> AND(p,q))		       
			 (parse_atomic_formula (ifn,afn) vs))))))) inp;;

(* ------------------------------------------------------------------------- *)
(* Generic function to impose lexing and exhaustion checking on a parser.    *)
(* ------------------------------------------------------------------------- *)

let make_parser pfn s =
  let expr,rest = pfn (lex(explode s)) in
  if rest = [] then expr else failwith "Unparsed input";;

(* ------------------------------------------------------------------------- *)
(* Parsing of propositional formulas.                                        *)
(* ------------------------------------------------------------------------- *)

type prop = P of string;;

let pname(P s) = s;;

let parse_propvar vs inp =
  match inp with
    p::oinp 
      when p <> "(" -> 
	if p = "null" then AP(NULL),oinp
	else if p = "ls" then (* parse ls(e1,e2) *)
	  (match oinp with
	  | lp::e1::c::e2::rp::rest ->
	    if lp = "(" && c = "," && rp = ")" then
	      AP(LS(e1,e2)),rest
	    else failwith "parse_propvar: not a valid list structure!"
	  | _ -> failwith "parse_propvar: list structure too short!")
	else if p = "tr" then (* parse tr(e) *)
	  (match oinp with
	  | lp::e::rp::rest ->
	    if lp = "(" && rp = ")" then
	      AP(TR(e)),rest
	    else failwith "parse_propvar: not a valid tree structure!"
	  | _ -> failwith "parse_propvar: tree structure too short!")
	else if (List.length oinp) > 1 then (* parse = or |-> *)
	  let op = List.hd oinp in
	  let q = List.nth oinp 1 in
	  let rest = List.tl (List.tl oinp) in
	  match op with
	  | "=" -> AP(EQ(p,q)),rest
	  | "|->" -> 
	    if List.length rest > 0 then 
	      if (List.hd rest) = "," then  
		if List.length rest > 1 then
		  let rest1 = List.tl (List.tl rest) in
		  let r = List.nth rest 1 in
		  AP(PT2(p,q,r)),rest1
		else failwith "parse_propvar: not a valid pointsto expression"
	      else AP(PT(p,q)),rest
	    else failwith "parse_propvar: not a valid pointsto expression, might forget a ) "
	  | _ -> failwith "parse_propvar: not a valid expression"
	else failwith "parse_propvar: not a valid expression"
  | _ -> failwith "parse_propvar";;

let parse_bi_formula = make_parser
  (parse_formula ((fun _ _ -> failwith ""),parse_propvar) []);;

(* ------------------------------------------------------------------------- *)
(* Set this up as default for quotations.                                    *)
(* ------------------------------------------------------------------------- *)

let parse = parse_bi_formula;;

(* ------------------------------------------------------------------------- *)
(* Printing of formulas, parametrized by atom printer.                       *)
(* ------------------------------------------------------------------------- *)

let bracket p n f x y =
  (if p then print_string "(" else ());
  Format.open_box n; f x y; Format.close_box();
  (if p then print_string ")" else ());;

let rec strip_quant fm =
  match fm with
    FORALL(x,(FORALL(y,p) as yp)) | EXISTS(x,(EXISTS(y,p) as yp)) ->
        let xs,q = strip_quant yp in x::xs,q
  |  FORALL(x,p) | EXISTS(x,p) -> [x],p
  | _ -> [],fm;;

let rec do_list f l =
  match l with
    [] -> ()
  | h::t -> f(h); do_list f t;;

(* always print brackets for binary connectives *)
let print_formula pfn =
  let rec print_formula pr fm =
    match fm with
      | FALSE -> print_string "false"
      | TRUE -> print_string "true"
      | AP(pargs) -> pfn pr pargs
      | NOT(p) -> bracket (pr > 10) 1 (print_prefix 10) "~" p
      | AND(p,q) -> bracket (true) 0 (print_infix 8 "&") p q
      | OR(p,q) ->  bracket (true) 0 (print_infix  6 "|") p q
      | IMP(p,q) ->  bracket (true) 0 (print_infix 4 "->") p q
      | EQU(p,q) ->  bracket (true) 0 (print_infix 2 "<->") p q
      | MTRUE -> print_string "mtrue"
      | MFALSE -> print_string "mfalse"
      | MNOT(p) -> bracket (pr > 9) 1 (print_prefix 9) "-" p
      | MAND(p,q) -> bracket (true) 0 (print_infix 7 "*") p q
      | MOR(p,q) ->  bracket (true) 0 (print_infix  5 "+") p q
      | MIMP(p,q) ->  bracket (true) 0 (print_infix 3 "-*") p q
      | FORALL(x,p) -> bracket (true) 2 print_qnt "forall" (strip_quant fm)
      | EXISTS(x,p) -> bracket (true) 2 print_qnt "exists" (strip_quant fm)
  and print_qnt qname (bvs,bod) =
    print_string qname;
    do_list (fun v -> print_string " "; print_string v) bvs;
    print_string "."; Format.open_box 0;
    print_formula 0 bod;
    Format.close_box()
  and print_prefix newpr sym p = 
   print_string sym; print_formula (newpr+1) p
  and print_infix newpr sym p q = (* right associativity is used here*)
    print_formula (newpr+1) p;
    print_string(" "^sym^" "); Format.print_space();
    print_formula newpr q in
    print_formula 0;;

let print_biformula pfn fm =
  Format.open_box 0; print_string "<<";
  Format.open_box 0; print_formula pfn fm; Format.close_box();
  print_string ">>"; Format.close_box();;

let print_justformula pfn fm =
  Format.open_box 0; 
  Format.open_box 0; print_formula pfn fm; Format.close_box();
  Format.close_box();;

(* ------------------------------------------------------------------------- *)
(* Printer.                                                                  *)
(* ------------------------------------------------------------------------- *)

let print_propvar prec p = 
  if p = NULL then print_string "null"
  else 
    match p with
    | EQ(x,y) -> print_string ("("^x^" = "^y^")")
    | PT(x,y) -> print_string ("("^x^" |-> "^y^")")
    | PT2(x,y,z) -> print_string ("("^x^" |-> "^y^","^z^")")
    | LS(x,y) -> print_string ("ls("^x^","^y^")")
    | TR(x) -> print_string ("tr("^x^")")
    | _ -> failwith "print_propvar: not a valid atomic formula";;

let print_bi_formula = print_biformula print_propvar;;

let print_justbi_formula = print_justformula print_propvar;;
(*#install_printer print_bi_formula;;*)


(* ------------------------------------------------------------------------- *)
(* Print a formula in a file                                                 *)
(* ------------------------------------------------------------------------- *)

let filebracket p n f x y fp =
  (if p then output_string fp "(" else ());
  Format.open_box n;f x y;Format.close_box();
  (if p then output_string fp")" else ());;

(* print an atomic formula to file *)
let print_filepropvar fp p = 
  if p = NULL then output_string fp "null"
  else 
    match p with
    | EQ(x,y) -> output_string fp ("("^x^" = "^y^")")
    | PT(x,y) -> output_string fp  ("("^x^" |-> "^y^")")
    | PT2(x,y,z) -> output_string fp  ("("^x^" |-> "^y^","^z^")")  
    | LS(x,y) -> output_string fp ("ls("^x^","^y^")")
    | TR(x) -> output_string fp ("tr("^x^")")
    | _ -> failwith "print_propvar: not a valid atomic formula";;

(* always print brackets for binary connectives *)
let print_fileformula fp =
  let rec print_fileformula pr fp fm =
    match fm with
      | FALSE -> output_string fp "false "
      | TRUE -> output_string fp "true "
      | AP(pargs) -> print_filepropvar fp pargs
      | NOT(p) -> filebracket (pr > 10) 1 (print_prefix 10) "~ " p fp
      | AND(p,q) -> filebracket (true) 0 (print_infix 8 "& ") p q fp
      | OR(p,q) -> filebracket (true) 0 (print_infix 6 "| ") p q fp
      | IMP(p,q) -> filebracket (true) 0 (print_infix 4 "-> ") p q fp
      | EQU(p,q) ->  filebracket (true) 0 (print_infix 2 "<-> ") p q fp
      | MTRUE -> output_string fp "mtrue "
      | MFALSE -> output_string fp "mfalse "
      | MNOT(p) -> filebracket (pr > 9) 1 (print_prefix 9) "-" p fp
      | MAND(p,q) -> filebracket (true) 0 (print_infix 7 "*") p q fp
      | MOR(p,q) ->  filebracket (true) 0 (print_infix  5 "+") p q fp
      | MIMP(p,q) ->  filebracket (true) 0 (print_infix 3 "-*") p q fp
      | FORALL(x,p) -> filebracket (true) 2 print_fileqnt "forall" (strip_quant fm) fp
      | EXISTS(x,p) -> filebracket (true) 2 print_fileqnt "exists" (strip_quant fm) fp
  and print_fileqnt qname (bvs,bod) =
    output_string fp qname;
    do_list (fun v -> output_string fp " "; output_string fp v) bvs;
    output_string fp "."; Format.open_box 0;
    print_fileformula 0 fp bod;
    Format.close_box()
  and print_prefix newpr sym p = 
    output_string fp sym; print_fileformula (newpr+1) fp p
  and print_infix newpr sym p q = (* right associativity is used here*)
    print_fileformula (newpr+1) fp p;
    output_string fp (" "^sym^" ");output_string fp " ";
    print_fileformula newpr fp q 
  in
    print_fileformula 0 fp;;

let print_filebi_formula fp = print_fileformula fp;;

(* ------------------------------------------------------------------------- *)
(* OCaml won't let us use the constructors.                                  *)
(* ------------------------------------------------------------------------- *)

let mk_and p q = AND(p,q)  
and mk_or p q = OR(p,q)
and mk_imp p q = IMP(p,q) 
and mk_equ p q = EQU(p,q)
and mk_not p = NOT(p)
and mk_mand p q = MAND(p,q)
and mk_mor p q = MOR(p,q)
and mk_mimp p q = MIMP(p,q)
and mk_mnot p = MNOT(p);;

(* ------------------------------------------------------------------------- *)
(* Destructors.                                                              *)
(* ------------------------------------------------------------------------- *)

let dest_equ fm =
  match fm with EQU(p,q) -> (p,q) | _ -> failwith "dest_que";;

let dest_not fm =
  match fm with NOT(p) -> p | _ -> failwith "dest_not";;

let rec negations fm = 
  match fm with NOT(p) -> negations p | _ -> [fm];;

let dest_and fm =
  match fm with AND(p,q) -> (p,q) | _ -> failwith "dest_and";;

let rec conjuncts fm =
  match fm with AND(p,q) -> conjuncts p @ conjuncts q | _ -> [fm];;

let dest_or fm =
  match fm with OR(p,q) -> (p,q) | _ -> failwith "dest_or";;

let rec disjuncts fm =
  match fm with OR(p,q) -> disjuncts p @ disjuncts q | _ -> [fm];;

let dest_imp fm =
  match fm with IMP(p,q) -> (p,q) | _ -> failwith "dest_imp";;

let dest_mnot fm =
  match fm with MNOT(p) -> p | _ -> failwith "dest_mnot";;

let rec mnegations fm = 
  match fm with MNOT(p) -> mnegations p | _ -> [fm];;

let dest_mand fm =
  match fm with MAND(p,q) -> (p,q) | _ -> failwith "dest_mand";;

let rec mconjuncts fm =
  match fm with MAND(p,q) -> mconjuncts p @ mconjuncts q | _ -> [fm];;

let dest_mor fm =
  match fm with MOR(p,q) -> (p,q) | _ -> failwith "dest_mor";;

let rec mdisjuncts fm =
  match fm with MOR(p,q) -> mdisjuncts p @ mdisjuncts q | _ -> [fm];;

let dest_mimp fm =
  match fm with MIMP(p,q) -> (p,q) | _ -> failwith "dest_mimp";;

let antecedent fm = fst(dest_imp fm);;
let consequent fm = snd(dest_imp fm);;

(* ------------------------------------------------------------------------- *)
(* Apply a function to the atoms, otherwise keeping structure.               *)
(* ------------------------------------------------------------------------- *)

let rec onatoms f fm =
  match fm with
    AP a -> f a
  | NOT(p) -> NOT(onatoms f p)
  | AND(p,q) -> AND(onatoms f p,onatoms f q)
  | OR(p,q) -> OR(onatoms f p,onatoms f q)
  | IMP(p,q) -> IMP(onatoms f p,onatoms f q)
  | EQU(p,q) -> EQU(onatoms f p,onatoms f q)
  | MNOT(p) -> MNOT(onatoms f p)
  | MAND(p,q) -> MAND(onatoms f p,onatoms f q)
  | MOR(p,q) -> MOR(onatoms f p,onatoms f q)
  | MIMP(p,q) -> MIMP(onatoms f p,onatoms f q)
  | _ -> fm;;

(* ------------------------------------------------------------------------- *)
(* Formula analog of list iterator "itlist".                                 *)
(* ------------------------------------------------------------------------- *)

let rec overatoms f fm b =
  match fm with
    AP(a) -> f a b
  | NOT(p) | MNOT(p) -> overatoms f p b
  | AND(p,q) | OR(p,q) | IMP(p,q) | EQU(p,q) | MAND(p,q) | MOR(p,q) | MIMP(p,q) ->
        overatoms f p (overatoms f q b)
  | _ -> b;;

(** The constant True.
 *)
let const_true = TRUE;;

(** The constant False.
 *)
let const_false = FALSE;;
    
(** Constructs an atomic proposition.
    @param s The name of the atomic proposition.
    @return The atomic proposition with name s.
 *)
let const_ap s = AP (s);;

(** Negates a formula.
    @param f A formula.
    @return The negation of f.
 *)
let const_not f = NOT f;;

(** Constructs an equivalence from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The equivalence f1 <=> f2.
 *)
let const_equ f1 f2 = EQU (f1, f2);;

(** Constructs an implication from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The implication f1 => f2.
 *)
let const_imp f1 f2 = IMP (f1, f2);;

(** Constructs an or-formula from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The formula f1 | f2.
 *)
let const_or f1 f2 = OR (f1, f2);;

(** Constructs an and-formula from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The formula f1 & f2.
 *)    
let const_and f1 f2 = AND (f1, f2);;

(* The constant multiplicative truth *)
let const_mtrue = MTRUE;;

(* The constant multiplicative false *)
let const_mfalse = MFALSE;;

(** Multiplicatively negates a formula.
    @param f A formula.
    @return The negation of f.
 *)
let const_mnot f = MNOT f;;

(** Constructs a multiplicative implication from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The multiplicative implication f1 -* f2.
 *)
let const_mimp f1 f2 = MIMP (f1, f2);;

(** Constructs a multiplicative or-formula from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The formula f1 + f2.
 *)
let const_mor f1 f2 = MOR (f1, f2);;

(** Constructs a multiplicative and-formula from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The formula f1 * f2.
 *)    
let const_mand f1 f2 = MAND (f1, f2);;

(* ------------------------------------------------------------------------- *)
(* Additional functions.                                                     *)
(* ------------------------------------------------------------------------- *)

(* test if f1 is a subformula of f2 *)
let rec issubFormula f1 f2 =
  if f1 = f2 then true
  else 
    match f2 with
    | TRUE
    | FALSE
    | MTRUE
    | MFALSE
    | AP _ -> false
    | NOT f3 
    | MNOT f3 
    | FORALL (_,f3) 
    | EXISTS (_,f3) -> issubFormula f1 f3
    | EQU (f3,f4)
    | IMP(f3,f4)
    | OR(f3,f4)
    | AND(f3,f4)
    | MAND(f3,f4)
    | MOR(f3,f4) 
    | MIMP(f3,f4) -> issubFormula f1 f3 || issubFormula f1 f4;;

(** Substitutes some subformulae in a formula.
    @param subl A list of pairs (subf, fp) 
    where subf is a subformula in f and fp is a formula.
    @param f A formula.
    @return A formula f' where each subformula subf
    such that (subf, fp) is contained in subl is replaced by fp.
    NOTE THAT if subf is atomic, it's not substituted!
 *)
let rec substFormula subl f =
  if List.mem_assoc f subl then List.assoc f subl 
  else
    match f with
    | TRUE
    | FALSE 
    | MTRUE
    | MFALSE
    | AP _ -> f
    | NOT f1 -> NOT(substFormula subl f1)
    | MNOT f1 -> MNOT(substFormula subl f1)
    | FORALL (x,f1) -> FORALL(x,(substFormula subl f1)) 
    | EXISTS (x,f1) -> EXISTS(x,(substFormula subl f1))
    | EQU (f1, f2) -> EQU((substFormula subl f1),(substFormula subl f2))
    | IMP (f1, f2) -> IMP((substFormula subl f1),(substFormula subl f2))
    | OR (f1, f2) -> OR((substFormula subl f1),(substFormula subl f2))
    | AND (f1, f2) -> AND((substFormula subl f1),(substFormula subl f2))
    | MAND (f1, f2) -> MAND((substFormula subl f1),(substFormula subl f2))
    | MOR (f1, f2) -> MOR((substFormula subl f1),(substFormula subl f2))
    | MIMP (f1, f2) -> MIMP((substFormula subl f1),(substFormula subl f2));;

(* find all the expressions/values in a formula f *)
let rec findexpf f =
  match f with
  | TRUE
  | FALSE
  | MTRUE
  | MFALSE 
  | AP(NULL) -> [] 
  | AP(EQ(e1,e2))
  | AP(PT(e1,e2)) -> [e1;e2]
  | AP(PT2(e1,e2,e3)) -> [e1;e2;e3]
  | AP(LS(e1,e2)) -> [e1;e2]
  | AP(TR(e1)) -> [e1]
  | NOT f3 
  | MNOT f3 
  | FORALL (_,f3) 
  | EXISTS (_,f3) -> findexpf f3
  | EQU (f3,f4)
  | IMP(f3,f4)
  | OR(f3,f4)
  | AND(f3,f4)
  | MAND(f3,f4)
  | MOR(f3,f4) 
  | MIMP(f3,f4) -> (findexpf f3)@(findexpf f4)
  | _ -> failwith "findexpf(): not a valid formula";;

(* check if the formula f contains a variable v *)
let rec hasvar f v =
  match f with
  | TRUE 
  | FALSE 
  | MTRUE
  | MFALSE -> false
  | AP(af) -> 
    (match af with
    | NULL -> false
    | EQ(e1,e2) -> if (e1 = v) || (e2 = v) then true else false
    | PT(e1,e2) -> if (e1 = v) || (e2 = v) then true else false
    | PT2(e1,e2,e3) -> if (e1 = v) || (e2 = v) || (e3 = v) then true else false
    | LS(e1,e2) -> if (e1 = v) || (e2 = v) then true else false
    | TR(e1) -> if (e1 = v) then true else false) 
  | MNOT(f1)
  | NOT(f1) -> hasvar f1 v
  | EQU(f1,f2) 
  | IMP(f1,f2) 
  | OR(f1,f2)
  | AND(f1,f2)
  | MAND(f1,f2)
  | MIMP(f1,f2)
  | MOR(f1,f2) -> (hasvar f1 v) || (hasvar f2 v)
  | FORALL(x,f1)
  | EXISTS(x,f1) -> hasvar f1 v
  | _ -> failwith "hasvar(): not a valid formula";;

(* perform an exp/value substitution [e1/e2] on an exp/value e *)
(* if e is "nil" or a string of number, do not substitute *)
let subsexp e e1 e2 =
  if e = "nil" || isnumstr e then e 
  else if e2 <> "nil" && not(isnumstr e2) && e2 = e then e1
  else if (e2 = "nil" || isnumstr e2) && e1 <> "nil" && not(isnumstr e1) && e1 = e then e2
  else if (e1 = "nil" || isnumstr e1) && (e2 = "nil" || isnumstr e2) then 
    let testprint = print_string ("e1 = "^e1^", e2 = "^e2) in
    failwith "subsexp: e1 and e2 are both nil or numbers"
  else e;;

(* perform a list of exp/value substitutions expsl on a single exp/value e *)
let rec subsexple e expsl =
  match expsl with
  | h::t -> let (e1,e2) = h in subsexple (subsexp e e1 e2) t
	    (* if e2 = e then subsexple e1 t else subsexple e t *)
  | _ -> e;;

(* perform the substitution [e1/e2] of two expressions in an *)
(* atomic formula e |-> e or e = e  *)
(* nil is the constant expression that can't be substituted *)
let subsexpaf af e1 e2 =
  match af with
  | EQ(exp1,exp2) -> EQ((subsexp exp1 e1 e2),(subsexp exp2 e1 e2))
  | PT(exp1,exp2) -> PT((subsexp exp1 e1 e2),(subsexp exp2 e1 e2))
  | PT2(exp1,exp2,exp3) -> PT2((subsexp exp1 e1 e2),(subsexp exp2 e1 e2),(subsexp exp3 e1 e2))
  | LS(exp1,exp2) -> LS((subsexp exp1 e1 e2),(subsexp exp2 e1 e2))
  | TR(exp1) -> TR(subsexp exp1 e1 e2)
  | _ -> failwith "subsexpaf(): not a valid atomic formula";;

(* perform the substitution [e1/e2] of two expressions/variables in a formula f *)
let rec subsexpf f e1 e2 =
  match f with
  | TRUE -> TRUE
  | FALSE -> FALSE
  | AP(NULL) -> AP(NULL)
  | AP(af) -> AP(subsexpaf af e1 e2)
  | NOT(f1) -> NOT(subsexpf f1 e1 e2)
  | EQU(f1,f2) -> EQU((subsexpf f1 e1 e2),(subsexpf f2 e1 e2))
  | IMP(f1,f2) -> IMP((subsexpf f1 e1 e2),(subsexpf f2 e1 e2))
  | OR(f1,f2) -> OR((subsexpf f1 e1 e2),(subsexpf f2 e1 e2))
  | AND(f1,f2) -> AND((subsexpf f1 e1 e2),(subsexpf f2 e1 e2))
  | MTRUE -> MTRUE
  | MFALSE -> MFALSE
  | MAND(f1,f2) -> MAND((subsexpf f1 e1 e2),(subsexpf f2 e1 e2))
  | MIMP(f1,f2) -> MIMP((subsexpf f1 e1 e2),(subsexpf f2 e1 e2))
  | MOR(f1,f2) -> MOR((subsexpf f1 e1 e2),(subsexpf f2 e1 e2))
  | MNOT(f1) -> MNOT(subsexpf f1 e1 e2)
  | FORALL(x,f1) -> 
    let x1 = if x = e2 then e1 else x in FORALL(x1,(subsexpf f1 e1 e2))
  | EXISTS(x,f1) -> 
    let x1 = if x = e2 then e1 else x in EXISTS(x1,(subsexpf f1 e1 e2));;

(* get the list of binded variables in the formula f *)
let getvars f =
  let rec findvars f vars =
    match f with
    | TRUE
    | FALSE 
    | MTRUE
    | MFALSE 
    | AP(_) -> []
    | MNOT(f1)
    | NOT(f1) -> findvars f1 vars
    | EQU(f1,f2) 
    | IMP(f1,f2) 
    | OR(f1,f2)
    | AND(f1,f2)
    | MAND(f1,f2)
    | MIMP(f1,f2)
    | MOR(f1,f2) -> (findvars f1 vars)@(findvars f2 vars)
    | FORALL(x,f1)
    | EXISTS(x,f1) -> [x]@(findvars f1 vars)
  in findvars f [];;

(* check if f contains quantifiers *)
let rec hasquant f =
  match f with
    | TRUE 
    | FALSE 
    | MTRUE 
    | MFALSE 
    | AP(_) -> false
    | MNOT(f1)
    | NOT(f1) -> hasquant f1
    | EQU(f1,f2) 
    | IMP(f1,f2) 
    | OR(f1,f2)
    | AND(f1,f2)
    | MAND(f1,f2)
    | MIMP(f1,f2)
    | MOR(f1,f2) -> (hasquant f1) || (hasquant f2)
    | FORALL(x,f1)
    | EXISTS(x,f1) -> true;;

(* rename a formula so that each binded variable is different *)
(* return a formula *)
let renamevar f =
  let varnum = ref 0 in
  let rec rename f =
    match f with
    | TRUE -> TRUE
    | FALSE -> FALSE
    | AP(NULL) -> AP(NULL)
    | AP(af) -> AP(af)
    | NOT(f1) -> NOT(rename f1)
    | EQU(f1,f2) -> let f1t = rename f1 in let f2t = rename f2 in EQU(f1t,f2t)
    | IMP(f1,f2) -> let f1t = rename f1 in let f2t = rename f2 in IMP(f1t,f2t)
    | OR(f1,f2) -> let f1t = rename f1 in let f2t = rename f2 in OR(f1t,f2t)
    | AND(f1,f2) -> let f1t = rename f1 in let f2t = rename f2 in AND(f1t,f2t)
    | MTRUE -> MTRUE
    | MFALSE -> MFALSE
    | MAND(f1,f2) -> let f1t = rename f1 in let f2t = rename f2 in MAND(f1t,f2t)
    | MIMP(f1,f2) -> let f1t = rename f1 in let f2t = rename f2 in MIMP(f1t,f2t)
    | MOR(f1,f2) -> let f1t = rename f1 in let f2t = rename f2 in MOR(f1t,f2t)
    | MNOT(f1) -> MNOT(rename f1)
    | FORALL(x,f1) -> 
      if hasquant f1 then 
	let f1t = rename f1 in
	let _ = varnum := !varnum + 1 in
	subsexpf (FORALL(x,f1t)) ("x"^(string_of_int (!varnum))) x
      else 
	let _ = varnum := !varnum + 1 in
	subsexpf (FORALL(x,f1)) ("x"^(string_of_int (!varnum))) x
    | EXISTS(x,f1) -> 
      if hasquant f1 then 
	let f1t = rename f1 in
	let _ = varnum := !varnum + 1 in
	subsexpf (EXISTS(x,f1t)) ("x"^(string_of_int (!varnum))) x
      else 
	let _ = varnum := !varnum + 1 in
	subsexpf (EXISTS(x,f1)) ("x"^(string_of_int (!varnum))) x
  in 
  rename f;;

(* simplify a formula by deleting vacuous quantifiers *)
(* !!! this function must be applied after renaming the variables *)
let rec simpvacquant f =
  match f with
  | TRUE -> TRUE
  | FALSE -> FALSE
  | AP(NULL) -> AP(NULL)
  | AP(af) -> AP(af)
  | NOT(f1) -> NOT(simpvacquant f1)
  | EQU(f1,f2) -> EQU((simpvacquant f1),(simpvacquant f2))
  | IMP(f1,f2) -> IMP((simpvacquant f1),(simpvacquant f2))
  | OR(f1,f2) -> OR((simpvacquant f1),(simpvacquant f2))
  | AND(f1,f2) -> AND((simpvacquant f1),(simpvacquant f2))
  | MTRUE -> MTRUE
  | MFALSE -> MFALSE
  | MAND(f1,f2) -> MAND((simpvacquant f1),(simpvacquant f2))
  | MIMP(f1,f2) -> MIMP((simpvacquant f1),(simpvacquant f2))
  | MOR(f1,f2) -> MOR((simpvacquant f1),(simpvacquant f2))
  | MNOT(f1) -> MNOT(simpvacquant f1)
  | FORALL(x,f1) -> 
    if hasquant f1 then 
      let f1t = simpvacquant f1 in
      if hasvar f1t x then FORALL(x,f1t) else f1t
    else 
      if hasvar f1 x then FORALL(x,f1) else f1
  | EXISTS(x,f1) -> 
    if hasquant f1 then 
      let f1t = simpvacquant f1 in
      if hasvar f1t x then EXISTS(x,f1t) else f1t
    else 
      if hasvar f1 x then EXISTS(x,f1) else f1;;
	
(* Define the labelled formula *)
type ('a)lformula = LF of string * ('a)formula;; 

let nulllf = LF("-1",FALSE);;

(* Define the relations in the lablled system *)
type ('a)relation = RT of string * string * string;; 

let nullr = RT("-1","-1","-1");;

(* for determining HC *)
let nullr2 = RT("-2","-2","-2");;

(* test if a relational atom is invalid *)
let invalidrel r = let RT(s1,s2,s3) = r in if (s1 = "-1") || (s2 = "-1") || (s3 = "-1") || (s1 = "-2") || (s2 = "-2") || (s3 = "-2") then true else false;;

(* test if a list of relational atoms contains invalid ones *)
let rec invalidrell rl = 
  match rl with
  | h::t -> if invalidrel h then true else invalidrell t
  | _ -> false;;

(* Define the sequent for formulae *)
type ('a)sequent = SEQ of (('a)relation list) * (('a)lformula list) * (('a)lformula list);;

(* Define the sequent for relations *)
type ('a)rsequent = RSEQ of (('a)relation list) * (('a)relation list);;

(* get the label of a labelled formula *)
let lb lf =
  match lf with
    | LF(label,formula) -> label
    | _ -> failwith "lb(): Note a well-formed labelled formula\n";;

(* get the formula of a labelled formula *)
let fm lf =
  match lf with
    | LF(label,formula) -> formula
    | _ -> failwith "fm(): Note a well-formed labelled formula\n";;

let empseq = SEQ([],[],[]);;

(* Define the formulae derivation tree*)
type ('a)derivation =
  | UD of string * ('a)sequent * ('a)derivation
  | BD of string * ('a)sequent * ('a)derivation * ('a)derivation 
  | NULLD;;

let backjump = UD("bj",empseq,NULLD);;

(* Define the informulation needed for an inference*)
type ('a)inference =
  | BINF of ('a)sequent * ('a)sequent
  | UINF of ('a)sequent
  | NULLI;;

(* Get the variable number from the label*)
let getnum s = 
  if s = "epsilon" then -1 
  else int_of_string (String.sub s 1 ((String.length s)-1));;

(* Test if a formula is a proposition *)
let isprop f =  match f with | AP _ -> true | _ -> false;;

(* perform exp/value substitution [e1/e2] on a list of labelled formulae fl *)
let rec subsexpfl lfl e1 e2 =
  match lfl with
  | h::t -> [LF((lb h),(subsexpf (fm h) e1 e2))]@(subsexpfl t e1 e2)
  | _ -> [];;

(* perform a list of exp/value substitution expsl on a list of labelled formulae fl *)
let rec subsexplfl lfl expsl =
  match expsl with
  | h::t -> subsexplfl (subsexpfl lfl (fst h) (snd h)) t
  | _ -> lfl;;

(* perform a list of exp/value substitutions expsl on a labelled formula lf *)
let rec subsexpllf lf expsl =
  match expsl with
  | h::t -> subsexpllf (LF((lb lf),(subsexpf (fm lf) (fst h) (snd h)))) t
  | _ -> lf;;

(* given a list g of ternary relations and a label l *)
(* test if l occurs in g *)
let rec oldlabelg l g =
  match g with
  | h::t -> 
    let RT(a1,a2,a3) = h in 
    if a1 = l || a2 = l || a3 = l then true 
    else oldlabelg l t
  | _ -> false;;

(* given a list lfl of labelled formulae, and a label l *)
(* test if l occurs in lfl *)
let rec oldlabellfl l lfl =
  match lfl with
  | h::t -> 
    let label = lb h in if label = l then true else oldlabellfl l t 
  | _ -> false;;

(* given a sequent seq and a label l, test if l occurs in seq *)
let rec oldlabelseq l seq =
  let SEQ(g,lf,rf) = seq in
  if oldlabelg l g || oldlabellfl l (lf@rf) then true else false;;

(* parse a list of string to a list of formulae*)
let parselist list =
  let rec recparse list acc = 
    match list with
    | h::t -> recparse t (acc@[(simpvacquant (renamevar (parse h)))])
    | _ -> acc
  in 
  recparse list [];;

(************** the following functions print on screen **********************)

(* print a pair of strings (x,y), representing a substitution [x/y] *)
let print_pair p = print_string ("("^(fst p)^","^(snd p)^")");;

(* print a list of pairs *)
let rec print_pairl pl = 
  match pl with
  | h::t -> print_pair h;print_string ";";print_pairl t
  | _ -> ();;

(* Print a relation *)
let print_rel r =
  match r with
    (*| REQ(s1,s2) -> print_string  ("("^s1^"="^s2^")")*)
    | RT(s1,s2,s3) -> print_string ("("^s1^","^s2^"|>"^s3^")")
    | _ -> failwith "print_rel(): invalid relation\n";;

(* Print a list of relations *)
let rec print_rell rl =
  match rl with
    | h::t -> 
	print_rel h;
	if (List.length t) > 0 then 
	  (print_string ";";
	   print_rell t)
	else print_rell t
    | _ -> ();;

(* print a list of lists of relations *)
let rec print_relll rll =
  match rll with
  | h::t -> print_rell h;print_endline "";print_relll t
  | _ -> ();;

(* Print the sequent of relations *)
let print_rseq rs =
  match rs with
    | RSEQ(lr,rr) -> print_rell lr;print_string " |-r ";print_rell rr
    | _ -> failwith "Can't print this relation sequent\n";;

(* Print a list of relational sequents *)
let rec print_rseqs rss =
  match rss with
  | h::t -> print_rseq h;print_endline "";print_rseqs t
  | _ -> print_endline "";;

(* print a labelled formula *)
let print_lf lf = print_string ((lb lf)^":");print_justbi_formula (fm lf);;

(* Print a list of labelled formulae *)
let rec print_lfl lfl =
  match lfl with
  | h::t -> 
    if (List.length t) > 0 then (print_lf h;print_string ";";print_lfl t)
    else (print_lf h;print_lfl t)
  | _ -> ();;

(* Print a sequent of labelled formuale *)
let rec print_seq seq =
  match seq with
  | SEQ(g,lf,rf) -> print_rell g;print_string "||";print_lfl lf;print_string " |- ";print_lfl rf
  | _ -> failwith "print_seq(): invalid sequent";;

let rec printlist = function
  |[] -> print_string ""
  |h::t -> print_string (h^";"); printlist t;; 

let rec printlistlist = function
  |[] -> printlist [] 
  |h::t -> print_string "["; printlist h; print_string"]"; printlistlist t;;

(* print a 2-lvl tree *)
let printl2tree t =
  print_string ((fst t)^" = ");printlist (snd t);;

(* print a list of 2-lvl trees *)
let rec printl2trees ts =
  match ts with
  | h::t -> printl2tree h;print_endline "";printl2trees t
  | _ -> ();;

(* print a pair *)
let printpair p = print_string ("("^(fst p)^","^(snd p)^")");;

(* print a list of pairs *)
let rec printpairlist pl =
  match pl with
  | h::t -> printpair h;printpairlist t
  | _ -> print_endline "";;

(************** the following functions print in latex files ******************)

(* Print the 2 level tree with 1 parent and multiple children*)
let rec print_latexl2trees l fp =
  let rec print_latexlist l fp =
    match l with
    | h::t -> 
      output_string fp h;
      if (List.length t) > 0 then output_string fp ";";
      print_latexlist t fp
    | _ -> ()
  in
  match l with
  | h::t -> output_string fp ("$"^(fst h)^"=\{");print_latexlist (snd h) fp;output_string fp ("\}$\\\\\n");print_latexl2trees t fp
  | _ -> ();;

let writetexhead fp =
  let _ = print_endline "writing latex head" in
  let _ = output_string fp "\\documentclass[landscape,11pt]{article}\n" in
  let _ = output_string fp "\\usepackage[paperheight=5in,paperwidth=100in]{geometry}\n" in
  let _ = output_string fp "\\usepackage{amssymb}\n" in
  let _ = output_string fp "\\usepackage{amsthm}\n" in
  let _ = output_string fp "\\usepackage{amsmath}\n" in
  let _ = output_string fp "\\usepackage{bussproofs}\n" in
  let _ = output_string fp "\\newcommand{\lexcl}[0]{{\ensuremath{-\!\!\!<\;}}}\n" in
  let _ = output_string fp "\\newcommand{\mexcl}[0]{{\ensuremath{-\!\!\!\!-\!\!\!\!\\times\;}}}\n" in
  let _ = output_string fp "\\newcommand{\limp}[0]{\ensuremath{\\rightarrow}}\n" in
  let _ = output_string fp "\\newcommand{\llimp}[0]{\ensuremath{\multimap}}\n" in
  let _ = output_string fp "\\newcommand{\mimp}[0]{\ensuremath{{-\!*\;}}}\n" in
  let _ = output_string fp "\\newcommand{\ie}[0]{\ensuremath{\vartriangleright}}\n" in
  let _ = output_string fp "\\newcommand{\\turnstile}[0]{\ensuremath{\vdash}}\n" in
  let _ = output_string fp "\\newcommand{\simp}[0]{\ensuremath{\\triangleright}}\n" in
  let _ = output_string fp "\\newcommand{\mor}[0]{\ensuremath{\overset{*}\lor}}\n" in
  let _ = output_string fp "\\newcommand{\mnot}[0]{\ensuremath{\sim\!\!\;}}\n" in
  let _ = output_string fp "\\newcommand{\mand}[0]{\ensuremath{*}}\n" in
  let _ = output_string fp "\\title{Derivation}\n" in
  let _ = output_string fp "\\author{Zh\'e}\n" in
    output_string fp "\\begin{document}\n";;

let writetexend fp =
  let _ = print_endline  "writing latex end\n" in
    output_string fp "\n\\end{document}\n";;

let latexbracket p n f x y fp =
  (if p then output_string fp "(" else ());
  Format.open_box n;f x y;Format.close_box();
  (if p then output_string fp")" else ());;

(* print an expression to latex file *)
let print_latexpropvar fp p = 
  if p = NULL then output_string fp "\textbf{null}"
  else 
    match p with
    | EQ(x,y) -> output_string fp ("("^x^" = "^y^")")
    | PT(x,y) -> output_string fp  ("("^x^" \mapsto "^y^")")
    | PT2(x,y,z) -> output_string fp  ("("^x^" \mapsto "^y^","^z^")")
    | LS(x,y) -> output_string fp ("ls("^x^","^y^")")
    | TR(x) -> output_string fp ("tr("^x^")")
    | _ -> failwith "print_propvar: not a valid expression";;

let print_latexformula fp =
  let rec print_latexformula pr fp fm =
    match fm with
      | FALSE -> output_string fp "\\bot "
      | TRUE -> output_string fp "\\top "
      | AP(pargs) -> print_latexpropvar fp pargs
      | NOT(p) -> latexbracket (true) 1 (print_prefix 10) "\lnot " p fp
      | AND(p,q) -> latexbracket (true) 0 (print_infix 8 "\land ") p q fp
      | OR(p,q) ->  latexbracket (true) 0 (print_infix  6 "\lor ") p q fp
      | IMP(p,q) -> latexbracket (true) 0 (print_infix 4 "\limp ") p q fp
      | EQU(p,q) ->  latexbracket (true) 0 (print_infix 2 "\leftrightarrow ") p q fp
      | MTRUE -> output_string fp "\\top^* "
      | MFALSE -> output_string fp "\bot^* "
      | MNOT(p) -> latexbracket (pr > 9) 1 (print_prefix 9) "\mnot " p fp
      | MAND(p,q) -> latexbracket (true) 0 (print_infix 7 "\mand ") p q fp
      | MOR(p,q) ->  latexbracket (true) 0 (print_infix  5 "\mor ") p q fp
      | MIMP(p,q) ->  latexbracket (true) 0 (print_infix 3 "\mimp ") p q fp
      | FORALL(x,p) -> latexbracket (true) 2 print_latexqnt "forall" (strip_quant fm) fp
      | EXISTS(x,p) -> latexbracket (true) 2 print_latexqnt "exists" (strip_quant fm) fp
  and print_latexqnt qname (bvs,bod) =
    output_string fp ("\\"^qname);
    do_list (fun v -> output_string fp " "; output_string fp v) bvs;
    output_string fp "."; Format.open_box 0;
    print_latexformula 0 fp bod;
    Format.close_box()
  and print_prefix newpr sym p = 
    output_string fp sym; print_latexformula (newpr+1) fp p
  and print_infix newpr sym p q = (* right associativity is used here*)
    print_latexformula (newpr+1) fp p;
    output_string fp (" "^sym^" ");output_string fp " ";
    print_latexformula newpr fp q 
  in
    print_latexformula 0 fp;;

let print_latexbi_formula fp = print_latexformula fp;;

let print_latex_label fp str =
  if str = "epsilon" then output_string fp ("\\"^str) else output_string fp str;;

(* Print a labelled formula *)    
let print_latexformula lf fp =
  match lf with
    | LF(l,f) -> print_latex_label fp l;output_string fp ":";print_latexbi_formula fp f
    | _ -> failwith "No formula to print\n";;

(* Print a list of labelled formulae *)
let rec print_latexformulal lfl fp =
  match lfl with
    | h::t -> 
	print_latexformula h fp;
	if (List.length t) > 0 then 
	  (output_string fp ";";
	   print_latexformulal t fp)
	else print_latexformulal t fp
    | _ -> ();;

(* Print a relation *)
let print_latexrel r fp =
  match r with
    (*| REQ(s1,s2) -> output_string fp "(";print_latex_label fp s1;output_string fp "=";print_latex_label fp s2;output_string fp ")"*)
    | RT(s1,s2,s3) -> output_string fp "(";print_latex_label fp s1;output_string fp ",";print_latex_label fp s2;output_string fp "\simp ";print_latex_label fp s3;output_string fp ")"
    | _ -> failwith "print_latexrel(): invalid relation\n";;

(* Print a list of relations *)
let rec print_latexrell rl fp =
  match rl with
    | h::t -> 
	print_latexrel h fp;
	if (List.length t) > 0 then 
	  (output_string fp ";";
	   print_latexrell t fp)
	else print_latexrell t fp
    | _ -> ();;

(* Print a sequent of formulae *)
let print_latexseq s fp dis =
  match s with
    | SEQ(g,lf,rf) -> 
      if dis = "-p-g" then
	(print_latexrell g fp;output_string fp "||";print_latexformulal lf fp;output_string fp " \vdash ";print_latexformulal rf fp)
      else 
	(print_latexformulal lf fp;output_string fp " \vdash ";print_latexformulal rf fp)
    | _ -> failwith "print_latexseq(): invalid sequent";;


(* Print the sequent of relations *)
let print_latexrseq rs fp =
  match rs with
    | RSEQ(lr,rr) -> print_latexrell lr fp;output_string fp " \vdash_R ";print_latexrell rr fp
    | _ -> failwith "Can't print this relation sequent\n";;

(* Print a list of relational sequents in latex *)
let rec print_latexrseqs rseqs fp =
  match rseqs with
  | h::t -> print_latexrseq h fp;output_string fp "\\\\\n";print_latexrseqs t fp
  | _ -> output_string fp " \\ \\\\\n";;

(* Print the rule *)
let print_latexrule str fp =
  match str with
    | "trueR" -> output_string fp "\\top R"
    | "falseL" -> output_string fp "\\bot L"
    | "mtrueL" -> output_string fp "\\top^* L"
    | "mtrueR" -> output_string fp "\\top^* R"
    | "id" -> output_string fp "id"
    | "notL" -> output_string fp "\lnot L"
    | "notR" -> output_string fp "\lnot R"  
    | "orL"  -> output_string fp "\lor L"
    | "orR"  -> output_string fp "\lor R"  
    | "andL" -> output_string fp "\land L"
    | "andR" -> output_string fp "\land R"
    | "impL" -> output_string fp "\limp L"
    | "impR" -> output_string fp "\limp R"
    | "mandL" -> output_string fp "\mand L"
    | "mandR" -> output_string fp "\mand R"
    | "mandR_q" -> output_string fp "\mand R_q"
    | "mimpL" -> output_string fp "\mimp L"
    | "mimpL_q" -> output_string fp "\mimp L_q"
    | "mimpR" -> output_string fp "\mimp R"
    | "idmtrueR" -> output_string fp "id \\ or \\ \\top^* R"
    | "eqclose" -> output_string fp "eq"
    | "str" -> output_string fp "str"
    | "bj" -> output_string fp "bj"
    | "existsL" -> output_string fp "\exists L"
    | "existsR" -> output_string fp "\exists R"
    | "forallL" -> output_string fp "\forall L"
    | "forallR" -> output_string fp "\forall R"
    | "equalityL" -> output_string fp "= L"
    | "equalityR" -> output_string fp "= R"
    | "pointstoL1" -> output_string fp "\mapsto L_1"
    | "pointstoL2" -> output_string fp "\mapsto L_2"
    | "pointstoL3" -> output_string fp "\mapsto L_3"
    | "pointstoL4" -> output_string fp "\mapsto L_4"
    | "pointstoL41" -> output_string fp "\mapsto L_4'"  
    | "pointstoL5" -> output_string fp "\mapsto L_5"
    | "pointstonil" -> output_string fp "\mapsto nil"
    | "sll1" -> output_string fp "LS_1"
    | "sll2" -> output_string fp "LS_2"
    | "sll3" -> output_string fp "LS_3"
    | "sll4" -> output_string fp "LS_4"
    | "sll5" -> output_string fp "LS_5"
    | "sll6" -> output_string fp "LS_6"
    | "sll7" -> output_string fp "LS_7"
    | "sll8" -> output_string fp "LS_8"
    | "sll9" -> output_string fp "LS_9"
    | "sll10" -> output_string fp "LS_{10}"
    | "ds" -> output_string fp "IC" 
    | "btr1" -> output_string fp "TR_1"
    | "btr2" -> output_string fp "TR_2"
    | "btr3" -> output_string fp "TR_3"
    | "btr4" -> output_string fp "TR_4"
    | "btr5" -> output_string fp "TR_5"
    | "btr6" -> output_string fp "TR_6"
    | "cs" -> output_string fp "CS"
    | "h" -> output_string fp "H"
    | "he" -> output_string fp "HE"
    | "hhe" -> output_string fp "H\& HE"
    | "he2" -> output_string fp "HE_2"
    | "hc" -> output_string fp "HC"
    | "id2" -> output_string fp "id_2"
    | "cut=" -> output_string fp "cut_="
    | "invexpsub" -> output_string fp "InvES"
    | "rhe" -> output_string fp "HE"
    | "NULL" -> output_string fp "null"
    | "NORULE" -> output_string fp "norule"
    | _ -> failwith ("print_latexrule(): "^str^" is not a valid rule\n");;

let rec print_latexdev dev fp dis =
  match dev with
    | NULLD -> output_string fp "\AxiomC{}\n"
    | UD(str,seq,ndev) ->
      if str = "bj" then output_string fp "\AxiomC{backjump}\n"
      else 
	begin
	  print_latexdev ndev fp dis;output_string fp "\RightLabel{\\tiny $";
	  print_latexrule str fp;output_string fp "$}\n";
	  output_string fp "\UnaryInfC{$";print_latexseq seq fp dis;
	  output_string fp "$}\n"
	end 
    | BD(str,seq,nd1,nd2) -> 
	begin
	  print_latexdev nd1 fp dis;print_latexdev nd2 fp dis;
	  output_string fp "\RightLabel{\\tiny $";print_latexrule str fp;
	  output_string fp "$}\n";output_string fp "\BinaryInfC{$";
	  print_latexseq seq fp dis;output_string fp "$}\n"
	end 
    | _ -> failwith "print_latexdev(): Not a valid derivation\n";;

let rec print_latexsudosubs subl fp =
  match subl with
  | h::t -> let (f1,f2) = h in 
	    print_latexbi_formula fp f1;output_string fp " = ";print_latexbi_formula fp f2;output_string fp "\\\\";
	    print_latexsudosubs t fp
  | _ -> ();;
