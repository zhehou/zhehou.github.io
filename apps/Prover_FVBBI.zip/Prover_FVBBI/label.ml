module L = Labelinterm16
module F = BIformulae
module M = Misc

let label =
  if (Array.length Sys.argv) = 2 then 
    let infile = Sys.argv.(1) in
    let f = F.parse (M.readfile infile) in
    let _ = L.strategyproof_test f false in ()
  else if (Array.length Sys.argv) = 3 then 
    let param1 = Sys.argv.(1) in
    let infile = Sys.argv.(2) in
    let f = F.parse (M.readfile infile) in
    (if param1 = "-o" then 
	let _ = L.strategyproof f false in ()
     else if param1 = "-p" then   
       let _ = L.strategyproof_test f true in ())
  else failwith ("Wrong parameters");;



