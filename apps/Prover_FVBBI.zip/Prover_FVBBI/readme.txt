use "make" to compile and generate the executable file

Specify a formula in a file (e.g., input.txt), the syntax is:
f ::= true | false | mtrue | f & f | f -> f | f * f | f -* f |

to prove a formula in the file filename, use the command
./label filename

to prove a formula, and see the process on screen, use 
./label -p filename

to prove a formula, and output a pdf file (ptree.pdf) of derivation, use
./label -o filename

See example formulae in files *.bi
