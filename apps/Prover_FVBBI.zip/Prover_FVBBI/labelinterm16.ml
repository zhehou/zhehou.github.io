module F = BIformulae
module M = Misc

(* Define the labelled formula *)
type ('a)lformula = LF of string * ('a)F.formula | NULLLF;;

(* Define the relations in the lablled system *)
type relation =
  | REQ of string * string 
  | RT of string * string * string
  | NULLR;; 

(* Define the sequent for formulae *)
type ('a)sequent = SEQ of (('a)lformula list) * (('a)lformula list);;

(* get the label of a labelled formula *)
let lb lf =
  match lf with
    | LF(label,formula) -> label
    | _ -> failwith "lb(): Note a well-formed labelled formula\n";;

(* get the formula of a labelled formula *)
let fm lf =
  match lf with
    | LF(label,formula) -> formula
    | _ -> failwith "fm(): Note a well-formed labelled formula\n";;

let empseq = SEQ([],[]);;

(* Define the sequent for relations *)
type rsequent = RSEQ of (relation list) * (relation list);;

(* Define the formulae derivation tree*)
type ('a)derivation =
  | UD of string * ('a)sequent * ('a)derivation
  | BD of string * ('a)sequent * ('a)derivation * ('a)derivation 
  | NULLD;;

(* Define the informulation needed for an inference*)
type ('a)inference =
  | BINF of ('a)sequent * ('a)sequent
  | UINF of ('a)sequent
  | NULLI;;

(* A global variable for the number of label eignvariables *)
let labelnum = ref 0;;
(* A global variable for the number of label variables *)
(*let labelvnum = ref 0;;
(* A global variable for the total number of variables *)
let labeln = ref 0;;*)

(************************* for printing on screen ***********************************)
(* Print a relation *)
let print_rel r =
  match r with
    | REQ(s1,s2) -> print_string  ("("^s1^"="^s2^")")
    | RT(s1,s2,s3) -> print_string ("("^s1^","^s2^"|>"^s3^")")
    | NULLR -> print_string "NULL relation detected!"
    | _ -> failwith "Can't print this relation\n";;

(* Print a list of relations *)
let rec print_rell rl =
  match rl with
    | h::t -> 
	print_rel h;
	if (List.length t) > 0 then 
	  (print_string ";";
	   print_rell t)
	else print_rell t
    | _ -> ();;

(* print a list of lists of relations *)
let rec print_relll rll =
  match rll with
  | h::t -> print_rell h;print_endline "";print_relll t
  | _ -> ();;

(* Print the sequent of relations *)
let print_rseq rs =
  match rs with
    | RSEQ(lr,rr) -> print_rell lr;print_string " |-r ";print_rell rr
    | _ -> failwith "Can't print this relation sequent\n";;

(* Print a list of relational sequents *)
let rec print_rseqs rss =
  match rss with
  | h::t -> print_rseq h;print_endline "";print_rseqs t
  | _ -> print_endline "";;

(* Print a list of labelled formulae *)
let rec print_lfl lfl =
  match lfl with
  | h::t -> 
    if (List.length t) > 0 then (print_string ((lb h)^":");F.print_justbi_formula (fm h);print_string ";";print_lfl t)
    else (print_string ((lb h)^":");F.print_justbi_formula (fm h);print_lfl t)
  | _ -> ();;

(* Print a sequent of labelled formuale *)
let rec print_seq seq =
  match seq with
  | SEQ(lf,rf) -> print_lfl lf;print_string " |- ";print_lfl rf;;

(* print a 2-lvl tree *)
let printl2tree t =
  print_string ((fst t)^" = ");M.printlist (snd t);;

(* print a list of 2-lvl trees *)
let rec printl2trees ts =
  match ts with
  | h::t -> printl2tree h;print_endline "";printl2trees t
  | _ -> ();;

(* print a pair *)
let printpair p = print_string ("("^(fst p)^","^(snd p)^")");;

(* print a list of pairs *)
let rec printpairlist pl =
  match pl with
  | h::t -> printpair h;printpairlist t
  | _ -> print_endline "";;

(************************* for printing on screen ***********************************)

(* check if a label is free-variable *)
let isfree s = if s.[0] = 'x' then true else false;;

let iseigen s = if s.[0] = 'a' then true else false;;

(* Get the variable number from the label*)
let getnum s = 
  if s = "epsilon" then -1 
  else if (Str.first_chars s 2) = "ax" then int_of_string (String.sub s 2 ((String.length s)-2))
  else int_of_string (String.sub s 1 ((String.length s)-1));;

(* Test if a formula is a proposition *)
let isprop f =
  match f with
    | F.AP _ -> true
    | _ -> false;;

(* Test if a relation is a ternary relation *)
let istern r = match r with | RT(s1,s2,s3) -> true | _ -> false;;

(* Find the atmoic formula f in the list of labelled formulae l. Return the label (a number) if found, otherwise return "-1". *)
let rec findatomf f l free =
  match l with 
    | h::t -> 
      begin
	if free = 0 then  (* do not require free variable *)
	  begin if (fm h) = f then (lb h) else findatomf f t 0 end 
	else (* require free variable *) 
	  begin if ((fm h) = f) && (isfree (lb h)) then (lb h) else findatomf f t 1 end 
      end 
    | _ -> "-1";;

(* Find a labelled formula in l that matches lf in the id rule *)
let rec findlf lf l =
  match l with
  | h::t -> if ((fm h) = (fm lf)) && ((lb h) = (lb lf)) then (lb h) else findlf lf t
  | _ -> "-1";;

(* Find atmoic formulas that are equal to f in the list of labelled formulae l. Return the list of labels if found, otherwise return []. *)
let findatomfs f l free =
  let rec findas f l free acc = 
    match l with 
    | h::t -> 
      begin
	if free = 0 then  (* do not require free variable *)
	  begin if (fm h) = f then findas f t 0 (acc@[(lb h)]) else findas f t 0 acc end 
	else (* require free variable *) 
	  begin if ((fm h) = f) && (isfree (lb h)) then findas f t 1 (acc@[(lb h)]) else findas f t 1 acc end 
      end 
    | _ -> acc
  in
  findas f l free [];;

(* Find formulae that are equal to f in the list of labelled formulae l. Return the list of labels if found, otherwise return []. *)
let findfs f l free =
  let rec finds f l free acc = 
    match l with 
    | h::t -> 
      begin
	if free = 0 then  (* do not require free variable *)
	  begin if (fm h) = f then finds f t 0 (acc@[(lb h)]) else finds f t 0 acc end 
	else (* require free variable *) 
	  begin if ((fm h) = f) && (isfree (lb h)) then finds f t 1 (acc@[(lb h)]) else finds f t 1 acc end 
      end 
    | _ -> acc
  in
  finds f l free [];;

(* Make pairs from a label and a list of labels *)
let rec mkpairs lb lbs acc =
    match lbs with 
    | h::t -> mkpairs lb t (acc@[(lb,h)])
    | _ -> acc;;

(* Find the a set of pairs of identical propositions in lf and rf, if found, return the list of pairs of labels, otherwise return []. *)
let findids l r =
  let rec recfind l r acc = 
    match l with 
    | h::t -> 
      if isprop (fm h) then
	(let label2 = findlf h r in (* try to find a prop with the same label*)
	 if label2 = "-1" then 
	   (let labels = findatomfs (fm h) r 0 in
	    recfind t r (acc@(mkpairs (lb h) labels [])))
	 else [(lb h, lb h)])
      else recfind t r acc
    | _ -> acc
  in 
  recfind l r [];;

(* Find the a set of pairs of identical propositions in lf and rf, if found, return the list of pairs of labels, otherwise return []. Require eigenv must be matched with freev*)
let findids_strict l r =
  let rec recfind l r acc = 
    match l with 
    | h::t -> 
      if isprop (fm h) then
	(let label2 = findlf h r in (* try to find a prop with the same label*)
	 if label2 = "-1" then 
	   (if isfree (lb h) then 
	       let labels = findatomfs (fm h) r 0 in
	       recfind t r (acc@(mkpairs (lb h) labels []))
	    else let labels = findatomfs (fm h) r 1 in
		 recfind t r (acc@(mkpairs (lb h) labels [])))
	 else [(lb h, lb h)])
      else recfind t r acc
    | _ -> acc
  in 
  recfind l r [];;

(* Find the a set of pairs of identical formulae in lf and rf, if found, return the list of pairs of labels, otherwise return []. *)
let findids_f l r =
  let rec recfind_f l r acc = 
    match l with 
    | h::t -> 
      (let label2 = findlf h r in (* try to find a formulae with the same label*)
       if label2 = "-1" then 
	 (let labels = findfs (fm h) r 0 in
	  recfind_f t r (acc@(mkpairs (lb h) labels [])))
       else [(lb h, lb h)])
    | _ -> acc
  in 
  recfind_f l r [];;

(* check if the eigenvariable is created before the free-variable *)
let canequal s1 s2 =
  if isfree s1 then
    begin
      if isfree s2 then true
      else 
	if (getnum s1) > (getnum s2) then true 
	else false 
    end 
  else if isfree s2 then 
    begin
      if (getnum s1) < (getnum s2) then true
      else false
    end 
  else true;; (* allows a constraint of the form (Ai = Aj) *)

(* check if candidate pairs for id satisfy canequal(), filter off the unsat ones *)
let filterpairs pairs =
  let rec filter pairs acc =
    match pairs with
    | h::t -> if canequal (fst h) (snd h) then filter t (acc@[h]) else filter t acc
    | _ -> acc
  in 
  filter pairs [];;

(* make REQ() from a list of labels *)
let mkeqrs pairs =
  let rec mkeq pairs acc =
    match pairs with 
    | h::t -> mkeq t (acc@[REQ((fst h), (snd h))])
    | _ -> acc
  in mkeq pairs [];;

(* simplify pairs by deleting identical ones *)
let simpairs pairs =
  let rec simp pairs acc =
    match pairs with
    | h::t -> if (List.mem h t) || (List.mem ((snd h),(fst h)) t) then simp t acc else simp t (acc@[h])
    | _ -> acc
  in
  simp pairs [];;

(* The id rule *)
let id inf =
  match inf with 
    | UINF s ->
	begin 
	  match s with
	    | SEQ(lf,rf) ->
	      let pairstmp = findids_strict lf rf in (** changed to findids_stric from findids ***)
	      let pairs = simpairs pairstmp in
	      if (List.length pairs) = 0 then (RSEQ([],[]),NULLI)
	      else if ((fun p -> if (fst p) = (snd p) then true else false) (List.nth pairs 0)) then (RSEQ([],[]),inf) (*Only have to check the 1st pair*)
	      else 
		begin
		  let fpairs = filterpairs pairs in
		  let eqrs = mkeqrs fpairs in
		  if (List.length eqrs) = 0 then (RSEQ([],[]),NULLI)
		  else (RSEQ([],eqrs),inf)
		end 
	    | _ -> failwith "id(): Not a valid sequent\n"
	end
    | _ -> failwith "id(): Note a valid inference\n";;

(* The id rule that concludes on identical formulae as well *)
let id_f inf =
  match inf with 
    | UINF s ->
	begin 
	  match s with
	    | SEQ(lf,rf) ->
		let pairs = findids_f lf rf in
		  if (List.length pairs) = 0 then (RSEQ([],[]),NULLI)
		  else if ((fun p -> if (fst p) = (snd p) then true else false) (List.nth pairs 0)) then (RSEQ([],[]),inf) (*Only have to check the 1st pair*)
		  else 
		    begin
		      let fpairs = filterpairs pairs in
		      let eqrs = mkeqrs fpairs in
		      if (List.length eqrs) = 0 then (RSEQ([],[]),NULLI)
		      else (RSEQ([],eqrs),inf)
		    end 
	    | _ -> failwith "id(): Not a valid sequent\n"
	end
    | _ -> failwith "id(): Note a valid inference\n";;

(* Find the identical propositions with the same label in lf and rf, if found, return the labels, otherwise return ("-1","-1"). *)
let rec findsimpid l r =
  match l with 
    | h::t ->
	if isprop (fm h) then
	  let label2 = findlf h r in
	    if label2 = "-1" then findsimpid t r else true
	else findsimpid t r
    | _ -> false;;

(* A simplified id rule that only deal with prop with the same label *)
let simpid inf = 
  match inf with
  | UINF s ->
    begin
      match s with
      | SEQ(lf,rf) -> if findsimpid lf rf then (RSEQ([],[]),inf) else (RSEQ([],[]),NULLI)
      | _ -> failwith "simpid(): Not a valid sequent\n"
    end 
  | _ -> failwith "simpid(): Not a valid inference\n";;

(* Find the identical formulae with the same label in lf and rf, if found, return the labels, otherwise return ("-1","-1"). *)
let rec findsimpid_f l r =
  match l with 
    | h::t ->
      let label2 = findlf h r in
      if label2 = "-1" then findsimpid t r else true
    | _ -> false;;

(* A simplified id rule that only deal with formulae with the same label *)
let simpid_f inf = 
  match inf with
  | UINF s ->
    begin
      match s with
      | SEQ(lf,rf) -> if findsimpid_f lf rf then (RSEQ([],[]),inf) else (RSEQ([],[]),NULLI)
      | _ -> failwith "simpid_f(): Not a valid sequent\n"
    end 
  | _ -> failwith "simpid_f(): Not a valid inference\n";;

(* A simplified stopstar R ruel that only deal with topstar labelled with epsilon *)
let simptopstarr inf =
  match inf with
  | UINF s -> 
    begin
      match s with
      | SEQ(lr,rf) -> let label = findlf (LF("epsilon",F.MTRUE)) rf in 
		      if label = "-1" then (RSEQ([],[]), NULLI)
		      else (RSEQ([],[]),inf)
      | _ -> failwith "simptopstarr(): Not a valid sequent\n"
    end 
  | _ -> failwith "simptopstarr(): Not a valid inference\n";;
		   
(* The \bot L rule *)
let botl inf = 
  match inf with 
    | UINF s ->
	begin 
	  match s with
	    | SEQ(lf,rf) ->
		let label = findatomf F.FALSE lf 0 in
		  if label = "-1" then (RSEQ([],[]),NULLI) else (RSEQ([],[]),inf)
	    | _ -> failwith "botl(): Not a valid sequent\n"
	end 
    | _ -> failwith "botl(): Not a valid inference\n";;

(* The \top R rule *)
let topr inf = 
  match inf with 
    | UINF s ->
	begin
	  match s with
	    | SEQ(lf,rf) ->
		let label = findatomf F.TRUE rf 0 in
		  if label = "-1" then (RSEQ([],[]),NULLI) else (RSEQ([],[]),inf)
	    | _ -> failwith "topr(): Not a valid sequent\n"
	end 
    | _ -> failwith "topr(): Not a valid inference\n";;

(* Test if a list of labelled formulae contains and *)
let rec hasand l =
  match l with
    | h::t -> 
	begin
	  match (fm h) with 
	    | F.AND(f1,f2) -> h
	    | _ -> hasand t
	end 
    | _ -> NULLLF;;
	  

(* The and L rule *)
let andl inf =
  match inf with
    | UINF s ->
	begin
	  match s with 
	    | SEQ(lf,rf) ->
		begin
		  let pf = hasand lf in
		    if pf = NULLLF then (RSEQ([],[]),NULLI)
		    else 
		      let lf1 = M.subtlist pf lf in
		      let label = lb pf in
			match (fm pf) with  
			  | F.AND(f1,f2) -> (RSEQ([],[]),UINF(SEQ((lf1@[LF(label,f1);LF(label,f2)]),rf)))
			  | _ -> failwith "andl(): pf is not AND\n"
		end
	    | _ -> failwith "andl(): Not a valid sequent\n"  
	end 
    | _ -> failwith "andl(): Not a valid inference\n";;

(* The and R rule *)
let andr inf =
  match inf with
    | UINF s ->
	begin 
	  match s with
	    | SEQ(lf,rf) ->
		begin
		  let pf = hasand rf in
		    if pf = NULLLF then (RSEQ([],[]),NULLI)
		    else 
		      let rf1 = M.subtlist pf rf in
		      let label = lb pf in
			match (fm pf) with
			  | F.AND(f1,f2) -> (RSEQ([],[]),BINF(SEQ(lf,(rf1@[LF(label,f1)])),SEQ(lf,(rf1@[LF(label,f2)]))))
			  | _ -> failwith "andr(): pf is not AND\n"
		end 
	    | _ -> failwith "andr(): Not a valid sequent\n" 
	end 
    | _ -> failwith "andr(): Not a valid inference\n";;

(* Test if a list of labelled formulae contains imp *)
let rec hasimp l =
  match l with
    | h::t -> 
	begin 
	  match (fm h) with 
	    | F.IMP(f1,f2) -> h
	    | _ -> hasimp t
	end 
    | _ -> NULLLF;;

(* The imp L rule *)
let impl inf =
  match inf with 
    | UINF s ->
	begin
	  match s with
	    | SEQ(lf,rf) -> 
		begin
		  let pf = hasimp lf in
		    if pf = NULLLF then (RSEQ([],[]),NULLI)
		    else 
		      let lf1 = M.subtlist pf lf in
		      let label = lb pf in
			match (fm pf) with
			  | F.IMP(f1,f2) -> (RSEQ([],[]),BINF(SEQ(lf1,(rf@[LF(label,f1)])),SEQ((lf1@[LF(label,f2)]),rf)))
			  | _ -> failwith "impl(): pf is not IMP\n"
		end 
	    | _ -> failwith "impl(): Not a valid sequent\n"
	end 
    | _ -> failwith "impl(): Not a valid inference\n";;

(* The imp R rule *)
let impr inf = 
  match inf with 
    | UINF s ->
	begin 
	  match s with
	    | SEQ(lf,rf) ->
		begin 
		  let pf = hasimp rf in
		    if pf = NULLLF then (RSEQ([],[]),NULLI)
		    else 
		      let rf1 = M.subtlist pf rf in
		      let label = lb pf in
			match (fm pf) with
			  | F.IMP(f1,f2) -> (RSEQ([],[]),UINF(SEQ((lf@[LF(label,f1)]),(rf1@[LF(label,f2)]))))
			  | _ -> failwith "impr(): pf is not IMP\n"
		end 
	    | _ -> failwith "impr(): Not a valid sequent\n"
	end 
    | _ -> failwith "impr(): Not a valid inference\n";;

(* Substitution [x/y] in a list of relations *)
let subsrlist l x y =
  let rec subsrl l x y acc =
    match l with
      | h::t ->
	  begin 
	    match h with 
	      | REQ(s1,s2) ->
		  if s1 = y then 
		    if s2 = y then subsrl t x y (acc@[REQ(x,x)])
		    else subsrl t x y (acc@[REQ(x,s2)])
		  else (if s2 = y then subsrl t x y (acc@[REQ(s1,x)])
			else subsrl t x y (acc@[REQ(s1,s2)]))
	      | RT(s3,s4,s5) ->
		  if s3 = y then 
		    if s4 = y then
		      if s5 = y then subsrl t x y (acc@[RT(x,x,x)])
		      else subsrl t x y (acc@[RT(x,x,s5)])
		    else (if s5 = y then subsrl t x y (acc@[RT(x,s4,x)])
			  else subsrl t x y (acc@[RT(x,s4,s5)]))
		  else (if s4 = y then 
			  if s5 = y then subsrl t x y (acc@[RT(s3,x,x)])
			  else subsrl t x y (acc@[RT(s3,x,s5)])
			else (if s5 = y then subsrl t x y (acc@[RT(s3,s4,x)])
			      else subsrl t x y (acc@[RT(s3,s4,s5)])))
	      | NULLR -> [NULLR]
	      | _ -> failwith "Not a valid relation!"
	  end 
      | _ -> acc 
  in
    subsrl l x y [];;

(* Substitution [x/y] in a list of labelled formulae *)
let subsflist l x y =
  let rec subsfl l x y acc =
    match l with
      | h::t -> 
	  if (lb h) = y then subsfl t x y (acc@[LF(x,(fm h))])
	  else subsfl t x y (acc@[h]) 
      | _ -> acc 
  in
    subsfl l x y [];;

(* The top* L rule *)
(* Note that relations are not substituted here *)
let topstarl inf =
  match inf with
    | UINF s ->
	begin 
	  match s with 
	    | SEQ(lf,rf) -> 
		begin 
		  let label = findatomf F.MTRUE lf 0 in
		    if ((label = "-1") or (label = "epsilon")) then (RSEQ([],[]),NULLI) 
		    else 
		      let lft = M.subtlist (LF(label,F.MTRUE)) lf in
		      let lf1 = subsflist lft "epsilon" label in
		      let rf1 = subsflist rf "epsilon" label in
 			(RSEQ([REQ("epsilon",label)],[]),UINF(SEQ(lf1,rf1)))
		end 
	    | _ -> failwith "topstarl(): Not a valid sequent\n"
	end 
    | _ -> failwith "topstarl(): Not a valid inference\n";;

(* Find the first identity relation of the form (x,epsilon |> y) from a list of relations *)
let rec findidr l =
  match l with
  | h::t -> 
    begin
      match h with
      | RT(s1,s2,s3) -> if ((s1 = "epsilon") && (s2 != "epsilon") && (s2 != s3)) || ((s2 = "epsilon") && (s1 != "epsilon") && (s1 != s3)) || ((s1 = "epsilon") && (s2 = "epsilon") && (s3 != "epsilon")) then h else findidr t 
      | _ -> findidr t
    end 
  | _ -> NULLR;;

(* Get a list of identity relations from a list of relations *)
let findidrs l =
  let rec idrs l acc =
    let idr = findidr l in
    if idr = NULLR then acc 
    else 
      let lt = M.subtlist idr l in
      idrs lt (acc@[idr])
  in 
  idrs l [];;

(* Deal with identity relations of the form (x,epsilon |> y) or (epsilon,epsilon |> x), substitute formulae as well  *)
let idtrsolver_f rseq seq =
  let rec trysubs rseq seq =
    match rseq with 
    | RSEQ(lr,rr) -> 
      begin
	let lidl = findidrs lr in
	let ridl = findidrs rr in
	if (List.length lidl = 0) && (List.length ridl = 0) then (rseq,seq)
	else 
	  begin 
	    let rec subs idl l =
	      match idl with
	      | h::t -> 
		begin 
		  match h with
		  | RT(s1,s2,s3) -> 
		    begin
		      let lt = if List.mem h l then M.subtlist h l else l in
		      if s1 = "epsilon" then 
			(if s2 = "epsilon" then subs t (subsrlist lt "epsilon" s3)
			 else subs t (subsrlist lt s3 s2))
		      else 
			(if s2 = "epsilon" then subs t (subsrlist lt s1 s3)
			 else failwith "subs(): Not a identity relation\n") 
		    end 
		  | _ -> failwith "subs(): Not a ternary relation\n"
		end 
	      | _ -> l
	    in 
	    let rec subs_f idl fl =
	      match idl with
	      | h::t ->
		begin
		  match h with
		  | RT(s1,s2,s3) ->
		    begin 
		      if s1 = "epsilon" then 
			(if s2 = "epsilon" then subs_f t (subsflist fl "epsilon" s3)
			 else subs_f t (subsflist fl s3 s2))
		      else 
			(if s2 = "epsilon" then subs_f t (subsflist fl s1 s3)
			 else failwith "subs_f(): Not a identity relation\n")
		    end 
		  | _ -> failwith "subs_f(): Not a ternary relation\n"
		end 
	      | _ -> fl
	    in 
	    let lr1 = subs lidl lr in
	    let rr0 = subs lidl rr in
	    let rr1 = subs ridl rr0 in
	    match seq with
	    | SEQ(lf,rf) -> 
	      let seq2 = SEQ((subs_f lidl lf),(subs_f lidl rf)) in
	      trysubs (RSEQ(lr1,rr1)) seq2
	  end 
      end 
    | _ -> failwith "idsolver(): Not a valid relational sequent\n"
  in 
  trysubs rseq seq;;

(* Deal with identity relations of the form (x,epsilon |> y) or (epsilon,epsilon |> x) *)
let idtrsolver rseq =
  let rec trysubs rseq =
    match rseq with 
    | RSEQ(lr,rr) -> 
      begin
	let lidl = findidrs lr in
	let ridl = findidrs rr in
	if (List.length lidl = 0) && (List.length ridl = 0) then rseq
	else 
	  begin 
	    let rec subs idl l =
	      match idl with
	      | h::t -> 
		begin 
		  match h with
		  | RT(s1,s2,s3) -> 
		    let lt = if List.mem h l then M.subtlist h l else l in
		    begin
		      if s1 = "epsilon" then 
			(if s2 = "epsilon" then subs t (subsrlist lt "epsilon" s3)
			 else subs t (subsrlist lt s3 s2))
		      else 
			(if s2 = "epsilon" then subs t (subsrlist lt s1 s3)
			 else failwith "subs(): Not a identity relation\n") 
		    end 
		  | _ -> failwith "subs(): Not a ternary relation\n"
		end 
	      | _ -> l
	    in 
	    let lr1 = subs lidl lr in
	    let rr0 = subs lidl rr in
	    let rr1 = subs ridl rr0 in
	    trysubs (RSEQ(lr1,rr1))
	  end 
      end 
    | _ -> failwith "idsolver(): Not a valid relational sequent\n"
  in 
  trysubs rseq;;

(* Deal with the above relations in a list of relational sequents *)
let idtrsolvers rseqs =
  let rec recsubs rseqs acc =
    match rseqs with
    | h::t -> recsubs t (acc@[idtrsolver h])
    | _ -> acc 
  in 
  recsubs rseqs [];;

(* Find the atmoic formula f in the list of labelled formulae l. Return the list of labels if found, otherwise return []. *)
let rec findatomfl f l free =
  let rec find f l free acc =
    match l with 
    | h::t -> 
      begin
	if free = 0 then  (* do not require free variable *)
	  begin if (fm h) = f then find f t 0 (acc@[(lb h)]) else find f t 0 acc end 
	else (* require free variable *) 
	  begin if ((fm h) = f) && (isfree (lb h)) then find f t 1 (acc@[(lb h)]) else find f t 1 acc end 
      end 
    | _ -> acc
  in 
  find f l free [];;

(* The top* R rule *)
let topstarr inf = 
  match inf with 
    | UINF s ->
	begin
	  match s with
	    | SEQ(lf,rf) ->
		begin
		  let labels = findatomfl F.MTRUE rf 0 in
		    if (List.length labels) = 0 then (RSEQ([],[]),NULLI) (* can't find topstar on the RHS *)
		    else if (List.mem "epsilon" labels) then (RSEQ([],[]),inf)
		    else 
		      begin
			let pairstmp = mkpairs "epsilon" labels [] in
			let pairs = simpairs pairstmp in
			let eqs = mkeqrs pairs in
			(RSEQ([],eqs),inf)
		      end 
		end 
	    | _ -> failwith "topstarr(): Not a valid sequent\n"
	end 
    | _ -> failwith "topstarr(): Not a valid inference\n";;

(* Test if a list of labelled formulae contains star *)
let rec hasstar l =
  match l with
    | h::t -> 
	begin
	  match (fm h) with 
	  | F.MAND(f1,f2) -> h
	  | _ -> hasstar t
	end 
    | _ -> NULLLF;;

(* The star L rule *)
let mandl inf =
  match inf with
    | UINF s ->
	begin 
	  match s with 
	    | SEQ(lf,rf) ->
		begin 
		  let pf = hasstar lf in
		    if pf = NULLLF then (RSEQ([],[]),NULLI)
		    else 
		      let lf1 = M.subtlist pf lf in 
		      let label = lb pf in
			match (fm pf) with
			  | F.MAND(f1,f2) ->
			      let _ = labelnum := !labelnum+2 in
			      let t = !labelnum in
				(RSEQ([RT(("a"^(string_of_int (t-1))),("a"^(string_of_int t)),label)],[]),UINF(SEQ((lf1@[LF(("a"^(string_of_int (t-1))),f1);LF(("a"^(string_of_int t)),f2)]),rf)))
			  | _ -> failwith "mandl(): pf is not MAND\n"
		end 
	    | _ -> failwith "mandl(): Not a valid sequent\n"
	end 
    | _ -> failwith "mandl(): Not a valid inference\n";;

(* The star R rule *)
(* I do not keep a copy of principal formula, hopefully it's complete *)
let mandr inf = 
  match inf with
    | UINF s ->
	begin 
	  match s with
	    | SEQ(lf,rf) ->
		begin 
		  let pf = hasstar rf in
		    if pf = NULLLF then (RSEQ([],[]),NULLI)
		    else 
		      let rf1 = M.subtlist pf rf in
		      let label = lb pf in
			match (fm pf) with
			  | F.MAND(f1,f2) ->
			      let _ = labelnum := !labelnum+2 in
			      let t = !labelnum in
				(RSEQ([],[RT(("x"^(string_of_int (t-1))),("x"^(string_of_int (t))),label)]),BINF(SEQ(lf,(rf1@[LF(("x"^(string_of_int (t-1))),f1)])),SEQ(lf,(rf1@[LF(("x"^(string_of_int (t))),f2)]))))
			  | _ -> failwith "mandr(): pf is not MAND\n"
		end 
	    | _ -> failwith "mandr(): Not a valid sequent\n"
	end 
    | _ -> failwith "mandr(): Not a valid inference\n";;

(* Test if a list of labelled formulae contains magic wand *)
let rec hasmagic l =
  match l with
    | h::t -> 
	begin 
	  match (fm h) with 
	  | F.MIMP(f1,f2) -> h
	  | _ -> hasmagic t
	end 
    | _ -> NULLLF;;

(* The magic wand L rule *)
(* I do not keep a copy of principal formula, hopefully it's complete *)
let mimpl inf = 
  match inf with
    | UINF s ->
	begin 
	  match s with
	    | SEQ(lf,rf) ->
		begin 
		  let pf = hasmagic lf in
		    if pf = NULLLF then (RSEQ([],[]),NULLI)
		    else 
		      let lf1 = M.subtlist pf lf in
		      let label = lb pf in
			match (fm pf) with
			  | F.MIMP(f1,f2) ->
			      let _ = labelnum := !labelnum+2 in
			      let t = !labelnum in
				(RSEQ([],[RT(("x"^(string_of_int (t-1))),label,("x"^(string_of_int t)))]),BINF(SEQ(lf1,(rf@[LF(("x"^(string_of_int (t-1))),f1)])),SEQ((lf1@[LF(("x"^(string_of_int (t))),f2)]),rf)))
			  | _ -> failwith "mimpl(): pf is not MIMP\n"
		end 
	    | _ -> failwith "mimpl(): Not a valid sequent\n"
	end 
    | _ -> failwith "mimpl(): Not a valid inference\n";;

(* The magic wand R rule *)
let mimpr inf =
  match inf with
    | UINF s ->
	begin 
	  match s with 
	    | SEQ(lf,rf) ->
		begin 
		  let pf = hasmagic rf in
		    if pf = NULLLF then (RSEQ([],[]),NULLI)
		    else 
		      let rf1 = M.subtlist pf rf in 
		      let label = lb pf in
			match (fm pf) with
			  | F.MIMP(f1,f2) ->
			      let _ = labelnum := !labelnum+2 in
			      let t = !labelnum in
				(RSEQ([RT(("a"^(string_of_int (t-1))),label,(("a"^(string_of_int t))))],[]),UINF(SEQ((lf@[LF(("a"^(string_of_int (t-1))),f1)]),(rf1@[LF(("a"^(string_of_int t)),f2)]))))
			  | _ -> failwith "mimpr(): pf is not MIMP\n"
		end 
	    | _ -> failwith "mimpr(): Not a valid sequent\n"
	end 
    | _ -> failwith "mimpr(): Not a valid inference\n";;

exception Norules;;

(* Another star R rule with a parameter of principal formula *)
let mandr1 inf pf = 
  match inf with
    | UINF s ->
	begin 
	  match s with
	    | SEQ(lf,rf) ->
		begin 
		  let rf1 = M.subtlist pf rf in
		  let label = lb pf in
		  match (fm pf) with
		  | F.MAND(f1,f2) ->
		    let _ = labelnum := !labelnum+2 in
		    let t = !labelnum in
		    (RSEQ([],[RT(("x"^(string_of_int (t-1))),("x"^(string_of_int (t))),label)]),BINF(SEQ(lf,(rf1@[LF(("x"^(string_of_int (t-1))),f1)])),SEQ(lf,(rf1@[LF(("x"^(string_of_int (t))),f2)]))))
		  | _ -> failwith "mandr1(): pf is not MAND\n"
		end 
	    | _ -> failwith "mandr1(): Not a valid sequent\n"
	end 
    | _ -> failwith "mandr1(): Not a valid inference\n";;

(* Another magic L rule with a parameter of principal formula *)
let mimpl1 inf pf = 
  match inf with
  | UINF s ->
    begin 
      match s with
      | SEQ(lf,rf) ->
	begin 
	  let lf1 = M.subtlist pf lf in
	  let label = lb pf in
	  match (fm pf) with
	  | F.MIMP(f1,f2) ->
	    let _ = labelnum := !labelnum+2 in
	    let t = !labelnum in
	    (RSEQ([],[RT(("x"^(string_of_int (t-1))),label,("x"^(string_of_int t)))]),BINF(SEQ(lf1,(rf@[LF(("x"^(string_of_int (t-1))),f1)])),SEQ((lf1@[LF(("x"^(string_of_int (t))),f2)]),rf)))
	  | _ -> failwith "mimpl1(): pf is not MIMP\n"
	end 
      | _ -> failwith "mimpl1(): Not a valid sequent\n"
    end 
  | _ -> failwith "mimpl1(): Not a valid inference\n";;

(* Collect the list of star formulae from a list *)
let rec collectstar l acc =
  match l with
  | h::t -> 
    begin
      match (fm h) with
      | F.MAND(f1,f2) -> collectstar t (acc@[h])
      | _ -> collectstar t acc
    end 
  | _ -> acc;;

(* Collect the list of magicwand formulae from a list *)
let rec collectmagic l acc =
  match l with
  | h::t -> 
    begin
      match (fm h) with
      | F.MIMP(f1,f2) -> collectmagic t (acc@[h])
      | _ -> collectmagic t acc
    end 
  | _ -> acc;;

(* Return the list of formulae of * on the right and -* on the left from a sequent *)
let starRmagicL seq =
  match seq with
  | SEQ(lf,rf) -> 
    let starr = collectstar rf [] in
    let magicl = collectmagic lf [] in
    (starr@magicl);;

(* test if two relational lists rl1 = rl2 *)
let rec reqlist rl1 rl2 = 
    match rl1 with
    | h::t -> if List.mem h rl2 then reqlist t (M.subtlist h rl2) else false
    | _ -> if List.length rl2 = 0 then true else false;;

(* test if two relational lists rl1 is contained in rl2 *)
let rec rsublist rl1 rl2 = 
    match rl1 with
    | h::t -> if List.mem h rl2 then rsublist t rl2 else false
    | _ -> true;;

(* check if a relational sequent rseq1 contains another relational sequent rseq2 *)
let rinclude rseq1 rseq2 =
  let RSEQ(lr1,rr1) = rseq1 in
  let RSEQ(lr2,rr2) = rseq2 in
  if (reqlist lr1 lr2) && (rsublist rr2 rr1) then true else false;; 
  

(* check if a relational sequent rseq is already included in a set of relational sequents rseqs *)
let rec rincludel rseqs rseq =
  match rseqs with
  | h::t -> if rinclude h rseq then true else rincludel t rseq
  | _ -> false;;

(* Proof Search for a formula f *)
let proofsearch f dis =
  let _ = if dis then print_endline "starting proof search" else () in
  let rf = [LF("a0",f)] in
  let seq = SEQ([],rf) in
  let rseq = ref (RSEQ([],[])) in
  let rseqs = ref [] in
  let rec buildptree seq =
    let _ = if dis then print_endline "trying to build a proof tree for the sequent:" else () in
    let _ = if dis then (print_seq seq;print_endline "") else () in
    match seq with
    | SEQ(lsf,rsf) ->
      if ((lsf = []) & (rsf = [])) then NULLD (* end of a branch *)
      else
	begin 
	  (* apply Eq_1 and Eq_2 whenever possible *)
	  let (rseq1,seq1) = idtrsolver_f !rseq seq in
	  let _ = rseq := rseq1 in
	  let _ = rseqs := idtrsolvers !rseqs in
	  let inf = UINF seq1 in
	  let app = topr inf in
	  if (snd app) = NULLI then (* can't apply topR *)
	    begin
	      let app = botl inf in
	      if (snd app) = NULLI then (* can't apply botl *)
		begin
		  let app = simpid_f inf in
		  if (snd app) = NULLI then (* can't apply simpid *)
		    begin
		      let app = simptopstarr inf in
		      if (snd app) = NULLI then (* can't apply simptopstarr *)
			begin 
			  let app = topstarl inf in
			  if (snd app) = NULLI then (* can't apply toptarl *)
		    	    begin
			      let app = andl inf in
			      if (snd app) = NULLI then (* can't apply andl *)
				begin
				  let app = impr inf in
				  if (snd app) = NULLI then (* can't apply impR *)
				    begin
				      let app = mandl inf in
				      if (snd app) = NULLI then (* can't apply mandL*)
					begin
					  let app = mimpr inf in
					  if (snd app) = NULLI then (* can't apply mimpR *)
					    begin
					      let app = andr inf in
					      if (snd app) = NULLI then (* can't apply andr *)
						begin
						  let app = impl inf in
						  if (snd app) = NULLI then (* can't apply impL *)
						    begin (* synchronous rules can't be applied, have to consider mandR or mimpL now *)
						      let appfl = starRmagicL seq1 in 
						      if appfl = [] then 
							begin							   
							  let app = id inf in
							  if (snd app) = NULLI then (* can't apply id *)
							    begin
				      			      let app = topstarr inf in
							      if (snd app) = NULLI then (* can't apply topstarr *)
								UD("NORULE",seq1,(buildptree empseq)) (* No more applicable ruels!!!!!!!! *) 
							      else (* topstarR applied*)
								begin
								  let tr = !rseq in
								  let trs = !rseqs in
								  match tr with
								  | RSEQ(lr,rr) ->
								    match (fst app) with
								    | RSEQ(applr,apprr) ->
								      let _ = rseq := RSEQ((lr@applr),(rr@apprr)) in
								      let newconstr = RSEQ(lr,apprr) in
								      let _ = rseqs := if rincludel trs newconstr then trs else trs@[newconstr] in
								      (*let _ = rseqs := trs@[newconstr] in*)
								      UD("mtrueR",seq1,(buildptree empseq)) (* end of a branch *)
								end
							    end 
							  else (* id applied, need to substitute relations here*) 
							    begin 
							      let tr = !rseq in 
							      let trs = !rseqs in
							      match tr with
							      | RSEQ(lr,rr) ->
								match (fst app) with 
								| RSEQ(applr,apprr) ->
								  let app2 = topstarr (UINF seq1) in (*!!!!!!!!!!! apply topstarr inside id rule!!!!!!!!*)
								  if (snd app2) = NULLI then (*can't apply id and topstarr at the same time*)
								    let _ = if dis then print_endline "Conclude id with the constraint(s):" else () in
								    let _ = if dis then (print_rell apprr;print_endline "") else () in
								    let _ = rseq := RSEQ((lr@applr),(rr@apprr)) in
								    let newconstr = RSEQ(lr,apprr) in
								    let _ = rseqs := if rincludel trs newconstr then trs else trs@[newconstr] in
								    (*let _ = rseqs := trs@[newconstr] in*)
								    UD("id",seq1,(buildptree empseq)) (* end of a branch *)
								  else (* can apply id and topstarr at the same time, collect both constraints *)
								    begin
								      match (fst app2) with
								      | RSEQ(app2lr,app2rr) ->
									let _ = if dis then print_endline "Conclude id or topstarR with constrains:" else () in
									let _ = if dis then (print_rell (apprr@app2rr);print_endline "") else () in
									let _ = rseq := RSEQ((lr@applr@app2lr),(rr@apprr@app2rr)) in
									let newconstr = RSEQ(lr,(apprr@app2rr)) in
									let _ = rseqs := if rincludel trs newconstr then trs else trs@[newconstr] in
								     	UD("idmtrueR",seq1,(buildptree empseq)) (* end of a branch *)
								    end
							    end	
							end 
						      else 
							begin 
							  let rec leadstodev ptr =
							    match ptr with
							    | UD(r,s,pt) -> if r = "NORULE" then false else leadstodev pt
							    | BD(r,s,pt1,pt2) -> (leadstodev pt1) & (leadstodev pt2) 
							    | NULLD -> true
							  in 
							  let rec tryrules inf fl =
							    match fl with
							    | h::t -> 
							      begin
								let lt = !labelnum in
								match (fm h) with
								| F.MAND(f1,f2) -> 
								  let app = mandr1 inf h in
								  begin
								    match (snd app) with
								    | BINF(s1,s2) -> 
								      begin 
									let rt = !rseq in
									let rts = !rseqs in
									match rt with
									| RSEQ(lr,rr) ->
									  match (fst app) with
									  | RSEQ(applr,apprr) ->
									    let _ = rseq := RSEQ(lr,(rr@apprr)) in
									    let newconstr = RSEQ(lr,apprr) in
									    let _ = rseqs := if rincludel rts newconstr then rts else rts@[newconstr] in
									    let pt1 = buildptree s1 in
									    if leadstodev pt1 then 
									      let pt2 = buildptree s2 in
									      if leadstodev pt2 then  
										begin
								      		  BD("*R",seq1,pt1,pt2)
										end
									      else (let _ = rseq := rt;labelnum := lt;rseqs := rts in tryrules inf t)
									    else (let _ = rseq := rt;labelnum := lt;rseqs := rts in tryrules inf t) 
								      end 
								    | _ -> failwith "Wrong parameter from mandR!\n"
								  end 
								| F.MIMP(f1,f2) ->
								  let app = mimpl1 inf h in
								  begin
								    match (snd app) with
								    | BINF(s1,s2) -> 
								      begin
									let rt = !rseq in
									let rts = !rseqs in
									match rt with
									| RSEQ(lr,rr) ->
									  match (fst app) with
									  | RSEQ(applr,apprr) ->
									    let _ = rseq := RSEQ(lr,(rr@apprr)) in
									    let newconstr = RSEQ(lr,apprr) in
									    let _ = rseqs := if rincludel rts newconstr then rts else rts@[newconstr] in
									    let pt1 = buildptree s1 in
									    if leadstodev pt1 then 
									      let pt2 = buildptree s2 in
									      if leadstodev pt2 then
										begin
										  BD("-*L",seq1,pt1,pt2)
										end
									      else (let _ = rseq := rt;labelnum := lt;rseqs := rts in tryrules inf t)
									    else (let _ = rseq := rt;labelnum := lt;rseqs := rts in tryrules inf t)
								      end 
								    | _ -> failwith "Wrong parameter from mimpL!\n"
								  end 
								| _ -> failwith "tryrules(): Principal connective is not * nor -*\n"
							      end 
							    | _ -> UD("NORULE",seq1,(buildptree empseq)) (* No more applicable rules!!!!!!!! *)
							  in
							  tryrules inf appfl
							end
						    end
						  else (* impL applied *) 
						    begin
						      match (snd app) with
						      | BINF (s1,s2) -> BD("->L",seq1,(buildptree s1),(buildptree s2))
						      | _ -> failwith "Wrong parameter from impL!\n"
						    end
						end
					      else (* andr applied *)
						begin
						  match (snd app) with 
						  | BINF (s1,s2) -> BD("&R",seq1,(buildptree s1),(buildptree s2))
						  | _ -> failwith "Wrong parameter from andr !\n" 
						end 
					    end
					  else (* mimpR applied *)
					    begin
					      let rt = !rseq in
					      match rt with
					      | RSEQ(lr,rr) ->
						match (fst app) with
						| RSEQ(applr,apprr) -> 
						  let _ = rseq := RSEQ((lr@applr),rr) in
						  match (snd app) with
						  | UINF ns -> UD("-*R",seq1,(buildptree ns))
						  | _ -> failwith "Wrong parameter from mimpR!\n"
					    end
					end 
				      else (* mandL applied *)
					begin
					  let rt = !rseq in
					  match rt with
					  | RSEQ(lr,rr) ->
					    match (fst app) with
					    | RSEQ(applr,apprr) -> 
					      let _ = rseq := RSEQ((lr@applr),rr) in
					      match (snd app) with
					      | UINF ns -> UD("*L",seq1,(buildptree ns))
					      | _ -> failwith "Wrong parameter from mandL!\n"
					end
				    end 
				  else (* impR applied *)
				    begin
				      match (snd app) with 
				      | UINF ns -> UD("->R",seq1,(buildptree ns))
				      | _ -> failwith "Wrong parameter from impR!\n"									  
				    end
				end
			      else (* andl applied *)
				begin
				  match (snd app) with
				  | UINF ns -> UD("&L", seq1, (buildptree ns))
				  | _ -> failwith "Wrong parameter from andl !\n"
				end
			    end   
			  else (* topstarl applied *)
			    begin
			      let tr = !rseq in
			      match tr with
			      | RSEQ(lr,rr) ->
				begin 
				  match (fst app) with
				  | RSEQ(applr,apprr) ->
				    begin 
				      match (List.hd applr) with
				      | REQ(x,y) ->
					begin 
					  let lrt = subsrlist lr x y in
					  let rrt = subsrlist rr x y in
					  let _ = rseq := RSEQ(lrt,rrt) in
					  match (snd app) with (* apply Eq1 and Eq2 *)
					  | UINF ns -> 
					    begin 
					      let (rseq1,ns1) = idtrsolver_f !rseq ns in
					      let _ = rseq := rseq1 in
					      let _ = rseqs := idtrsolvers !rseqs in
					      UD("mtrueL", seq1, (buildptree ns1))
					    end 
					  | _ -> failwith "Wrong parameter from topstarl !\n"
					end 
				      | _ -> failwith "topstarl didn't return a valid relational atom\n"
				    end 
				  | _ -> failwith "topstarl didn't return a valid relation sequent\n"
				end 
			      | _ -> failwith "rseq is not a valid sequent after topstarl was applied\n"
			    end
			end
		      else (* simptopstarr applied *)
			UD("mtrueR",seq1,(buildptree empseq)) (* end of a branch *)
		    end 
		  else (* simpid_f applied *)
		    UD("id",seq1,(buildptree empseq)) (* end of a branch *)
		end 
	      else (* botl applied *)
		UD("falseL",seq1,(buildptree empseq)) (* end of a branch *)
	    end  
	  else (* topr applied *)
	    UD("trueR",seq1,(buildptree empseq)) (* end of a branch *)
	end
  in
  let ptree = (try buildptree seq with Norules -> failwith "Can't find a derivation\n") in
  let rseqfinal = !rseq in
  let rseqsfinal = !rseqs in
    (rseqsfinal,ptree);;

(* an eager proof search that applies zero-premise rules whenever possible *)
(* Proof Search for a formula f *)
let proofsearch_eager f dis =
  let _ = if dis then print_endline "starting proof search" else () in
  let rf = [LF("a0",f)] in
  let seq = SEQ([],rf) in
  let rseq = ref (RSEQ([],[])) in
  let rseqs = ref [] in
  let rec buildptree seq =
    let _ = if dis then print_endline "trying to build a proof tree for the sequent:" else () in
    let _ = if dis then (print_seq seq;print_endline "") else () in
    match seq with
    | SEQ(lsf,rsf) ->
      if ((lsf = []) & (rsf = [])) then NULLD (* end of a branch *)
      else
	begin 
	  (* apply Eq_1 and Eq_2 whenever possible *)
	  let (rseq1,seq1) = idtrsolver_f !rseq seq in
	  let _ = rseq := rseq1 in
	  let _ = rseqs := idtrsolvers !rseqs in
	  let inf = UINF seq1 in
	  let app = topr inf in
	  if (snd app) = NULLI then (* can't apply topR *)
	    begin
	      let app = botl inf in
	      if (snd app) = NULLI then (* can't apply botl *)
		begin
		  let app = id inf in
		  if (snd app) = NULLI then (* can't apply id *)
		    begin
		      let app = topstarr inf in
		      if (snd app) = NULLI then (* can't apply topstarr *)
			begin 
			  let app = topstarl inf in
			  if (snd app) = NULLI then (* can't apply toptarl *)
		    	    begin
			      let app = andl inf in
			      if (snd app) = NULLI then (* can't apply andl *)
				begin
				  let app = impr inf in
				  if (snd app) = NULLI then (* can't apply impR *)
				    begin
				      let app = mandl inf in
				      if (snd app) = NULLI then (* can't apply mandL*)
					begin
					  let app = mimpr inf in
					  if (snd app) = NULLI then (* can't apply mimpR *)
					    begin
					      let app = andr inf in
					      if (snd app) = NULLI then (* can't apply andr *)
						begin
						  let app = impl inf in
						  if (snd app) = NULLI then (* can't apply impL *)
						    begin (* synchronous rules can't be applied, have to consider mandR or mimpL now *)
						      let appfl = starRmagicL seq1 in 
						      if appfl = [] then (*can't apply *R or -*L *)
							begin							   
							  UD("NORULE",seq1,(buildptree empseq)) (* No more applicable ruels!!!!!!!! *) 
							end 
						      else 
							begin 
							  let rec leadstodev ptr =
							    match ptr with
							    | UD(r,s,pt) -> if r = "NORULE" then false else leadstodev pt
							    | BD(r,s,pt1,pt2) -> (leadstodev pt1) & (leadstodev pt2) 
							    | NULLD -> true
							  in 
							  let rec tryrules inf fl =
							    match fl with
							    | h::t -> 
							      begin
								let lt = !labelnum in
								match (fm h) with
								| F.MAND(f1,f2) -> 
								  let app = mandr1 inf h in
								  begin
								    match (snd app) with
								    | BINF(s1,s2) -> 
								      begin 
									let rt = !rseq in
									let rts = !rseqs in
									match rt with
									| RSEQ(lr,rr) ->
									  match (fst app) with
									  | RSEQ(applr,apprr) ->
									    let _ = rseq := RSEQ(lr,(rr@apprr)) in
									    let newconstr = RSEQ(lr,apprr) in
									    let _ = rseqs := if rincludel rts newconstr then rts else rts@[newconstr] in
									    let pt1 = buildptree s1 in
									    if leadstodev pt1 then 
									      let pt2 = buildptree s2 in
									      if leadstodev pt2 then  
										begin
								      		  BD("*R",seq1,pt1,pt2)
										end
									      else (let _ = rseq := rt;labelnum := lt;rseqs := rts in tryrules inf t)
									    else (let _ = rseq := rt;labelnum := lt;rseqs := rts in tryrules inf t) 
								      end 
								    | _ -> failwith "Wrong parameter from mandR!\n"
								  end 
								| F.MIMP(f1,f2) ->
								  let app = mimpl1 inf h in
								  begin
								    match (snd app) with
								    | BINF(s1,s2) -> 
								      begin
									let rt = !rseq in
									let rts = !rseqs in
									match rt with
									| RSEQ(lr,rr) ->
									  match (fst app) with
									  | RSEQ(applr,apprr) ->
									    let _ = rseq := RSEQ(lr,(rr@apprr)) in
									    let newconstr = RSEQ(lr,apprr) in
									    let _ = rseqs := if rincludel rts newconstr then rts else rts@[newconstr] in
									    let pt1 = buildptree s1 in
									    if leadstodev pt1 then 
									      let pt2 = buildptree s2 in
									      if leadstodev pt2 then
										begin
										  BD("-*L",seq1,pt1,pt2)
										end
									      else (let _ = rseq := rt;labelnum := lt;rseqs := rts in tryrules inf t)
									    else (let _ = rseq := rt;labelnum := lt;rseqs := rts in tryrules inf t)
								      end 
								    | _ -> failwith "Wrong parameter from mimpL!\n"
								  end 
								| _ -> failwith "tryrules(): Principal connective is not * nor -*\n"
							      end 
							    | _ -> UD("NORULE",seq1,(buildptree empseq)) (* No more applicable rules!!!!!!!! *)
							  in
							  tryrules inf appfl
							end
						    end
						  else (* impL applied *) 
						    begin
						      match (snd app) with
						      | BINF (s1,s2) -> BD("->L",seq1,(buildptree s1),(buildptree s2))
						      | _ -> failwith "Wrong parameter from impL!\n"
						    end
						end
					      else (* andr applied *)
						begin
						  match (snd app) with 
						  | BINF (s1,s2) -> BD("&R",seq1,(buildptree s1),(buildptree s2))
						  | _ -> failwith "Wrong parameter from andr !\n" 
						end 
					    end
					  else (* mimpR applied *)
					    begin
					      let rt = !rseq in
					      match rt with
					      | RSEQ(lr,rr) ->
						match (fst app) with
						| RSEQ(applr,apprr) -> 
						  let _ = rseq := RSEQ((lr@applr),rr) in
						  match (snd app) with
						  | UINF ns -> UD("-*R",seq1,(buildptree ns))
						  | _ -> failwith "Wrong parameter from mimpR!\n"
					    end
					end 
				      else (* mandL applied *)
					begin
					  let rt = !rseq in
					  match rt with
					  | RSEQ(lr,rr) ->
					    match (fst app) with
					    | RSEQ(applr,apprr) -> 
					      let _ = rseq := RSEQ((lr@applr),rr) in
					      match (snd app) with
					      | UINF ns -> UD("*L",seq1,(buildptree ns))
					      | _ -> failwith "Wrong parameter from mandL!\n"
					end
				    end 
				  else (* impR applied *)
				    begin
				      match (snd app) with 
				      | UINF ns -> UD("->R",seq1,(buildptree ns))
				      | _ -> failwith "Wrong parameter from impR!\n"									  
				    end
				end
			      else (* andl applied *)
				begin
				  match (snd app) with
				  | UINF ns -> UD("&L", seq1, (buildptree ns))
				  | _ -> failwith "Wrong parameter from andl !\n"
				end
			    end   
			  else (* topstarl applied *)
			    begin
			      let tr = !rseq in
			      match tr with
			      | RSEQ(lr,rr) ->
				begin 
				  match (fst app) with
				  | RSEQ(applr,apprr) ->
				    begin 
				      match (List.hd applr) with
				      | REQ(x,y) ->
					begin 
					  let lrt = subsrlist lr x y in
					  let rrt = subsrlist rr x y in
					  let _ = rseq := RSEQ(lrt,rrt) in
					  match (snd app) with (* apply Eq1 and Eq2 *)
					  | UINF ns -> 
					    begin 
					      let (rseq1,ns1) = idtrsolver_f !rseq ns in
					      let _ = rseq := rseq1 in
					      let _ = rseqs := idtrsolvers !rseqs in
					      UD("mtrueL", seq1, (buildptree ns1))
					    end 
					  | _ -> failwith "Wrong parameter from topstarl !\n"
					end 
				      | _ -> failwith "topstarl didn't return a valid relational atom\n"
				    end 
				  | _ -> failwith "topstarl didn't return a valid relation sequent\n"
				end 
			      | _ -> failwith "rseq is not a valid sequent after topstarl was applied\n"
			    end
			end
		      else (* topstarr applied *)
			begin
			  let tr = !rseq in
			  let trs = !rseqs in
			  match tr with
			  | RSEQ(lr,rr) ->
			    match (fst app) with
			    | RSEQ(applr,apprr) ->
			      let _ = rseq := RSEQ((lr@applr),(rr@apprr)) in
			      let newconstr = RSEQ(lr,apprr) in
			      let _ = rseqs := if rincludel trs newconstr then trs else trs@[newconstr] in
			      UD("mtrueR",seq1,(buildptree empseq)) (* end of a branch *)
			end 
		    end 
		  else (* id applied *)
		    begin
		      let tr = !rseq in 
		      let trs = !rseqs in
		      match tr with
		      | RSEQ(lr,rr) ->
			match (fst app) with 
			| RSEQ(applr,apprr) ->
			  let _ = if dis then print_endline "Conclude id with the constraint(s):" else () in
			  let _ = if dis then (print_rell apprr;print_endline "") else () in
			  let _ = rseq := RSEQ((lr@applr),(rr@apprr)) in
			  let newconstr = RSEQ(lr,apprr) in
			  let _ = rseqs := if rincludel trs newconstr then trs else trs@[newconstr] in
			  UD("id",seq1,(buildptree empseq)) (* end of a branch *)
		    end 
		end 
	      else (* botl applied *)
		UD("falseL",seq1,(buildptree empseq)) (* end of a branch *)
	    end  
	  else (* topr applied *)
	    UD("trueR",seq1,(buildptree empseq)) (* end of a branch *)
	end
  in
  let ptree = (try buildptree seq with Norules -> failwith "Can't find a derivation\n") in
  let rseqfinal = !rseq in
  let rseqsfinal = !rseqs in
    (rseqsfinal,ptree);;

(* Test if a prooftree is all closed *)
let rec closedptree ptree =
  match ptree with
  | UD(rule,seq,dev) -> if rule = "NORULE" then false else closedptree dev
  | BD(rule,seq,dev1,dev2) -> if rule = "NORULE" then false else ((closedptree dev1) && (closedptree dev2))
  | _ -> true;;

(* Test if there is no constraints to satisfy *)
let rec noconstr rseqs =
  match rseqs with
  | h::t -> 
    begin
      match h with
      | RSEQ(lr,rr) -> if (List.length rr) = 0 then noconstr t else false
      | _ -> failwith "noconstr(): Not a valid relational sequent\n"
    end 
  | _ -> true;;

(* Return the first equality relation from a list of relations *)
let rec eqrel rl =
  match rl with
    | h::t -> 
	begin
	  match h with
	    | REQ(s1,s2) -> h
	    | _ -> eqrel t
	end 
    | _ -> NULLR;;
 
(* Substitute the equality relation on a list *)
let subsequality eq l =
  match eq with
  | REQ(x,y) ->
    begin
      if (isfree x) then subsrlist l y x
      else if (isfree y) then subsrlist l x y
      (*else (*subsrlist l x y*) l (* don't do anything is the constraint is (Ai = Aj)*)*)
      else [NULLR]
    end 
  | _ -> failwith "subsequality(): Not a valid equality relation\n";;

(* Substitute the equality relation on a relational sequent *)
let subseqrseq eq rseq =
  match rseq with
  | RSEQ(lr,rr) -> 
    let lrt = subsequality eq lr in
    let rrt = subsequality eq rr in
    if lrt = [NULLR] || rrt = [NULLR] then RSEQ([NULLR],[NULLR])
    else RSEQ(lrt,rrt)
  | RSEQ([NULLR],[NULLR]) -> RSEQ([NULLR],[NULLR])
  | _ -> failwith "subseqrseq(): Not a valid relational sequent\n";;

(*check if the set of relational sequents is changed *)
let changedrseqs rseqsold rseqsnew = if rseqsold = rseqsnew then false else true;;

(* substitute the equality relation (ai = xj) on a list of relational sequents *)
let rec subseqll eq ll acc =
    match ll with
    | h::t -> 
      let tmp = subseqrseq eq h in
      if tmp = RSEQ([NULLR],[NULLR]) then [RSEQ([NULLR],[NULLR])]
      else subseqll eq t (acc@[tmp])
    | _ -> acc;;

(*detect (Ai=Ai) and (epsilon,Ai |> Ai) in a relational list*)
let rec istrivial rl = 
    match rl with
    | h::t -> 
      begin
	match h with
	| REQ(s1,s2) -> if s1 = s2 then true else istrivial t 
	| RT(s1,s2,s3) -> 
	  begin
	    if s1 = "epsilon" && s2 = s3 then true 
	    else if s2 = "epsilon" && s1 = s3 then true
	    else istrivial t
	  end 
      end 
    | _ -> false;;

(* Deal with the equality relations in a set of relational sequents *)
let eqsolvers rseqs = 
  let rec simpseqs rseqs acc = (*delete rseqs with (Ai =Ai) on the RHS *)
    match rseqs with 
    | h::t -> 
      begin
	match h with
	| RSEQ(lr,rr) -> if istrivial rr then simpseqs t acc else simpseqs t (acc@[h]) 
      end 
    | _ -> acc
  in 
  let deleunsolvable rseq =
    let rec dele rr acc =
      match rr with
      | h::t ->
	if List.length t > 0 || List.length acc > 0 then 
	  begin 
	    match h with
	    | REQ(s1,s2) -> if (iseigen s1) && (iseigen s2) && (s1 != s2) then dele t acc else dele t (acc@[h]) 
	    | _ -> failwith "dele(): Not a valid equality relation\n"
	  end 
	else [h]
      | _ -> acc
    in 
    let RSEQ(lr,rr) = rseq in
    if List.length rr > 0 then
      match List.hd rr with
      | REQ(s1,s2) -> if List.length rr > 1 then RSEQ(lr,(dele rr [])) else rseq
      | _ -> rseq
    else rseq
  in 
  let rec deleunsolvables rseqs acc =
    match rseqs with
    | h::t -> deleunsolvables t (acc@[deleunsolvable h])
    | _ -> acc
  in 
  let rec eqsolve rseqs result =
    match rseqs with
    | h::t -> 
      begin
	match h with
	| RSEQ(lr,rr) -> 
	  if (List.length rr = 0) || (List.length rr > 1) then eqsolve t result
	  else 
	    begin
	      let r = List.nth rr 0 in
	      match r with
	      | REQ(s1,s2) -> 
		begin 
		  let resulttmp = if (List.mem h result) && (isfree s1 || isfree s2) then M.subtlist h result else result in
		  let resulttmp2 = subseqll r resulttmp [] in
		  if resulttmp2 = [RSEQ([NULLR],[NULLR])] then [RSEQ([NULLR],[NULLR])]
		  else 
		    let resulttmp3 = simpseqs resulttmp2 [] in
		    eqsolve t resulttmp3
		end 
	      | RT(s1,s2,s3) -> 
		begin
		  if (s1 = "epsilon") && (s2 = "epsilon") && (s3 = "epsilon") then
		    let resulttmp = if List.mem h result then M.subtlist h result else result in
		    eqsolve t resulttmp
		  else if (s1 = "epsilon") && (s2 = "epsilon") && isfree s3 then 
		    let resulttmp = if List.mem h result then M.subtlist h result else result in
		    let resulttmp2 = subseqll (REQ("epsilon",s3)) resulttmp [] in
		    if resulttmp2 = [RSEQ([NULLR],[NULLR])] then [RSEQ([NULLR],[NULLR])]
		    else 
		      let resulttmp3 = simpseqs resulttmp2 [] in
		      eqsolve t resulttmp3
		  else if (s1 = "epsilon") && (isfree s2 || isfree s3) then 
		    let resulttmp = if List.mem h result then M.subtlist h result else result in
		    let resulttmp2 = subseqll (REQ(s2,s3)) resulttmp [] in
		    if resulttmp2 = [RSEQ([NULLR],[NULLR])] then [RSEQ([NULLR],[NULLR])]
		    else 
		      let resulttmp3 = simpseqs resulttmp2 [] in
		      eqsolve t resulttmp3 
		  else if (s2 = "epsilon") && (isfree s1 || isfree s3) then 
		    let resulttmp = if List.mem h result then M.subtlist h result else result in
		    let resulttmp2 = subseqll (REQ(s1,s3)) resulttmp [] in
		    if resulttmp2 = [RSEQ([NULLR],[NULLR])] then [RSEQ([NULLR],[NULLR])]
		    else 
		      let resulttmp3 = simpseqs resulttmp2 [] in
		      eqsolve t resulttmp3
		  else eqsolve t result 
		end 
	      | _ -> eqsolve t result
	    end 
	| _ -> failwith "eqsolve(): Not a valid relational sequent\n"
      end 
    | _ -> result
  in
  let rseqs0 = deleunsolvables rseqs [] in
  let rseqsi = eqsolve rseqs0 rseqs0 in
  if rseqsi = [RSEQ([NULLR],[NULLR])] then [RSEQ([NULLR],[NULLR])]
  else if rseqsi = rseqs then rseqsi else eqsolve rseqsi rseqsi;;

(* Test is the set of constraints is empty *)
let rec hasconstr rseqs =
  match rseqs with
  | h::t -> 
    begin
      match h with
      | RSEQ(lr,rr) -> if ((List.length lr) = 0) && ((List.length rr) = 0) then hasconstr t else true
    end 
  | _ -> false;;

(* Deal with the equality relations in the relational sequent *)
let eqsolver rseq =
  match rseq with
  | RSEQ(lr,rr) ->
    begin
      let rec lsubseq l r = 
	let eqr = eqrel l in
	if eqr = NULLR then (l,r)
	else 
	  begin 
	    let lt = if List.mem eqr l then M.subtlist eqr l else l in
	    if (List.mem eqr r) then 
	      let rt = M.subtlist eqr r in (* delete the same equal relation on the RHS *)
	      let l1 = subsequality eqr lt in
	      let r1 = subsequality eqr rt in
	      if l1 = [NULLR] or r1 = [NULLR] then ([NULLR],[NULLR])
	      else lsubseq l1 r1
	    else 
	      let l1 = subsequality eqr lt in
	      let r1 = subsequality eqr r in
	      if l1 = [NULLR] or r1 = [NULLR] then ([NULLR],[NULLR])
	      else lsubseq l1 r1
	  end 
      in
      let rec rsubseq l r = 
	let eqr = eqrel r in
	if eqr = NULLR then (l,r)
	else 
	  begin
	    match eqr with
	    | REQ(s1,s2) -> if (String.contains s1 'a') & (String.contains s2 'a') then (let rt = if List.mem eqr r then M.subtlist eqr r else r in rsubseq l (rt@[RT(s1,"epsilon",s2)])) else 
		let rt = if List.mem eqr r then M.subtlist eqr r else r in
		let l1 = subsequality eqr l in
		let r1 = subsequality eqr rt in
		if l1 = [NULLR] or r1 = [NULLR] then ([NULLR],[NULLR])
		else rsubseq l1 r1
	  end 
      in
      let (ltmp,rtmp) = lsubseq lr rr in
      if ltmp = [NULLR] && rtmp = [NULLR] then RSEQ([NULLR],[NULLR])
      else 
	let (lx,rx) = rsubseq ltmp rtmp in
	if lx = [NULLR] && rx = [NULLR] then RSEQ([NULLR],[NULLR])
	else RSEQ(lx,rx)
    end 
  | _ -> failwith "eqsolver(): Not a valid relational sequent\n";;

(* simplify the set of constraints by match ternary relations with two matchable eigenvariables *)
let matchtern rseqs =
  let prep tr = (* deal with (ai, xj |> ai), (ai,ai |> xj)*)
    (* these assignments are sound but not complete. the free variable may not be epsilon *)
    let RT(t1,t2,t3) = tr in
    if iseigen t1 && t1 = t3 && isfree t2 then REQ("epsilon",t2)
    else if iseigen t2 && t2 = t3 && isfree t1 then REQ(t1,"epsilon")
    else if iseigen t1 && t2 = "epsilon" && isfree t3 then REQ(t1,t3)
    else if iseigen t2 && t1 = "epsilon" && isfree t3 then REQ(t2,t3)
    else NULLR
  in 
  let simplematch rseqs =
    let rec simplify rseqs acc =
      match rseqs with
      | h::t -> 
	let RSEQ(lr,rr) = h in
	let fr = if List.length rr > 0 then List.nth rr 0 else REQ("-1","-1") in
	if istern fr then 
	  let RT(t1,t2,t3) = fr in
	  if List.mem (RT(t1,t2,t3)) lr || List.mem (RT(t2,t1,t3)) lr then 
	    simplify t acc
	  else simplify t (acc@[h])
	else simplify t (acc@[h])
      | _ -> acc
    in 
    simplify rseqs [] 
  in 
  let rec matchtr tr l =
    match l with 
    | h::t -> 
      begin
	match h with
	| RT(s1,s2,s3) ->
	  let RT(t1,t2,t3) = tr in 
	  if (s1 = t1) && (s2 = t2) && (isfree s3 || isfree t3 || s3 = t3) then REQ(s3,t3)
	  else if (s1 = t1) && (s3 = t3) && (isfree s2 || isfree t2 || s2 = t2) then REQ(s2,t2)
	  else if (s1 = t2) && (s2 = t1) && (isfree s3 || isfree t3 || s3 = t3) then REQ(s3,t3)
	  else if (s1 = t2) && (s3 = t3) && (isfree s2 || isfree t1 || s2 = t1) then REQ(s2,t1)
	  else if (s2 = t2) && (s3 = t3) && (isfree s1 || isfree t1 || s1 = t1) then REQ(s1,t1)
	  else if (s2 = t1) && (s3 = t3) && (isfree s1 || isfree t2 || s1 = t2) then REQ(s1,t2)
	  else matchtr tr t
	| _ -> matchtr tr t
      end 
    | _ -> NULLR
  in
  let rec simpas assts acc =
    match assts with
    | h::t -> let REQ(s1,s2) = h in if s1 = s2 then simpas t acc else simpas t (acc@[h])
    | _ -> acc
  in 
  let rec findmatch rseqs result assts =
    match rseqs with
    | h::t -> 
      let RSEQ(lr,rr) = h in 
      let fr = if List.length rr > 0 then List.nth rr 0 else REQ("-1","-1") in
      if istern fr then 
	let eq0 = prep fr in
	if eq0 = NULLR then 
	  let eq = matchtr fr lr in
	  if eq = NULLR then findmatch t result assts
	  else (* apply substitution eq on rseqs *)
	    begin
	      let tmpresult = if List.mem h result then M.subtlist h result else result in
	      let tmpresult2 = subseqll eq tmpresult [] in
	      findmatch t tmpresult2 (assts@[eq])
	    end 
	else 
	  begin
	    let tmpresult = if List.mem h result then M.subtlist h result else result in
	    let tmpresult2 = subseqll eq0 tmpresult [] in
	    findmatch t tmpresult2 (assts@[eq0])
	  end
      else findmatch t result assts
    | _ -> (result,assts)
  in 
  let rec matchall rseqs assts =
    let (rseqst,newassts) = findmatch rseqs rseqs [] in
    if changedrseqs rseqs rseqst then matchall rseqst (assts@newassts) else (rseqst,(simpas assts []))
  in 
  let rec validassts assts =
    match assts with
    | h::t -> let REQ(a1,a2) = h in if iseigen a1 && iseigen a2 then false else validassts t
    | _ -> true
  in 
  let (rseqs,assts) = matchall (simplematch rseqs) [] in
  if validassts assts then (rseqs,assts) else (rseqs,[REQ("-1","-1")]);;

(* Get the set of labels from a list of relations *)
let getlabels l =
  let rec labelsinl l acc =
    match l with
    | h::t -> 
      begin
	match h with
	| REQ(s1,s2) -> 
	  if (List.mem s1 acc) & (List.mem s2 acc) then labelsinl t acc
	  else if (List.mem s1 acc) then labelsinl t (acc@[s2])
	  else if (List.mem s2 acc) then labelsinl t (acc@[s1])
	  else labelsinl t (acc@[s1;s2])
	| RT(s1,s2,s3) ->
	  if (List.mem s1 acc) & (List.mem s2 acc) & (List.mem s3 acc) then labelsinl t acc
	  else if (List.mem s1 acc) & (List.mem s2 acc) then labelsinl t (acc@[s3])
	  else if (List.mem s1 acc) & (List.mem s3 acc) then labelsinl t (acc@[s2])
	  else if (List.mem s2 acc) & (List.mem s3 acc) then labelsinl t (acc@[s1])
	  else if (List.mem s1 acc) then labelsinl t (acc@[s2;s3])
	  else if (List.mem s2 acc) then labelsinl t (acc@[s1;s3])
	  else if (List.mem s3 acc) then labelsinl t (acc@[s1;s2])
	  else labelsinl t (acc@[s1;s2;s3])
      end 
    | _ -> acc
  in 
  labelsinl l [];;

(* Reads a list of ternary relations, return sets of leaves, no restriction on internal nodes *)
let leavesets l =
  let rec useful r l = (* test if r will be used in l *)
    let RT(t1,t2,t3) = r in
    match l with
    | h::t -> let RT(s1,s2,s3) = h in if s1 = t3 || s2 = t3 then true else useful r t
    | _ -> false 
  in 
  let rec setofleaves l acc =
    let rec getleaves l accl accr = (* accl stores unused relations, accr stores leaves *)
      match l with
      | h::t -> 
	begin
	  match h with
	  | RT(s1,s2,s3) -> 
	    begin
	      if s3 = (fst accr) then getleaves t (accl@[h]) accr
	      else if (List.mem s3 (snd accr)) then getleaves t accl ((fst accr),((M.subtlist s3 (snd accr))@[s1;s2]))
	      else if (snd accr) = [] then getleaves t accl (s3,[s1;s2])
	      else if (fst accr) = s1 then getleaves t accl (s3,((snd accr)@[s2]))
	      else if (fst accr) = s2 then getleaves t accl (s3,((snd accr)@[s1])) 
	      else getleaves t (accl@[h]) accr
	    end 
	  | _ -> failwith "getleaves(): Non-ternary relation\n"
	end 
      | _ -> (accl,accr)
    in 
    let rec getfinalleaves l last =
      let (lt,acct) = getleaves l [] last in
      if acct = last then (lt,acct) else getfinalleaves lt acct
    in 
    if l = [] then acc 
    else 
      let (lt,acct) = getfinalleaves l ("",[]) in
      (*let setl = M.SoL.S.elements (M.SoL.set_of_list (snd acct)) in*)
      setofleaves lt (acc@[(fst acct,snd acct)])
  in 
  setofleaves l [];;

(* extend a tree with a list of ternary relations *)
let rec exttree tree lt =
  match lt with
  | h::t -> 
    let RT(s1,s2,s3) = h in
    (* retrict internal nodes to be free *)
    if List.mem s3 (snd tree) && isfree s3 then exttree ((fst tree),((M.subtlist s3 (snd tree))@[s1;s2])) t
    else if (fst tree) = s1 && isfree s1 then exttree (s3,((snd tree)@[s2])) t
    else if (fst tree) = s2 && isfree s2 then exttree (s3,((snd tree)@[s1])) t
    else exttree tree t 
  | _ -> tree;;

(* extend a list of trees according to lt *)
let exttrees trees lt =
  let rec extend trees lt acc =
    match trees with
    | h::t -> extend t lt (acc@[exttree h lt])
    | _ -> acc
  in 
  extend trees lt [];;

(* Reads a list of ternary relations, return sets of leaves. Internal nodes in a tree is restricted to be free variables only *)
let leavesets_fi l =
  let rec useful r l = (* test if r will be used in l *)
    let RT(t1,t2,t3) = r in
    match l with
    | h::t -> let RT(s1,s2,s3) = h in if s1 = t3 || s2 = t3 then true else useful r t
    | _ -> false 
  in 
  let rec setofleaves l acc =
    let rec getleaves l accl accr = (* accl stores unused relations, accr stores a 2lvl tree *)
      match l with
      | h::t -> 
	begin
	  match h with
	  | RT(s1,s2,s3) -> 
	    begin
	      (* restricted the internal nodes to only be free variables *)
	      if s3 = (fst accr) then getleaves t (accl@[h]) accr
	      else if (List.mem s3 (snd accr)) && isfree s3 then getleaves t accl ((fst accr),((M.subtlist s3 (snd accr))@[s1;s2]))
	      else if (snd accr) = [] then getleaves t accl (s3,[s1;s2])
	      else if (fst accr) = s1 && isfree s1 then getleaves t accl (s3,((snd accr)@[s2]))
	      else if (fst accr) = s2 && isfree s2 then getleaves t accl (s3,((snd accr)@[s1])) 
	      else getleaves t (accl@[h]) accr
	    end 
	  | _ -> failwith "getleaves(): Non-ternary relation\n"
	end 
      | _ -> (accl,accr)
    in 
    let rec getfinalleaves l last =
      let (lt,acct) = getleaves l [] last in
      if acct = last then (lt,acct) else getfinalleaves lt acct
    in 
    if l = [] then acc 
    else 
      let (lt,acct) = getfinalleaves l ("",[]) in
      (*let setl = M.SoL.S.elements (M.SoL.set_of_list (snd acct)) in*)
      setofleaves lt (acc@[(fst acct,snd acct)])
  in 
  let trees = setofleaves l [] in
  exttrees trees l;;

(* extend a tree with a list of ternary relations,record the ternary relations used *)
let rec exttree_t tree terns lt =
  match lt with
  | h::t -> 
    let RT(s1,s2,s3) = h in
    (* retrict internal nodes to be free *)
    if List.mem s3 (snd tree) && isfree s3 then exttree_t ((fst tree),((M.subtlist s3 (snd tree))@[s1;s2])) (terns@[h]) t
    else if (fst tree) = s1 && isfree s1 then exttree_t (s3,((snd tree)@[s2])) (terns@[h]) t
    else if (fst tree) = s2 && isfree s2 then exttree_t (s3,((snd tree)@[s1])) (terns@[h]) t
    else exttree_t tree terns t 
  | _ -> ((fst tree),(snd tree),terns);;

(* extend a list of trees according to lt, record the ternary relations used  *)
let exttrees_t trees_t lt =
  let rec extend trees_t lt acc =
    match trees_t with
    | h::t -> 
      let (root,leaves,terns) = h in 
      extend t lt (acc@[exttree_t (root,leaves) terns lt])
    | _ -> acc
  in 
  extend trees_t lt [];;

(* Reads a list of ternary relations, return list of leaves, and corresponding ternary relations used to form the trees, in the form [(root,leaves,terns)]. Internal nodes in a tree is restricted to be free variables only *)
let leavesets_fi_t l =
  let rec useful r l = (* test if r will be used in l *)
    let RT(t1,t2,t3) = r in
    match l with
    | h::t -> let RT(s1,s2,s3) = h in if s1 = t3 || s2 = t3 then true else useful r t
    | _ -> false 
  in 
  let rec setofleaves l acc =
    let rec getleaves l accl accr acct= (* accl stores unused relations, accr stores leaves, acct stores used ternary relations *)
      match l with
      | h::t -> 
	begin
	  match h with
	  | RT(s1,s2,s3) -> 
	    begin
	      (* restrict the internal nodes to be free variables only *)
	      if s3 = (fst accr) then getleaves t (accl@[h]) accr acct
	      else if (List.mem s3 (snd accr)) && isfree s3 then getleaves t accl ((fst accr),((M.subtlist s3 (snd accr))@[s1;s2])) (acct@[h])
	      else if (snd accr) = [] then getleaves t accl (s3,[s1;s2]) (acct@[h])
	      else if (fst accr) = s1 && isfree s1 then getleaves t accl (s3,((snd accr)@[s2])) (acct@[h])
	      else if (fst accr) = s2 && isfree s2 then getleaves t accl (s3,((snd accr)@[s1])) (acct@[h])
	      else getleaves t (accl@[h]) accr acct
	    end 
	  | _ -> failwith "getleaves(): Non-ternary relation\n"
	end 
      | _ -> (accl,accr,acct)
    in 
    let rec getfinalleaves l last tlast =
      let (lt,acct,tt) = getleaves l [] last tlast in
      if acct = last then (lt,acct,tt) else getfinalleaves lt acct tt
    in 
    if l = [] then acc 
    else 
      let (lt,acct,tt) = getfinalleaves l ("",[]) [] in
      (*let setl = M.SoL.S.elements (M.SoL.set_of_list (snd acct)) in*)
      setofleaves lt (acc@[(fst acct,snd acct,tt)])
  in 
  let trees_t = setofleaves l [] in
  exttrees_t trees_t l;;

(* extend a tree with a list of ternary relations,record the ternary relations used *)
let rec exttree_e_t tree terns lt =
  match lt with
  | h::t -> 
    let RT(s1,s2,s3) = h in
    (* retrict internal nodes to be free *)
    if List.mem s3 (snd tree) then exttree_e_t ((fst tree),((M.subtlist s3 (snd tree))@[s1;s2])) (terns@[h]) t
    else if (fst tree) = s1 then exttree_e_t (s3,((snd tree)@[s2])) (terns@[h]) t
    else if (fst tree) = s2 then exttree_e_t (s3,((snd tree)@[s1])) (terns@[h]) t
    else exttree_e_t tree terns t 
  | _ -> ((fst tree),(snd tree),terns);;

(* extend a list of trees according to lt, record the ternary relations used  *)
let exttrees_e_t trees_t lt =
  let rec extend trees_t lt acc =
    match trees_t with
    | h::t -> 
      let (root,leaves,terns) = h in 
      extend t lt (acc@[exttree_e_t (root,leaves) terns lt])
    | _ -> acc
  in 
  extend trees_t lt [];;

(* Reads a list of ternary relations, return sets of leaves and corresponding ternary relations, no restriction on internal nodes *)
let leavesets_t l =
  let rec useful r l = (* test if r will be used in l *)
    let RT(t1,t2,t3) = r in
    match l with
    | h::t -> let RT(s1,s2,s3) = h in if s1 = t3 || s2 = t3 then true else useful r t
    | _ -> false 
  in 
  let rec setofleaves l acc =
    let rec getleaves l accl accr acct = (* accl stores unused relations, accr stores leaves *)
      match l with
      | h::t -> 
	begin
	  match h with
	  | RT(s1,s2,s3) -> 
	    begin
	      if s3 = (fst accr) then getleaves t (accl@[h]) accr acct
	      else if (List.mem s3 (snd accr)) then getleaves t accl ((fst accr),((M.subtlist s3 (snd accr))@[s1;s2])) (acct@[h])
	      else if (snd accr) = [] then getleaves t accl (s3,[s1;s2]) (acct@[h])
	      else if (fst accr) = s1 then getleaves t accl (s3,((snd accr)@[s2])) (acct@[h])
	      else if (fst accr) = s2 then getleaves t accl (s3,((snd accr)@[s1])) (acct@[h])
	      else getleaves t (accl@[h]) accr acct
	    end 
	  | _ -> failwith "getleaves(): Non-ternary relation\n"
	end 
      | _ -> (accl,accr,acct)
    in 
    let rec getfinalleaves l last tlast =
      let (lt,acct,tt) = getleaves l [] last tlast in
      if acct = last then (lt,acct,tt) else getfinalleaves lt acct tt
    in 
    if l = [] then acc 
    else 
      let (lt,acct,tt) = getfinalleaves l ("",[]) [] in
      (*let setl = M.SoL.S.elements (M.SoL.set_of_list (snd acct)) in*)
      setofleaves lt (acc@[(fst acct,snd acct,tt)])
  in 
  let trees_t = setofleaves l [] in
  exttrees_e_t trees_t l;;

(* reads a list of ternary relations, return (sub)trees with the said root *)
let gettreeroot root l =
  let rec gettree root l accl accr acct = (* accl stores unused relations, accr stores leaves, acct stores 2lvl trees *)
    match l with
    | h::t -> 
      begin 
	match h with
	| RT(s1,s2,s3) ->
	  begin
	    if s3 = root && accr = [] then 
	      let thisleaves = [s1;s2] in
	      gettree root t accl (accr@thisleaves) (acct@[(root,thisleaves)])
	    else if (List.mem s3 accr) then 
	      let thisleaves = (M.subtlist s3 accr)@[s1;s2] in
	      gettree root t accl thisleaves (acct@[(root,thisleaves)])
	    else gettree root t (accl@[h]) accr acct
	  end 
	| _ -> failwith "gettree(): Non-ternary relation\n"
      end 
    | _ -> (accl,accr,acct)
  in 
  let rec getfinaltree root l last acctree =
    let (lt,accl,acct) = gettree root l [] last [] in
    if acct = [] then (lt,(root,accl),acctree) else getfinaltree root lt accl (acctree@acct)
  in 
  let rec gettrees root l acc =
    let (lt,accl,acct) = getfinaltree root l [] [] in
    if List.length (snd accl) = 0 then acc else gettrees root lt (acc@acct)
  in 
  gettrees root l [];;

(* search a list of ternary relations find ones with parent node p *)
let getternp p l =
  let rec search p l acc =
    match l with
    | h::t -> let RT(s1,s2,s3) = h in if s3 = p then search p t (acc@[h]) else search p t acc
    | _ -> acc 
  in 
  search p l [];;

(* reads a list of ternary relations, return (sub)trees with the said list of leaves *)
let gettreeleaves leaves l dis =
  let rec candtrees leaves trees acc dis =
    match trees with
    | h::t -> 
      let _ = if dis then (print_string "testing if the tree ";printl2tree h;print_string " contains ";M.printlist leaves) else () in
      if M.listsubset leaves (snd h) then 
	let _ = if dis then print_endline "leaves is a subset" else () in candtrees leaves t (acc@[h]) dis
      else let _ = if dis then print_endline "leaves is not a subset" else () in candtrees leaves t acc dis 
    | _ -> acc 
  in
  let rec getchildren ts acc =
      match ts with
      | h::t -> let RT(s1,s2,s3) = h in getchildren t (acc@[s1;s2])
      | _ -> acc
  in 
  let nlvltrees leaves root l =
    let terns = getternp root l in
    let children = getchildren terns [] in
    let rec searchchild leaves c l acc =
      match c with
      | h::t -> 
	let trees = gettreeroot h l in
	let ntrees = candtrees leaves trees [] dis in
	searchchild leaves t l (acc@ntrees)
      | _ -> acc
    in
    searchchild leaves children l []
  in  
  let rootsubtrees leaves root l =
    let sub_trees trees =
      let rec largesttree trees acc =
	match trees with
	| h::t -> 
	  if List.length (snd h) > List.length (snd acc) then largesttree t h
	  else largesttree t acc 
	| _ -> acc
      in 
      let fulltree = largesttree trees ("",[]) in
      M.subtlist fulltree trees
    in 
    let candroottrees = gettreeroot root l in
    let candrootsubtrees = sub_trees candroottrees in
    let rec filtertrees candtrees leaves acc =
      match candtrees with
      | h::t -> 
	if M.listsubset leaves (snd h) then filtertrees t leaves (acc@[h]) 
	else filtertrees t leaves acc 
      | _ -> acc
    in 
    filtertrees candrootsubtrees leaves []
  in 
  let rec getroots trees acc =
    match trees with
    | h::t -> getroots t (acc@[fst h])
    | _ -> acc
  in 
  let rec subtrees leaves roots l acc =
    match roots with
    | h::t -> 
      let rsubtrees = rootsubtrees leaves h l in
      let ntrees = nlvltrees leaves h l in
      let nroots = getroots ntrees [] in
      subtrees leaves (t@nroots) l (acc@ntrees@rsubtrees)
    | _ -> acc
  in 
  let rec allsubtrees roots l acc =
    match roots with
    | h::t -> allsubtrees t l (acc@(gettreeroot h l))
    | _ -> acc
  in
  (* remove identical candidate tress *)
  let rec simpcantrees candtrees acc =
    let eqtrees t1 t2 = (* consider leaves as a list, since they are generated in the same way *)
      if (fst t1) = (fst t2) && (snd t1) = (snd t2) then true else false
    in
    let rec includedtree tr trl =
      match trl with
      | h::t -> if eqtrees tr h then true else includedtree tr t
      | _ -> false
    in  
    match candtrees with
    | h::t -> if includedtree h acc then simpcantrees t acc else simpcantrees t (acc@[h])
    | _ -> acc
  in 
  (* get l2-trees from LHS, internal nodes can be anything *)
  let l2trees = leavesets l in
  let allroots = getroots l2trees [] in
  let l2subtrees = allsubtrees allroots l [] in
  let ctrees = candtrees leaves (simpcantrees l2subtrees []) [] dis in
  ctrees;;

(* collect all the ternary relations on the RHS of rseqs. The result is a list *)
let getrhstrel rseqs = 
  let rec rhstrel rseqs acc =
    match rseqs with
    | h::t -> 
      begin
	let RSEQ(lr,rr) = h in
	if List.length rr = 1 then (match List.hd rr with | RT(s1,s2,s3) -> rhstrel t (acc@[List.hd rr])| _ -> rhstrel t acc)
	else rhstrel t acc
      end 
    | _ -> acc
  in 
  rhstrel rseqs [];;

(* collect all the equality relations on the RHS of rseqs. The result is a list of lists *)
let getrhseqrel rseqs =
  let rec rhseqrel rseqs acc =
    match rseqs with
    | h::t -> 
      begin
	let RSEQ(lr,rr) = h in
	if List.length rr > 0 then (match List.hd rr with | RT(s1,s2,s3) -> rhseqrel t acc| NULLR -> [[NULLR]] | _ -> rhseqrel t (acc@[rr]))
	else rhseqrel t acc
      end 
    | _ -> acc
  in
  rhseqrel rseqs [];;

(* try to match two 2-lvl trees t1 and t2, return possible 
sets of free variable assignments if successful. The result 
is a list of lists. Return [] if can't find any assignments. *)
let matchtrees t1 t2 dis =
  let matchroot t1 t2 =
    let root1 = fst t1 in
    let root2 = fst t2 in
    if root1 = root2 then REQ("","") 
    else if isfree root1 || isfree root2 then REQ(root1,root2)
    else NULLR (* if Ai = Aj, then return impossible *)
  in 
  let rec addepsilonleaves l num = 
    if num > 0 then addepsilonleaves (l@["epsilon"]) (num-1)
    else l
  in 
  let matchleaves l1 l2 dis =
    let rec matcheigenv l1 l2 accl1 = (* delete the matched eigenvariables in l1 and l2*)
      match l1 with
      | h::t -> 
	if List.mem h l2 then matcheigenv t (M.subtlist h l2) accl1 
	else matcheigenv t l2 (accl1@[h])
      | _ -> (accl1,l2)
    in 
    let matchrest l1 l2 dis = (* make sure if Ai = Xj, then i < j !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*)
      let c1 = M.cartesian [l1;l2] in
      let _ = if dis then (print_endline "posssible combination of assignments are:";M.printlistlist c1;print_endline "") else () in
      let rec mkeqs cartlist len count acc find dis =
	if len <= 0 then acc 
	else
	  begin 
	    match cartlist with
	    | h::t -> 
	      begin
		let v1 = List.nth h 0 in
		let v2 = List.nth h 1 in
		let _ = if dis then print_endline ("count = "^(string_of_int count)^"\nlen = "^(string_of_int len)) else () in 
		if count < len-1 then
		  if find = true then mkeqs t len (count+1) acc find dis 
		  else 
		    begin
		      let _ = if dis then print_endline ("v1 = "^v1^"; v2 = "^v2) else () in
		      if (isfree v1 && iseigen v2 && ((getnum v1) > (getnum v2))) || (isfree v1 && v2 = "epsilon") then 
			let _ = if dis then print_endline "v1 can be assigned to v2" else () in
			mkeqs (M.subslistlist v2 v1 t) len (count+1) (acc@[REQ(v1,v2)]) true dis
		      else if (isfree v2 && iseigen v1 && ((getnum v2) > (getnum v1))) || (isfree v2 && v1 = "epsilon") then 
			let _ = if dis then print_endline "v2 can be assinged to v1" else () in
			mkeqs (M.subslistlist v1 v2 t) len (count+1) (acc@[REQ(v1,v2)]) true dis
		      else 
			let _ = if dis then print_endline "v1 and v2 can't be matched" else () in
			mkeqs t len (count+1) acc false dis
		    end 
		else (* reset count to 0 *)
		  if find = true then mkeqs t len 0 acc false dis 
		  else 
		    begin
		      let _ = if dis then print_endline ("v1 = "^v1^"; v2 = "^v2) else () in
		      if (isfree v1 && iseigen v2 && ((getnum v1) > (getnum v2))) || (isfree v1 && v2 = "epsilon") then 
			let _ = if dis then print_endline "v1 can be assigned to v2" else () in
			if len = 1 then [REQ(v1,v2)]
			else mkeqs (M.subslistlist v2 v1 t) len 0 (acc@[REQ(v1,v2)]) false dis
		      else if (isfree v2 && iseigen v1 && ((getnum v2) > (getnum v1))) || (isfree v2 && v1 = "epsilon") then 
			let _ = if dis then print_endline "v2 can be assigned to v1" else () in
			if len = 1 then [REQ(v1,v2)]
			else mkeqs (M.subslistlist v1 v2 t) len 0 (acc@[REQ(v1,v2)]) false dis
		      else (*if acc = [] then *)
			let _ = if dis then print_endline ("there is no assignment for "^(if isfree v1 then v1 else if isfree v2 then v2 else "this pair")) else () in
			[] (*this eigenvariables has no assignment *)
		    end 
	      end
	    | _ -> acc
	  end 
      in
      let rec deleteused eqs cartlist acc =
	match cartlist with
	| h::t -> 
	  if List.mem (REQ((List.nth h 0),(List.nth h 1))) eqs then deleteused eqs t acc 
	  else deleteused eqs t (acc@[h])
	| _ -> acc
      in 
      let rec mkeqsall cartlist len acc dis =
	let thiseqs = mkeqs cartlist len 0 [] false dis in
	if thiseqs = [] then acc
	else 
	  let restcartlist  = deleteused thiseqs cartlist [] in
	  mkeqsall restcartlist (len-1) (acc@[thiseqs]) dis
      in 
      let eqs = mkeqsall c1 (List.length l2) [] dis in
      eqs
    in
    let (l1t,l2t) = matcheigenv l1 l2 [] in
    if l1t = [] && l2t = [] then [[REQ("s","s")]] 
    else if l2t = [] then [[REQ("t","t")]] (*if the tree on the RHS is a subtree of the candidate trees, both of which have only eigen variable leaves, and the root of the RHS tree is a free variable, then no need to assign free variables. NOT SURE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*)
    else 
      if List.length l2t > List.length l1t then matchrest (addepsilonleaves l1t ((List.length l2t) - (List.length l1t))) l2t dis
      else matchrest l1t l2t dis
  in
  let rec addrootasst eq eqs acc =
    match eqs with
    | h::t -> addrootasst eq t (acc@[h@[eq]])
    | _ -> acc 
  in 
  let asstleaves = matchleaves (snd t1) (snd t2) dis in
  let _ = if dis then (print_endline "asstleaves = ";print_relll asstleaves;print_endline "") else () in
  if asstleaves = [] || asstleaves = [[]] then [] (* the sets of leaves don't match *)
  else if asstleaves = [[REQ("s","s")]] then  (* leaves are matched, checking roots *)
    begin 
      let asstroot = matchroot t1 t2 in
      if asstroot = NULLR then failwith "matchtrees(): different root nodes found\n"
      else if asstroot = REQ("","") then [[REQ("s","s")]]
      else 
	let REQ(r1,r2) = asstroot in [[REQ(r1,r2)]]
    end
  else if asstleaves = [[REQ("t","t")]] then 
    let asstroot = matchroot t1 t2 in
    if asstroot = NULLR then failwith "matchtrees(): different root nodes found\n"
    else if asstroot = REQ("","") then [] (* if the RHS set is the subset of the LHS set, and the roots are the same, then they can't be matched *)
    else 
      let REQ(r1,r2) = asstroot in
      if isfree r1 then [[REQ(r1,("a"^r1))]]
      else if isfree r2 then [[REQ(r2,("a"^r2))]]
      else failwith "if l2 is a subset of l1, and no free variable leaves, then one of the roots must be a free variable"
  else 
    let asstroot = matchroot t1 t2 in
    if asstroot = NULLR then failwith "matchtrees(): different root nodes found\n"
    else if asstroot = REQ("","") then asstleaves 
    else addrootasst asstroot asstleaves [];;

(* assign freev = eigenv in a list of 2-lvl trees, return the substituted list trees *)
let assignfreev freev eigenv trees =
  let assigntree freev eigenv tree = if (fst tree) = freev then (eigenv,(M.subslist eigenv freev (snd tree))) else ((fst tree),(M.subslist eigenv freev (snd tree))) in
  let rec assignall freev eigenv trees acc =
    match trees with
    | h::t -> assignall freev eigenv t (acc@[assigntree freev eigenv h])
    | _ -> acc 
  in 
  assignall freev eigenv trees [];;

(* assign freev in trees according to a list of eq relations *)
let rec assigneqlisttree eqs trees =
  match eqs with
  | h::t -> 
    begin 
      let REQ(s1,s2) = h in
      if isfree s1 then let ntrees = assignfreev s1 s2 trees in assigneqlisttree t ntrees 
      else if isfree s2 then let ntrees = assignfreev s2 s1 trees in assigneqlisttree t ntrees 
      else [("-1",[])] (*failwith "assign(): equality Ai = Aj can't be satisfied\n"*)
    end 
  | _ -> trees;;

(* assgin freev in a list of relations according to a list of eq relations *)
let rec assigneqlist2rl eqs lt =
  match eqs with
  | h::t -> 
    let tmp = subsequality h lt in
    if tmp = [NULLR] then [NULLR]
    else assigneqlist2rl t tmp
  | _ -> lt;;

(* get the set of eigenvariables in the leaves of a tree *)
let geteigenleaves t =
  let rec search l acc =
    match l with
    | h::t -> if iseigen h then search t (acc@[h]) else search t acc
    | _ -> acc 
  in 
  search (snd t) [];;

(* assign freev on the LHS if possible according to a list of eq relations *)
let assignlhsrseqt eqs rseq = 
  let RSEQ(lr,rr) = rseq in
  let tmp = assigneqlist2rl eqs lr in
  if tmp = [NULLR] then RSEQ([NULLR],[NULLR])
  else RSEQ(tmp,rr);;

(* assign freev on rseq if possible according to a list of eq relations *)
let assignrseq eqs rseq = 
  let RSEQ(lr,rr) = rseq in
  let tmp1 = assigneqlist2rl eqs lr in
  let tmp2 = assigneqlist2rl eqs rr in
  if tmp1 = [NULLR] || tmp2 = [NULLR] then RSEQ([NULLR],[NULLR])
  else RSEQ((assigneqlist2rl eqs lr),(assigneqlist2rl eqs rr));;

(* assign freev on rseqs *)
let assignrseqs eqs rseqs =
  let rec assign eqs rseqs acc =
    match rseqs with
    | h::t -> 
      let tmp = assignrseq eqs h in
      if tmp = RSEQ([NULLR],[NULLR]) then [RSEQ([NULLR],[NULLR])]
      else assign eqs t (acc@[tmp])
    | _ -> acc
  in 
  assign eqs rseqs [];;

(* assign freev on a list of rseqs *)
let assignrseqsl eqs rseqsl =
  let rec assign eqs rseqsl acc =
    match rseqsl with
    | h::t -> 
      let tmp = assignrseqs eqs h in
      if tmp = [RSEQ([NULLR],[NULLR])] then [[RSEQ([NULLR],[NULLR])]]
      else 
	assign eqs t (acc@[tmp])
    | _ -> acc
  in 
  assign eqs rseqsl [];;

(* check if a ternary relation is ground*)
let groundtern t =
  match t with
  | RT(w1,w2,w3) -> if iseigen w1 && iseigen w2 && iseigen w3 then true else false
  | _ -> failwith "groundedtern(): invalid ternary relation";;

(* return a list of  ternary relations on the RHS that are grounded *)
let rhsgroundterns rseq =
  let RSEQ(lr,rr) = rseq in
  let rec findgroundtern rl acc =
    match rl with
    | h::t -> if groundtern h then findgroundtern t (acc@[h]) else findgroundtern t acc
    | _ -> acc
  in 
  findgroundtern rr [];;

(* add a list of ground ternary relations to the LHS of rseq, avoid adding same ones *)
let rec addgtern2lhs rseq gterns =
  match gterns with
  | h::t -> 
    let RSEQ(lr,rr) = rseq in
    if List.mem h lr then addgtern2lhs rseq t
    else addgtern2lhs (RSEQ((lr@[h]),rr)) t
  | _ -> rseq;;

(* add a list of ground ternary relations to the LHS of a set of rseq*)
let addallgtern2lhs rseqs gterns =
  let rec add rseqs gterns acc =
    match rseqs with
    | h::t -> add t gterns (acc@[addgtern2lhs h gterns])
    | _ -> acc
  in 
  add rseqs gterns [];;

(* check if a tree (root,leaves) is ground *)
let groundtree tr = 
  let rec groundlist l =
    match l with
    | h::t -> if isfree h then false else groundlist t
    | _ -> true
  in 
  if isfree (fst tr) || not (groundlist (snd tr)) then false else true;;

(* create new label in the assignment for a free variable *)
let newlabelasst fv = REQ(fv,("a"^fv));;

(* test if a label is created by the quickassoc rule *)
let isasso l = (String.contains l 'a') && (String.contains l 'x');;

(* match two sets of ternary relations *)
let matchterns ts1 ts2 rt =
  let rec findpnode ts pn =
    match ts with
    | h::t -> let RT(s1,s2,s3) = h in if s3 = pn then h else findpnode t pn
    | _ -> RT("-1","-1","-1")
  in 
  let rec matchnodes ts1 ts2 n1 n2 =
    let RT(l1,l2,l3) = findpnode ts1 n1 in
    let RT(r1,r2,r3) = findpnode ts2 n2 in
    if l1 = "-1" || r1 = "-1" then false
    else if l1 = r1 && l2 = r2 then true
    else if l1 = r1 then (matchnodes ts1 ts2 l2 r2)
    else if l2 = r2 then (matchnodes ts1 ts2 l1 r1)
    else (matchnodes ts1 ts2 l1 r1) && (matchnodes ts1 ts2 l2 r2)
  in 
  matchnodes ts1 ts2 rt rt;;

(* check if two ternary relations are identical, only new assoc labels are different *)
let sametern t1 t2 =
  let RT(p1,p2,p3) = t1 in
  let RT(q1,q2,q3) = t2 in
  if p1 = q1 && p2 = q2 then true
  else if p1 = q1 && p3 = q3 then true
  else if p2 = q2 && p3 = q3 then true
  else false;;

(* Check if the free variable internal nodes in a tree are created after the eigen variables in the LHS. lhs and treeterns are both lists of ternary relationas  *)
let realfree lhs treeterns =
  let rec getlabels lt acc = 
    match lt with
    | h::t -> let RT(t1,t2,t3) = h in getlabels t (acc@[t1;t2;t3])
    | _ -> acc
  in
  let rec getfvs lt acc = 
    match lt with
    | h::t -> 
      let RT(t1,t2,t3) = h in 
      if isfree t1 & isfree t2 & isfree t3 then getlabels t (acc@[t1;t2;t3])
      else if isfree t1 & isfree t2 then getlabels t (acc@[t1;t2])
      else if isfree t1 & isfree t3 then getlabels t (acc@[t1;t3])
      else if isfree t2 & isfree t3 then getlabels t (acc@[t2;t3])
      else if isfree t1 then getlabels t (acc@[t1])
      else if isfree t2 then getlabels t (acc@[t2])
      else if isfree t3 then getlabels t (acc@[t3])
      else getlabels t acc
    | _ -> acc
  in
  let rec greatestnum ll max =
    match ll with
    | h::t -> let num = getnum h in if num > max then greatestnum t num else greatestnum t max
    | _ -> max
  in 
  let rec isrealfree lf max = 
    match lf with
    | h::t -> let num = getnum h in if num > max then isrealfree t max else false
    | _ -> true
  in 
  let lhslabels = getlabels lhs [] in
  let treefvs = getfvs treeterns [] in
  let lhsmax = greatestnum lhslabels 0 in
  if isrealfree treefvs lhsmax then true else false;;

(* if a RHS tree only has ground leaves and free variable internal nodes, then assign internal nodes to new labels, add related ternary relations to the LHS, return the following format: (rseq,[terns],[asst]) *)
let quickassoc rseq = 
  let RSEQ(lr,rr) = rseq in
  let trees = leavesets_fi_t rr in (* this tree is of the from (root,leaves,terns) *)
  let rec lhssametern lr tr =
    match lr with 
    | h::t -> if sametern h tr then true else lhssametern t tr
    | _ -> false
  in 
  let delsametern lr ts =
    let rec del lr ts acc =
      match ts with
      | h::t -> if lhssametern lr h then del lr t acc else del lr t (acc@[h])
      | _ -> acc
    in 
    del lr ts []
  in 
  let delasst terns asst =
    let rec newls terns acc =
      match terns with
      | h::t -> let RT(s1,s2,s3) = h in 
		if isasso s1 && isasso s2 && isasso s3 then newls t (acc@[s1;s2;s3])
		else if isasso s1 && isasso s2 then newls t (acc@[s1;s2])
		else if isasso s2 && isasso s3 then newls t (acc@[s2;s3])
		else if isasso s1 && isasso s3 then newls t (acc@[s1;s3])
		else if isasso s1 then newls t (acc@[s1])
		else if isasso s2 then newls t (acc@[s2])
		else if isasso s3 then newls t (acc@[s3])
		else newls t acc
      | _ -> acc
    in 
    let nnl = newls terns [] in
    let rec delasst nnl asst acc =
      match asst with
      | h::t -> let REQ(s1,s2) = h in
		if List.mem s2 nnl then delasst nnl t (acc@[h])
		else delasst nnl t acc
      | _ -> acc
    in 
    delasst nnl asst []
  in 
  let assigninter tree =
    let (root,leaves,terns) = tree in
    let rec assign terns acc =
      match terns with
      | h::t -> 
	let RT(s1,s2,s3) = h in
	if isfree s1 && isfree s2 && isfree s3 then assign t (acc@[(newlabelasst s1);(newlabelasst s2);(newlabelasst s3)])
	else if isfree s1 && isfree s2 then assign t (acc@[(newlabelasst s1);(newlabelasst s2)])
	else if isfree s1 && isfree s3 then assign t (acc@[(newlabelasst s1);(newlabelasst s3)])
        else if isfree s2 && isfree s3 then assign t (acc@[(newlabelasst s2);(newlabelasst s3)]) 
	else if isfree s1 then assign t (acc@[(newlabelasst s1)])
	else if isfree s2 then assign t (acc@[(newlabelasst s2)])
	else if isfree s3 then assign t (acc@[(newlabelasst s3)])
	else assign t acc
      | _ -> acc
    in 
    let asst = assign terns [] in
    let nterns = assigneqlist2rl asst terns in
    (nterns,asst)
  in 
  let rec addgtrees rseq trees accterns accassts =
  match trees with
  | h::t -> 
    begin
      let (root,leaves,terns) = h in
      (* check if this is right!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*)
      if (groundtree (root,leaves)) & (realfree lr terns) then 
	let (nt,at) = assigninter h in
	if nt = [NULLR] then (RSEQ([NULLR],[NULLR]),[],[])
	else 
	let RSEQ(lr,rr) = rseq in
	let nnt = delsametern lr nt in
	let nat = delasst nnt at in
	let tmpl = assigneqlist2rl nat lr in
	let tmpr = assigneqlist2rl nat rr in
	if tmpl = [NULLR] || tmpr = [NULLR] then (RSEQ([NULLR],[NULLR]),[],[])
	else addgtrees (RSEQ(tmpl@nnt,tmpr)) t (accterns@nnt) (accassts@nat)
      else addgtrees rseq t accterns accassts
    end 
  | _ -> (rseq,accterns,accassts)
  in 
  addgtrees rseq trees [] [];;

(* test if two trees are the same *)
let sametree tr1 tr2 =
  let rec sameleaves l1 l2 =
    match l1 with
    | h::t -> if List.mem h l2 then sameleaves t (M.subtlist h l2) else false
    | _ -> if List.length l2 = 0 then true else false
  in 
    if ((fst tr1) = (fst tr2)) && (sameleaves (snd tr1) (snd tr2)) then true else false;; 

(* delete the identical assignments *)
let simpassts assts =
  let rec del assts acc =
    match assts with
    | h::t -> 
      let REQ(s1,s2) = h in
      if List.mem (REQ(s1,s2)) acc || List.mem (REQ(s2,s1)) acc then del t acc
      else del t (acc@[h])
    | _ -> acc
  in 
  del assts [];;
    
(* if tr only has ground leaves and free variable internal nodes, then assign internal nodes to new labels, add related ternary relations to the LHS, return the following format: (rseq,[terns],[asst]) *)
let quickassoc2 rseq tr = 
  let rec lhssametern lr tr =
    match lr with 
    | h::t -> if sametern h tr then true else lhssametern t tr
    | _ -> false
  in 
  let delsametern lr ts =
    let rec del lr ts acc =
      match ts with
      | h::t -> if lhssametern lr h then del lr t acc else del lr t (acc@[h])
      | _ -> acc
    in 
    del lr ts []
  in 
  let delasst terns asst =
    let rec newls terns acc =
      match terns with
      | h::t -> let RT(s1,s2,s3) = h in 
		if isasso s1 && isasso s2 && isasso s3 then newls t (acc@[s1;s2;s3])
		else if isasso s1 && isasso s2 then newls t (acc@[s1;s2])
		else if isasso s2 && isasso s3 then newls t (acc@[s2;s3])
		else if isasso s1 && isasso s3 then newls t (acc@[s1;s3])
		else if isasso s1 then newls t (acc@[s1])
		else if isasso s2 then newls t (acc@[s2])
		else if isasso s3 then newls t (acc@[s3])
		else newls t acc
      | _ -> acc
    in 
    let nnl = newls terns [] in
    let rec delasst nnl asst acc =
      match asst with
      | h::t -> let REQ(s1,s2) = h in
		if List.mem s2 nnl then delasst nnl t (acc@[h])
		else delasst nnl t acc
      | _ -> acc
    in 
    delasst nnl asst []
  in 
  let assigninter tree =
    let (root,leaves,terns) = tree in
    let rec assign terns acc =
      match terns with
      | h::t -> 
	let RT(s1,s2,s3) = h in
	if isfree s1 && isfree s2 && isfree s3 then assign t (acc@[(newlabelasst s1);(newlabelasst s2);(newlabelasst s3)])
	else if isfree s1 && isfree s2 then assign t (acc@[(newlabelasst s1);(newlabelasst s2)])
	else if isfree s1 && isfree s3 then assign t (acc@[(newlabelasst s1);(newlabelasst s3)])
	else if isfree s2 && isfree s3 then assign t (acc@[(newlabelasst s2);(newlabelasst s3)]) 
	else if isfree s1 then assign t (acc@[(newlabelasst s1)])
	else if isfree s2 then assign t (acc@[(newlabelasst s2)])
	else if isfree s3 then assign t (acc@[(newlabelasst s3)])
	else assign t acc
      | _ -> acc
    in 
    let asst = assign terns [] in
    let asst2 = simpassts asst in
    let nterns = assigneqlist2rl asst2 terns in
    (nterns,asst2)
  in 
  let rec addgtrees rseq trees accterns accassts =
    match trees with
    | h::t -> 
      begin
	let (root,leaves,terns) = h in
	if groundtree (root,leaves) then 
	  let (nt,at) = assigninter h in
	  if nt = [NULLR] then (RSEQ([NULLR],[NULLR]),[],[])
	  else 
	    let RSEQ(lr,rr) = rseq in
	    let nnt = delsametern lr nt in
	    let nat = delasst nnt at in
	    let tmpl = assigneqlist2rl nat lr in
	    let tmpr = assigneqlist2rl nat rr in
	    if tmpl = [NULLR] || tmpr = [NULLR] then (RSEQ([NULLR],[NULLR]),[],[])
	    else addgtrees (RSEQ(tmpl@nnt,tmpr)) t (accterns@nnt) (accassts@nat)
	else addgtrees rseq t accterns accassts
      end 
    | _ -> (rseq,accterns,accassts)
  in
  let rec tree2tern trs tr =
    match trs with
    | h::t -> let (root,leaves,terns) = h in if sametree (root,leaves) tr then terns else tree2tern t tr
    | _ -> [] (*failwith "quickassoc2(): tr is not in the RHS of rseq"*) (* may be caused by some free variables in tr being assigned to assoc varaibles *)
  in
  let RSEQ(lr,rr) = rseq in
  let trees = leavesets_fi_t rr in (* this tree is of the from (root,leaves,terns) *)
  let terns = tree2tern trees tr in
  if terns = [] then 
    begin
      (* find trees with eigen internal nodes *)
      let trees_e = leavesets_t rr in 
      (* if one of the trees_e is match to tr, then some internal free variables in tr must be assigned to assoc eigen variables *)
      let terns_e = tree2tern trees_e tr in 
      if terns_e = [] then (RSEQ([NULLR],[NULLR]),[],[]) 
      else 
	begin
	  let thetree = ((fst tr),(snd tr),terns_e) in
	  addgtrees rseq [thetree] [] []
	end 
    end 
  else 
  begin
    let thetree = ((fst tr),(snd tr),terns) in
    addgtrees rseq [thetree] [] []
  end;;

(*solve every tree in the RHS of rseqs*)
let solverhstrees rseqs trees dis =
  let rec mkeps l acc =
    match l with
    | h::t -> if isfree h then mkeps t (acc@[REQ("epsilon",h)]) else mkeps t acc 
    | _ -> acc
  in 
  let mkeps2 root l =
    let rec arbiassign root l acc =
      match l with
      | h::t -> if isfree h then ((REQ(root,h)),(acc@t)) else arbiassign root t (acc@[h])
      | _ -> failwith "arbiassign(): no free variable in the list"
    in 
    if List.mem root l then mkeps (M.subtlist root l) []
    else let (asst,lt) = arbiassign root l [] in ([asst]@(mkeps lt []))
  in 
  let mkidr l =
    let rec idr l acc =
      match l with
      | h::t -> idr t (acc@[(h,[h;"epsilon"])])
      | _ -> acc
    in 
    idr l []
  in 
  let rec solve rseqs trees acc accterns dis =
    let rec trytrees rseqs candts thistree resttrees accterns dis =
      match candts with
      | ht::tt -> 
	begin (* try to match a (sub)tree ht on the LHS *)
	  let _ = if dis then (print_endline "trying to match with (sub)tree:";printl2tree ht;print_endline "") else () in
	  let asst = matchtrees ht thistree dis in 
	  if asst = [] || asst = [[]] then (* can't find a match, try the next candidate tree *)
	    let _ = if dis then print_endline "can't find a match" else () in
	    trytrees rseqs tt thistree resttrees accterns dis 
	  else if asst = [[REQ("s","s")]] then (* find match, no assignments *)
	    begin
	      let (nrseqs,aterns,ast) = quickassoc2 rseqs thistree in
	      if nrseqs = RSEQ([NULLR],[NULLR]) then trytrees rseqs tt thistree resttrees accterns dis
	      else 
	      let (rt,rasst,rterns) = solve nrseqs resttrees (acc@ast) (accterns@aterns) dis in
	      if rt = true then let _ = if dis then print_endline "find match with no assignments" else () in (rt,rasst,rterns)
	      else 
		let _ = if dis then (print_endline "can't match the tree with:";printl2tree ht;print_endline "trying the next tree") else () in
		trytrees rseqs tt thistree resttrees accterns dis 
	    end
	  else (* find matches, now try assignments *)
	    begin 
	      let _ = if dis then (print_endline "possible assignments are:";print_relll asst;print_endline "") else () in
	      let rec tryassts rseqs asst thistree resttrees accterns dis = 
		match asst with
		| hasst::tasst -> 
		  begin (* try an assignment for the match of ht *)
		    let _ = if dis then (print_endline "trying the assignment:";print_rell hasst;print_endline "") else () in
		    let [thistree2] = assigneqlisttree hasst [thistree] in 
		    if thistree2 = ("-1",[]) then tryassts rseqs tasst thistree resttrees accterns dis
		    else 
		    let nrseqs = assignrseq hasst rseqs in
		    if nrseqs = RSEQ([NULLR],[NULLR]) then tryassts rseqs tasst thistree resttrees accterns dis
		    else 
		      let (nnrseq,aterns,ast) = quickassoc2 nrseqs thistree2 in 
		      if nnrseq = RSEQ([NULLR],[NULLR]) then tryassts rseqs tasst thistree resttrees accterns dis
		      else 
			let nthistree = assigneqlisttree (hasst@ast) [thistree] in
			let nresttrees = assigneqlisttree (hasst@ast) resttrees in
			if nthistree = [("-1",[])] || nresttrees = [("-1",[])] then tryassts rseqs tasst thistree resttrees accterns dis
			else 
			  let _ = 
			    if dis then 
			    let RSEQ(lp,rp) = nnrseq in
			    print_endline "now the LHS is:";print_rell lp;print_endline "";
			    print_endline "the current tree is:";printl2tree (List.hd nthistree);print_endline "";
			    print_endline "the rest trees are:";printl2trees nresttrees;print_endline "" 
			    else ()
			  in   
			  let (rt,rasst,rterns) = solve nnrseq nresttrees (acc@hasst@ast) (accterns@aterns) dis in
			  if rt = true then (rt,rasst,rterns)
			  else tryassts rseqs tasst thistree resttrees accterns dis
		  end 
		| _ -> 
		  let _ = if dis then print_endline "all assignments exhausted" else () in
		  (false,[],[]) (*all assignments for this tree tried *)
	      in
	      let (rt,rasst,rterns) = tryassts rseqs asst thistree resttrees accterns dis in
	      if rt then (rt,rasst,rterns)
	      else 
		let _ = if dis then (print_endline "can't match the tree with:";printl2tree ht;print_endline "trying the next tree") else () in
		trytrees rseqs tt thistree resttrees accterns dis 
	    end 
	end 
      | _ -> 
	let _ = if dis then print_endline "all candidate trees exhausted" else () in
	(false,[],[]) (*all candidate trees tried *)
    in
    let RSEQ(lr,rr) = rseqs in
    match trees with
    | h::t -> 
      begin
	let _ = if dis then (print_endline "triyng to solve tree:";printl2tree h;print_endline "") else () in
	if isfree (fst h) then (* the root is a free variable *)
	  begin
	    let eigenleaves = geteigenleaves h in
	    if lr = [] then 
	      if List.length eigenleaves > 1 then (false,[],[])
	      else 
		begin
		  let freeleaves = if List.length eigenleaves = 1 then M.subtlist (List.hd eigenleaves) (snd h) else (snd h) in
		  let asst = [REQ((fst h),(List.hd eigenleaves))]@(mkeps freeleaves []) in
		  let nrseqs = assignrseq asst rseqs in
		  if nrseqs = RSEQ([NULLR],[NULLR]) then (false,[],[])
		  else 
		  (*let nrseqs = assignlhsrseqt asst rseqs in*)
		  let nthistree = assigneqlisttree asst [h] in
		  let nresttrees = assigneqlisttree asst t in
		  if nthistree = [("-1",[])] || nresttrees = [("-1",[])] then (false,[],[])
		  else 
		  let _ =
		    if dis then 
		    let RSEQ(lp,rp) = nrseqs in
		    print_endline "now the LHS is:";print_rell lp;print_endline "";
		    print_endline "the current tree is:";printl2tree (List.hd nthistree);print_endline "";
		    print_endline "the rest trees are:";printl2trees nresttrees;print_endline "" 
		    else ()
		  in
		  let (rt,rasst,rterns) = solve nrseqs nresttrees (acc@asst) accterns dis in
		  if rt then (rt,rasst,rterns)
		  else (false,[],[])
		end 
	    else 
	      begin 
		let _ = if dis then (print_string "trying to find (sub)trees with leaves {";M.printlist eigenleaves;print_endline "}") else () in
		let cts = if List.length eigenleaves = 1 then (gettreeleaves eigenleaves lr dis)@[((List.hd eigenleaves),[(List.hd eigenleaves);"epsilon"])] else  gettreeleaves eigenleaves lr dis in
		let _ = if dis then (print_endline "candidate (sub)trees are:";printl2trees cts;print_endline "") else () in
		trytrees rseqs cts h t accterns dis 
	      end 
	  end 
	else (* the root is an eigenvariable*)
	  begin
	    if lr = [] then 
	      let eigenleaves = geteigenleaves h in
	      if List.length eigenleaves > 1 then (false,[],[])
	      else 
		begin 
		  let asst = mkeps2 (fst h) (snd h) in
		  let nrseqs = assignrseq asst rseqs in
		  if nrseqs = RSEQ([NULLR],[NULLR]) then (false,[],[])
		  else 
		  (*let nrseqs = assignlhsrseqt asst rseqs in*)
		  let nthistree = assigneqlisttree asst [h] in
		  let nresttrees = assigneqlisttree asst t in
		  if nthistree = [("-1",[])] || nresttrees = [("-1",[])] then (false,[],[])
		  else 
		  let _ = 
		    if dis then 
		    let RSEQ(lp,rp) = nrseqs in
		    print_endline "now the LHS is:";print_rell lp;print_endline "";
		    print_endline "the current tree is:";printl2tree (List.hd nthistree);print_endline "";
		    print_endline "the rest trees are:";printl2trees nresttrees;print_endline "" 
		    else ()
		  in
		  let (rt,rasst,rterns) = solve nrseqs nresttrees (acc@asst) accterns dis in
		  if rt then (rt,rasst,rterns)
		  else (false,[],[])
		end 
	    else 
	      begin 
		let _ = if dis then print_endline ("trying to find (sub)trees with root "^(fst h)) else () in
		let cts = (gettreeroot (fst h) lr)@[((fst h),[(fst h);"epsilon"])] in
		let _ = if dis then (print_endline "candidate (sub)trees are:";printl2trees cts;print_endline "") else () in
		trytrees rseqs cts h t accterns dis
	      end 
	  end 
      end
    | _ -> (true,acc,accterns) 
  in 
  solve rseqs trees [] [] dis;;

(* reads rseqs, return the set of ternary relations on the LHS *)
(* Note that in this version, very LHS in the set is the same *)
let getlhstern rseqs =
  if List.length rseqs > 0 then let RSEQ(lr,rr) = List.hd rseqs in lr
  else [];;

(* reads rseqs, return the set of ternary relations on the RHS *)
let getrhstern rseqs =
  let rec getrts rseqs acc =
    match rseqs with
    | h::t -> let RSEQ(lr,rr) = h in if List.length rr > 0 && istern (List.hd rr) then getrts t (acc@rr) else getrts t acc (* Note that rr can only have one ternary relation, or multiple equalities *)
    | _ -> acc
  in 
  getrts rseqs [];;

(* recover rseqs from rseq by allowing only one ternary relation on each RHS *)
let recrseqs rseq =
  let RSEQ(lr,rr) = rseq in
  let rec rebuild lr rr acc =
    match rr with
    | h::t -> rebuild lr t (acc@[RSEQ(lr,[h])])
    | _ -> acc
  in 
  rebuild lr rr [];;

(* try to solve rseqs if possible *)
let relsolver rseqs dis = 
  let rec simpeqs eqs acc = (* delete groups with (Ai = Ai) *)
    match eqs with
    | h::t -> if istrivial h then simpeqs t acc else simpeqs t (acc@[h])
    | _ -> acc
  in
  let rec conform eq eql = (* check if eq is consistent in eql *)
    match eql with
    | h::t -> 
      begin
	let REQ(s1,s2) = h in
	let REQ(t1,t2) = eq in
	if isfree s1 then (
	  if isfree t1 && t1 = s1 && t2 != s2 then false 
	  else if isfree t2 && t2 = s1 && t1 != s2 then false
	  else conform eq t)
	else if isfree s2 then (
	  if isfree t1 && t1 = s2 && t2 != s1 then false
	  else if isfree t2 && t2 = s2 && t1 != s1 then false
	  else conform eq t)
	else conform eq t
      end 
    | _ -> true
  in
  let rec conformlist eql = (* check if eqs is consistent *)
    match eql with
    | h::t -> if conform h t then conformlist t else false
    | _ -> true
  in 
  let rec simpeqs2 eqs acc = (* delete groups like (Ai=Xj);(Ak=Xj);... *)
    match eqs with
    | h::t -> if conformlist h then simpeqs2 t (acc@[h]) else simpeqs2 t acc
    | _ -> acc
  in 
  let rec valideql eql =
    match eql with
    | h::t -> let REQ(s1,s2) = h in if (isfree s1) = false && (isfree s2) = false then false else valideql t
    | _ -> true
  in
  let rec trysolve eqs rseq dis =
    match eqs with
    | h::t -> 
      begin
	let _ = if dis then print_endline "assigning the folowing equalities on the RHS" else () in
	let _ = if dis then (print_rell h;print_endline "") else () in
	if valideql h then 
	  begin
	    let nrseq = assignrseq h rseq in
	    if nrseq = RSEQ([NULLR],[NULLR]) then trysolve t rseq dis
	    else 
	    let nrseqs = recrseqs nrseq in
	    let (nrseqst,asstt) = matchtern nrseqs in
	    if asstt = [REQ("-1","-1")] then trysolve t rseq dis 
	    else 
	      begin
		let _ = if dis then print_endline "further assigning the folowing equalities on the RHS" else () in
		let _ = if dis then (print_rell asstt;print_endline "") else () in
		let RSEQ(ltt,rtt) = nrseq in
		(* extend the RHS tree with the ternary relations on LHS *)
		let tst = exttrees (leavesets_fi (getrhstrel nrseqst)) ltt in
		let ots = exttrees (leavesets_fi (getrhstrel nrseqs)) ltt in
		let _ = if dis then (print_endline "nrseqs is:";print_rseqs nrseqs;print_endline "") else () in
		let _ = if dis then (print_endline "nrseqst is:";print_rseqs nrseqst;print_endline "") else () in
		if tst = [("-1",[])] then (*trysolve t ts rseq*) ([REQ("-1","-1")],[])
		else 
		  begin
		    let RSEQ(l,r) = nrseq in
		    let (rt,rasst,rterns) = solverhstrees (RSEQ(l,(getrhstrel nrseqst))) tst dis in (* changed from rseq to nrseqst here !!!!!!!!!*)
		    if rt = true then 
		      ((h@rasst),rterns)
		    else trysolve t rseq dis  
		  end
	      end
	  end
	else trysolve t rseq dis  
      end 
    | _ -> let _ = if dis then print_endline "no more equalities on the RHS to assign" else () in ([REQ("-1","-1")],[])
  in
  let lt = getlhstern rseqs in 
  let rt = getrhstern rseqs in
  let rseq = RSEQ(lt,rt) in (* rseq contains the set of ternary relations on LHS and RHS *)
  (*let rhsts = exttrees (leavesets_fi (getrhstrel rseqs)) lt in*)
  let eqrels = getrhseqrel rseqs in
  if eqrels = [[NULLR]] then ([REQ("-1","-1")],[])
  else 
    begin
      let rhseqs = simpeqs (eqrels) [] in
      let _ = if dis then print_endline "computing all combinations of known assignments" else () in
      let eqcombins = M.cartesian rhseqs in
      let eqcombins2 = simpeqs2 eqcombins [] in 
      let _ = if dis then print_endline "trying to solve the problem" else () in
      if eqcombins2 = [] || eqcombins2 = [[]] then 
	begin
	  let _ = if dis then print_endline "No equalities on the RHS" else () in
	  let rseqs = recrseqs rseq in
	  let RSEQ(ltf,rtf) = rseq in
	  let ts = exttrees (leavesets_fi (getrhstrel rseqs)) ltf in
	  let (rt,rasst,rterns) = solverhstrees rseq ts dis in
	  if rt = true then 
	    (rasst,rterns) 
	  else ([REQ("-1","-1")],[])
	end 
      else trysolve eqcombins2 rseq dis
    end;;

(* Group rseqs according to the LHS *)
let grouprseqs rseqs =
  let rec add rseq rseqll acc =
    match rseqll with
    | h::t -> 
      begin
	let firstrseq = if List.length h > 0 then List.hd h else RSEQ([],[]) in
	let RSEQ(lr,rr) = firstrseq in
	let RSEQ(lrt,rrt) = rseq in
	if lrt = lr then (acc@[h@[rseq]]@t)
	else add rseq t (acc@[h])
      end 
    | _ -> acc@[[rseq]]
  in 
  let rec addall rseqs rseqll =
    match rseqs with
    | h::t -> let rseqllt = add h rseqll [] in addall t rseqllt 
    | _ -> rseqll
  in 
  addall rseqs [];;

(* add a list of ternary relations to the LHS of rseq *)
let addternlhs rseq terns =
  let RSEQ(lr,rr) = rseq in
  RSEQ((lr@terns),rr);;

(* add a list of ternary relations to the LHS of each one in rseqs *)
let addallternlhs rseqs terns =
  let rec add rseqs terns acc =
    match rseqs with
    | h::t -> add t terns (acc@[addternlhs h terns])
    | _ -> acc
  in 
  add rseqs terns [];;
      
let addrllternlhs rll terns =
  let rec add rll terns acc =
    match rll with
    | h::t -> add t terns (acc@[addallternlhs h terns])
    | _ -> acc
  in 
  add rll terns [];;

let relsolver2 rseqs dis =
  let rseqll = grouprseqs rseqs in
  let rec solveall rll asst = 
    match rll with
    | h::t -> 
      let _ = if dis then (print_endline "solving the set of relational sequents:";print_rseqs h;print_endline "") else () in
      let (thisasst,thisterns) = relsolver h dis in
      let simpedasst = simpassts thisasst in
      if thisasst = [REQ("-1","-1")] then 
	let _ = if dis then print_endline "this group of rseqs can't be satisfied" else () in [REQ("-1","-1")]
      else 
	let tmp = assignrseqsl thisasst t in
	if tmp = [[RSEQ([NULLR],[NULLR])]] then [REQ("-1","-1")]
	else 
	  solveall (addrllternlhs (assignrseqsl thisasst t) thisterns) (asst@thisasst)
    | _ -> asst
  in 
  solveall rseqll [];;

(* Translate a list of relational sequents to fof *)
let rec rseqstrans rseqs =
  let rec sepv rr acc1 acc2 = (*acc1 is for free variable, acc2 is for eigenvariable*)
    match rr with
    | h::t -> 
      begin 
	match h with
	| RT(s1,s2,s3) -> 
	  begin
	    if (isfree s1) && (isfree s2) && (isfree s3) then sepv t (acc1@[s1;s2;s3]) acc2
	    else if (isfree s1) && (isfree s2) then sepv t (acc1@[s1;s2]) (acc2@[s3])
	    else if (isfree s1) && (isfree s3) then sepv t (acc1@[s1;s3]) (acc2@[s2])
	    else if (isfree s2) && (isfree s3) then sepv t (acc1@[s2;s3]) (acc2@[s1])
	    else if (isfree s1) then sepv t (acc1@[s1]) (acc2@[s2;s3])
	    else if (isfree s2) then sepv t (acc1@[s2]) (acc2@[s1;s3]) 
	    else if (isfree s3) then sepv t (acc1@[s3]) (acc2@[s1;s2])
	    else sepv t acc1 (acc2@[s1;s2;s3]) 
	  end 
	| REQ(s1,s2) ->
	  begin 
	    if (isfree s1) && (isfree s2) then sepv t (acc1@[s1;s2]) acc2
	    else if (isfree s1) then sepv t (acc1@[s1]) (acc2@[s2])
	    else if (isfree s2) then sepv t (acc1@[s2]) (acc2@[s1])
	    else sepv t acc1 (acc2@[s1;s2])
	  end 
	| _ -> failwith "findfreev(): Not a valid relation\n"
      end 
    | _ -> (*M.SoL.S.elements (M.SoL.set_of_list acc)*) (acc1,acc2)
  in 
  let rec sepallv rseqs acc1 acc2 =
    match rseqs with
    | h::t -> 
      begin
	match h with
	| RSEQ(lr,rr) -> let (acct1,acct2) = sepv (lr@rr) [] [] in sepallv t (acc1@acct1) (acc2@acct2)
	| _ -> failwith "findallfreev(): Not a valid relational sequent\n"
      end 
    | _ -> 
      let fvlist = M.SoL.S.elements (M.SoL.set_of_list acc1) in
      let evlist = M.SoL.S.elements (M.SoL.set_of_list acc2) in
      if List.mem "epsilon" evlist then (fvlist,(M.subtlist "epsilon" evlist))
      else (fvlist,evlist)
  in
  let rec quan fv acc =
    match fv with
    | h::t -> 
      if (List.length t) > 0 then quan t (acc^(String.uppercase h)^",")
      else quan t (acc^(String.uppercase h))
    | _ -> acc
  in 
  let up s = if s = "epsilon" then s else String.uppercase s in
  let rec transrsl rs acc =
    match rs with
    | h::t -> 
      begin
	match h with 
	| RT(s1,s2,s3) ->
	  begin
	    if (List.length t) > 0 then transrsl t (acc^"r("^(up s1)^","^(up s2)^","^(up s3)^") & ")
	    else transrsl t (acc^"r("^(up s1)^","^(up s2)^","^(up s3)^")")
	  end
	| _ -> failwith "transrs(): Not a valid ternary relation\n"
      end 
    | _ -> acc 
  in 
  let rec transrsr rs acc =
    match rs with
    | h::t -> 
      begin
	match h with 
	| RT(s1,s2,s3) ->
	  begin
	    if (List.length t) > 0 then transrsr t (acc^"r("^(up s1)^","^(up s2)^","^(up s3)^") | ")
	    else transrsr t (acc^"r("^(up s1)^","^(up s2)^","^(up s3)^")")
	  end
	| REQ(s1,s2) ->
	  begin
	    if (List.length t) > 0 then transrsr t (acc^"("^(up s1)^" = "^(up s2)^") | ")
	    else transrsr t (acc^"("^(up s1)^" = "^(up s2)^")")
	  end 
	| _ -> failwith "transrs(): Not a valid relation\n"
      end 
    | _ -> acc 
  in
  let rstrans rseq =
    match rseq with
    | RSEQ(lr,rr) ->
      begin 
	let lft = transrsl lr "" in
	let lf = if lft = "" then "$true" else lft in
	let rft = transrsr rr "" in
	let rf = if rft = "" then "$false" else rft in
	"(("^lf^") => ("^rf^"))"
      end 
    | _ -> failwith "rseqtrans(): Not a valid relational sequent\n"
  in 
  let rec rsstrans rseqs acc =
  match rseqs with
  | h::t -> 
    begin
      match h with
      | RSEQ(lr,rr) ->
	begin
	  if (List.length rr) = 0 then 
	    begin
	      if (List.length t) > 0 then rsstrans t (acc^" $true & ")
	      else rsstrans t (acc^" $true") 
	    end 
	  else 
	    begin 
	      if (List.length t) > 0 then rsstrans t (acc^"("^(rstrans h)^") & ") 
	      else rsstrans t (acc^"("^(rstrans h)^")")
	    end 
	end 
    end 
  | _ -> acc
  in 
  let (fvlist,evlist) = sepallv rseqs [] [] in
  let fvstr = quan fvlist "" in
  let evstr = quan evlist "" in
  let qf = if fvstr = "" then "" else "? ["^fvstr^"]: " in
  let qe = if evstr = "" then "" else "! ["^evstr^"]: " in
  let fof = rsstrans rseqs "" in
  "fof(identity,axiom,(\n\t ! [A,B]: (r(epsilon,A,B) <=> (A = B)))).\n\nfof(commutativity,axiom,(\n\t! [A,B,C]: (r(A,B,C) <=> r(B,A,C)))).\n\nfof(associativity,axiom,(\n\t ! [A,B,C,D]: ((? [K]: (r(A,K,D) & r(B,C,K))) => (? [P]: (r(A,B,P) & r(P,C,D)))))).\n\nfof(problem,conjecture,(\n\t"^qe^"("^qf^"("^fof^")))).\n";;


(* The following processes the proof search and prints the resutls *)

(* Print the 2 level tree with 1 parent and multiple children*)
let rec print_latexl2trees l fp =
  let rec print_latexlist l fp =
    match l with
    | h::t -> 
      output_string fp h;
      if (List.length t) > 0 then output_string fp ";";
      print_latexlist t fp
    | _ -> ()
  in
  match l with
  | h::t -> output_string fp ("$"^(fst h)^"=\{");print_latexlist (snd h) fp;output_string fp ("\}$\\\\\n");print_latexl2trees t fp
  | _ -> ();;

let writetexhead fp =
  let _ = print_endline "writing latex head" in
  let _ = output_string fp "\\documentclass[landscape,11pt]{article}\n" in
  let _ = output_string fp "\\usepackage[paperheight=5in,paperwidth=100in]{geometry}\n" in
  let _ = output_string fp "\\usepackage{amssymb}\n" in
  let _ = output_string fp "\\usepackage{amsthm}\n" in
  let _ = output_string fp "\\usepackage{amsmath}\n" in
  let _ = output_string fp "\\usepackage{bussproofs}\n" in
  let _ = output_string fp "\\newcommand{\lexcl}[0]{{\ensuremath{-\!\!\!<\;}}}\n" in
  let _ = output_string fp "\\newcommand{\mexcl}[0]{{\ensuremath{-\!\!\!\!-\!\!\!\!\\times\;}}}\n" in
  let _ = output_string fp "\\newcommand{\limp}[0]{\ensuremath{\\rightarrow}}\n" in
  let _ = output_string fp "\\newcommand{\llimp}[0]{\ensuremath{\multimap}}\n" in
  let _ = output_string fp "\\newcommand{\mimp}[0]{\ensuremath{{-\!*\;}}}\n" in
  let _ = output_string fp "\\newcommand{\ie}[0]{\ensuremath{\vartriangleright}}\n" in
  let _ = output_string fp "\\newcommand{\\turnstile}[0]{\ensuremath{\vdash}}\n" in
  let _ = output_string fp "\\newcommand{\simp}[0]{\ensuremath{\\triangleright}}\n" in
  let _ = output_string fp "\\newcommand{\mor}[0]{\ensuremath{\overset{*}\lor}}\n" in
  let _ = output_string fp "\\newcommand{\mnot}[0]{\ensuremath{\sim\!\!\;}}\n" in
  let _ = output_string fp "\\newcommand{\mand}[0]{\ensuremath{*}}\n" in
  let _ = output_string fp "\\title{Derivation}\n" in
  let _ = output_string fp "\\author{Zh\'e}\n" in
    output_string fp "\\begin{document}\n";;

let writetexend fp =
  let _ = print_endline  "writing latex end" in
    output_string fp "\n\\end{document}\n";;

let latexbracket p n f x y fp =
  (if p then output_string fp "(" else ());
  Format.open_box n;f x y;Format.close_box();
  (if p then output_string fp")" else ());;

let print_latexformula fp =
  let rec print_latexformula pr fp fm =
    match fm with
      | F.FALSE -> output_string fp "\\bot "
      | F.TRUE -> output_string fp "\\top "
      | F.AP(pargs) -> output_string fp (F.pname pargs)
      | F.NOT(p) -> latexbracket (pr > 10) 1 (print_prefix 10) "\lnot " p fp
      | F.AND(p,q) -> latexbracket (pr > 8) 0 (print_infix 8 "\land ") p q fp
      | F.OR(p,q) ->  latexbracket (pr > 6) 0 (print_infix  6 "\lor ") p q fp
      | F.IMP(p,q) -> latexbracket (pr > 4) 0 (print_infix 4 "\limp ") p q fp
      | F.EQU(p,q) ->  latexbracket (pr > 2) 0 (print_infix 2 "\leftrightarrow ") p q fp
      | F.MTRUE -> output_string fp "\\top^* "
      | F.MFALSE -> output_string fp "\bot^* "
      | F.MNOT(p) -> latexbracket (pr > 9) 1 (print_prefix 9) "\mnot " p fp
      | F.MAND(p,q) -> latexbracket (pr > 7) 0 (print_infix 7 "\mand ") p q fp
      | F.MOR(p,q) ->  latexbracket (pr > 5) 0 (print_infix  5 "\mor ") p q fp
      | F.MIMP(p,q) ->  latexbracket (pr > 3) 0 (print_infix 3 "\mimp ") p q fp
  and print_prefix newpr sym p = 
    output_string fp sym; print_latexformula (newpr+1) fp p
  and print_infix newpr sym p q = (* right associativity is used here*)
    print_latexformula (newpr+1) fp p;
    output_string fp (" "^sym^" ");output_string fp " ";
    print_latexformula newpr fp q 
  in
    print_latexformula 0 fp;;

let print_latexbi_formula fp = print_latexformula fp;;

let print_latex_label fp str =
  if str = "epsilon" then output_string fp ("\\"^str) else output_string fp str;;

(* Print a labelled formula *)    
let print_latexformula lf fp =
  match lf with
    | LF(l,f) -> print_latex_label fp l;output_string fp ":";print_latexbi_formula fp f
    | _ -> failwith "No formula to print\n";;

(* Print a list of labelled formulae *)
let rec print_latexformulal lfl fp =
  match lfl with
    | h::t -> 
	print_latexformula h fp;
	if (List.length t) > 0 then 
	  (output_string fp ";";
	   print_latexformulal t fp)
	else print_latexformulal t fp
    | _ -> ();;

(* Print a sequent of formulae *)
let print_latexseq s fp =
  match s with
    | SEQ(lf,rf) -> print_latexformulal lf fp;output_string fp " \vdash ";print_latexformulal rf fp
    | _ -> ();;

(* Print a relation *)
let print_latexrel r fp =
  match r with
    | REQ(s1,s2) -> output_string fp "(";print_latex_label fp s1;output_string fp "=";print_latex_label fp s2;output_string fp ")"
    | RT(s1,s2,s3) -> output_string fp "(";print_latex_label fp s1;output_string fp ",";print_latex_label fp s2;output_string fp "\simp ";print_latex_label fp s3;output_string fp ")"
    | NULLR -> output_string fp "NULL relation detected!"
    | _ -> failwith "Can't print this relation\n";;

(* Print a list of relations *)
let rec print_latexrell rl fp =
  match rl with
    | h::t -> 
	print_latexrel h fp;
	if (List.length t) > 0 then 
	  (output_string fp ";";
	   print_latexrell t fp)
	else print_latexrell t fp
    | _ -> ();;

(* Print the sequent of relations *)
let print_latexrseq rs fp =
  match rs with
    | RSEQ(lr,rr) -> print_latexrell lr fp;output_string fp " \vdash_R ";print_latexrell rr fp
    | _ -> failwith "Can't print this relation sequent\n";;

(* Print the rule *)
let print_latexrule str fp =
  match str with
    | "trueR" -> output_string fp "\\top R"
    | "falseL" -> output_string fp "\\bot L"
    | "mtrueL" -> output_string fp "\\top^* L"
    | "mtrueR" -> output_string fp "\\top^* R"
    | "id" -> output_string fp "id"
    | "&L" -> output_string fp "\land L"
    | "&R" -> output_string fp "\land R"
    | "->L" -> output_string fp "\limp L"
    | "->R" -> output_string fp "\limp R"
    | "*L" -> output_string fp "\mand L"
    | "*R" -> output_string fp "\mand R"
    | "-*L" -> output_string fp "\mimp L"
    | "-*R" -> output_string fp "\mimp R"
    | "idmtrueR" -> output_string fp "id \\ or \\ \\top^* R"
    | "NULL" -> output_string fp "null"
    | "NORULE" -> output_string fp "norule"
    | _ -> failwith ("print_latexrule(): "^str^" is not a valid rule\n");;

let rec print_latexdev dev fp =
  match dev with
    | NULLD -> output_string fp "\AxiomC{}\n"
    | UD(str,seq,ndev) ->
	begin
	  print_latexdev ndev fp;output_string fp "\RightLabel{\\tiny $";
	  print_latexrule str fp;output_string fp "$}\n";
	  output_string fp "\UnaryInfC{$";print_latexseq seq fp;
	  output_string fp "$}\n"
	end 
    | BD(str,seq,nd1,nd2) -> 
	begin
	  print_latexdev nd1 fp;print_latexdev nd2 fp;
	  output_string fp "\RightLabel{\\tiny $";print_latexrule str fp;
	  output_string fp "$}\n";output_string fp "\BinaryInfC{$";
	  print_latexseq seq fp;output_string fp "$}\n"
	end 
    | _ -> failwith "print_latexdev(): Not a valid derivation\n";;

(* Print a list of relational sequents in latex *)
let rec print_latexrseqs rseqs fp =
  match rseqs with
  | h::t -> print_latexrseq h fp;output_string fp "\\\\\n";print_latexrseqs t fp
  | _ -> output_string fp " \\ \\\\\n";;

let print_result fp (rseqs,dev) dis =
  let _ = output_string fp "\\noindent The relation sequents are:\\\\\n$";print_latexrseqs rseqs fp;output_string fp "$\\\\\n\\\\" in
  let _ = if dis then print_endline "reducing the set of constraints" else () in
  let rseqs1 = eqsolvers rseqs in
  if rseqs1 = [RSEQ([NULLR],[NULLR])] then let _ = output_string fp "error when assinging equality relations. check if (ai = aj) is used\n\n" in false
  else 
    begin
      let _ = if dis then print_endline "matching ternary relations" else () in
      let (rseqs2,asst0) = matchtern rseqs1 in
      let _ = if dis then print_endline "simplifying assignments" else () in
      let asst1 = simpassts asst0 in
      let _ = if dis then print_endline "applying Eq1 and Eq2" else () in
      let rseqs3 = idtrsolvers rseqs2 in 
      let _ = output_string fp "\\noindent The eq-reduced relation sequents are:\\\\\n$";print_latexrseqs rseqs1 fp;output_string fp "$\\\\\n\\\\" in
      let _ = output_string fp "\\noindent The tr-reduced relation sequents are:\\\\\n$";print_latexrseqs rseqs2 fp;output_string fp "$\\\\\n\\\\" in
      let _ = output_string fp "\\noindent The Eq1, Eq2-reduced relation sequents are:\\\\\n$";print_latexrseqs rseqs3 fp;output_string fp "$\\\\\n\\\\" in
      let _ = print_endline "computing the set of trees on the RHS" in
      let rhsl2trees = leavesets_fi (getrhstrel rseqs3) in
      let _ = output_string fp "\\noindent The 2-lvl trees on the RHS of relation sequents are:\\\\\n";print_latexl2trees rhsl2trees fp;output_string fp "\\\\\n\\\\" in
      let _ = if dis then print_endline "solving constraints" else () in
      let asst = relsolver2 rseqs3 dis in
      let _ = output_string fp "The derivation is:\\\\\n" in
      let _ = output_string fp "\\begin{center}\n\\tiny\n" in
      let _ = print_latexdev dev fp in
      let _ = output_string fp "\DisplayProof\n\end{center}\n" in
      if (hasconstr rseqs3) then 
	if asst = [REQ("-1","-1")] || asst1 = [REQ("-1","-1")] then false 
	else 
	  let _ = 
	    if asst = [] then output_string fp "\\noindent No assignments needed\\\\\n"
	    else 
	  if asst1 = [] then (output_string fp "\\noindent The solved assignments are:\\\\\n$";print_latexrell (asst) fp;output_string fp "$\\\\\n\\\\")
	  else (output_string fp "\\noindent The preassigned assignments are:\\\\\n$";print_latexrell (asst1) fp;output_string fp "$\\\\\n\\\\";output_string fp "\\noindent The solved assignments are:\\\\\n$";print_latexrell (asst) fp;output_string fp "$\\\\\n\\\\") 
	  in
	  true
      else if asst1 = [REQ("-1","-1")] then false
      else 
	if List.length asst1 > 0 then 
	  let _ = output_string fp "\\noindent The assignments are:\\\\\n$";print_latexrell asst1 fp;output_string fp "$\\\\\n\\\\" in
	  true
	else true
    end;;

let rec print_latexsudosubs subl fp =
  match subl with
  | h::t -> let (f1,f2) = h in 
	    print_latexbi_formula fp f1;output_string fp " = ";print_latexbi_formula fp f2;output_string fp "\\\\";
	    print_latexsudosubs t fp
  | _ -> ();;

let label formula dis =
  let (rseqs,dev) = proofsearch formula dis in
  let rseqs0 = eqsolvers rseqs in
  if rseqs0 = [RSEQ([NULLR],[NULLR])] then false
  else 
  let (rseqs1,asst0) = matchtern rseqs0 in
  let asst1 = simpassts asst0 in
  let rseqs2 = idtrsolvers rseqs1 in
  let asst = relsolver2 rseqs2 dis in
  if (closedptree dev) then 
    if (noconstr rseqs2) then 
      (if asst1 = [REQ("-1","-1")] then false
       else true)
    else 
      if asst = [REQ("-1","-1")] || asst1 = [REQ("-1","-1")] then false
      else true 
    else false;;

let label_eager formula dis =
  let (rseqs,dev) = proofsearch_eager formula dis in
  let rseqs0 = eqsolvers rseqs in
  if rseqs0 = [RSEQ([NULLR],[NULLR])] then false
  else 
  let (rseqs1,asst0) = matchtern rseqs0 in
  let asst1 = simpassts asst0 in
  let rseqs2 = idtrsolvers rseqs1 in
  let asst = relsolver2 rseqs2 dis in
  if (closedptree dev) then 
    if (noconstr rseqs2) then 
      (if asst1 = [REQ("-1","-1")] then false
       else true)
    else 
      if asst = [REQ("-1","-1")] || asst1 = [REQ("-1","-1")] then false
      else true 
    else false;;
  
(* try to prove f with eager proof search *)
let tryproof_eager f sudosubs dis =
  let starttime = Unix.gettimeofday () in
  let fptex = open_out "ptree.tex" in
  let _ = writetexhead fptex in
  let _ = print_endline "trying to find an eager derivation" in
  let (rseqs,dev) = proofsearch_eager f dis in
  let _ = print_endline "derivation tree found, checking constraints" in
  let solved = print_result fptex (rseqs,dev) dis in
  let finishtime = Unix.gettimeofday () in
  let _ = if List.length sudosubs  = 0 then () else (output_string fptex "The sudo formulae are:\\\\$";print_latexsudosubs sudosubs fptex;output_string fptex "$\\\\")  in
  let _ = output_string fptex ("\ \\\nTime used in proof search: "^(string_of_float (finishtime -. starttime))^" seconds\n\\") in
  let _ = writetexend fptex in
  let _ = close_out fptex in
  let _ = Sys.command "pdflatex ptree.tex" in
  if (closedptree dev) then 
    if solved then 
      let _ = print_endline "constraints from the eager derivation solved\n" in true
    else 
      let _ = print_endline "constraints are unsolved for the eager derivation\n" in false
  else
    let _ = print_endline "Can't find an eager derivation.\n" in false;;

(* try to prove f with full proof search *)
let tryproof f sudosubs dis =
  let starttime = Unix.gettimeofday () in
  let fptex = open_out "ptree.tex" in
  let _ = writetexhead fptex in
  let _ = print_endline "trying to find a lazy derivation" in
  let (rseqs,dev) = proofsearch f dis in
  let _ = print_endline "derivation tree found, checking constraints" in
  let solved = print_result fptex (rseqs,dev) dis in
  let finishtime = Unix.gettimeofday () in
  let _ = if List.length sudosubs  = 0 then () else (output_string fptex "The sudo formulae are:\\\\$";print_latexsudosubs sudosubs fptex;output_string fptex "$\\\\") in
  let _ = output_string fptex ("\ \\\nTime used in proof search: "^(string_of_float (finishtime -. starttime))^" seconds\n\\") in
  let _ = writetexend fptex in
  let _ = close_out fptex in
  let _ = Sys.command "pdflatex ptree.tex" in
  if (closedptree dev) then 
    if solved then 
      let _ = print_endline "constraints from the lazy derivation solved\n" in true
    else 
      let _ = print_endline "constraints are unsolved for the lazy derivation\n" in false
  else
    let _ = print_endline "Can't find an lazy derivation.\n" in false;;

(* a strategy for proof search *)
let strategyproof f dis =
  let subl = F.subfsubst f in
  let simpf = F.substFormula subl f in
  if tryproof_eager simpf subl dis then true
  else if tryproof simpf subl dis then true
  else if tryproof_eager f [] dis then true
  else if tryproof f [] dis then true
  else false;;

(* a stretegy proof search for testing *)
let strategyproof_test f dis =
  let start = Unix.gettimeofday () in
  let subl = F.subfsubst f in
  let simpf = F.substFormula subl f in
  if label_eager simpf dis then 
    let finish = Unix.gettimeofday () in
    let time = finish -. start in
    let _ = print_endline "Eager search proved the simplified formula" in
    ("Proved "^(string_of_float time))
  else if label simpf dis then 
    let finish = Unix.gettimeofday () in
    let time = finish -. start in
    let _ = print_endline "Full search proved the simplified formula" in
    ("Proved "^(string_of_float time))
  else if label_eager f dis then 
    let finish = Unix.gettimeofday () in
    let time = finish -. start in
    let _ = print_endline "Eager search proved the formula" in
    ("Proved "^(string_of_float time))
  else if label f dis then 
    let finish = Unix.gettimeofday () in
    let time = finish -. start in
    let _ = print_endline "Full search proved the formula" in
    ("Proved "^(string_of_float time))
  else 
    let _ = print_endline "Failed to proved the formula" in
    "NULL";;

let label_testlist flist dis =
  let rec test flist acc dis =
    match flist with
    | h::t -> let result = strategyproof_test h dis in
	      test t (acc@[result]) dis 
    | _ -> acc 
  in 
  test flist [] dis;;
