module N = Naive
module F = BIformulae
module M = Misc

let naivetest =
  if (Array.length Sys.argv) != 2 then failwith ("Need one parameter for label: input file, but read "^(string_of_int ((Array.length Sys.argv)-1))^"parameters")
  else
    let infile = Sys.argv.(1) in
    let f = F.parse (M.readfile infile) in
    let fof = N.naive_translation f in
    let tptpf = N.tptptrans fof in
    let fp = open_out "naivef.p" in
    let _ = output_string fp tptpf;close_out fp in
    Sys.command "./vampire_rel --proof tptp --output_axiom_names on --mode casc -t 100 naivef.p";;
