module F = BIformulae
module M = Misc

let count = ref 0;;

let rec naive_trans f world = 
  match f with
    | F.TRUE -> "$true"   
    | F.FALSE -> "$false"   
    | F.MTRUE -> "(W"^(string_of_int world)^" = epsilon)"
    | F.AP s -> (F.pname s)^"(W"^(string_of_int world)^")"
    | F.NOT f1 -> "~("^(naive_trans f1 world)^")"
    | F.EQU (f1, f2) -> "("^(naive_trans f1 world)^" <=> "^(naive_trans f2 world)^")"
    | F.IMP (f1, f2) -> "("^(naive_trans f1 world)^" => "^(naive_trans f2 world)^")"
    | F.AND (f1, f2) -> "("^(naive_trans f1 world)^" & "^(naive_trans f2 world)^")" 
    | F.OR (f1, f2) -> "("^(naive_trans f1 world)^" | "^(naive_trans f2 world)^")" 
    | F.MAND (f1, f2) -> 
	let _ = count := !count+2 in
	let t = !count in
	  "(? "^"[W"^(string_of_int (t-1))^",W"^(string_of_int t)^"]: (r("^"W"^(string_of_int (t-1))^",W"^(string_of_int t)^",W"^(string_of_int world)^") & "^(naive_trans f1 (t-1))^" & "^(naive_trans f2 t)^"))"
    | F.MIMP (f1, f2) -> 
	let _ = count := !count+2 in
	let t = !count in
	  "(! ["^"W"^(string_of_int (t-1))^",W"^(string_of_int t)^"]: ((r("^"W"^(string_of_int (t-1))^",W"^(string_of_int world)^",W"^(string_of_int t)^") & "^(naive_trans f1 (t-1))^") => "^(naive_trans f2 t)^"))"
    | _ -> failwith "illegal BBI formula";;

let naive_translation f = naive_trans f 0;;

(*let naive = 
  let f = F.parse (M.readfile "bi_formulae.bi") in
  let fof = naive_translation f in
  let tptpf = "fof(identity,axiom,(\n\t ! [A,B]: (r(epsilon,A,B) <=> (A = B)))).\n\nfof(commutativity,axiom,(\n\t! [A,B,C]: (r(A,B,C) <=> r(B,A,C)))).\n\nfof(associativity,axiom,(\n\t ! [A,B,C,D]: ((? [K]: (r(A,K,D) & r(B,C,K))) => (? [P]: (r(A,B,P) & r(P,C,D)))))).\n\nfof(problem,conjecture,(\n\t![W0]: ("^fof^"))).\n" in
  let fp = open_out "naivef.p" in
    output_string fp tptpf;close_out fp;print_endline "Invoking Vampire 2.6...";Sys.command "./vampire_rel --proof tptp --output_axiom_names on --mode casc -t 500 naivef.p";;
*)

let tptptrans fof = "fof(identity,axiom,(\n\t ! [A,B]: (r(epsilon,A,B) <=> (A = B)))).\n\nfof(commutativity,axiom,(\n\t! [A,B,C]: (r(A,B,C) <=> r(B,A,C)))).\n\nfof(associativity,axiom,(\n\t ! [A,B,C,D]: ((? [K]: (r(A,K,D) & r(B,C,K))) => (? [P]: (r(A,B,P) & r(P,C,D)))))).\n\nfof(problem,conjecture,(\n\t![W0]: ("^fof^"))).\n";;
  
let naive formula =
  let fof = naive_translation formula in
  tptptrans fof;;

let naivetranslist flist =
  let rec trans flist acc =
    match flist with
    | h::t -> let tptpf = naive h in
	      trans t (acc@[tptpf])
    | _ -> acc
  in 
  trans flist [];;

(*let naive =
  if (Array.length Sys.argv) != 3 then failwith ("Need two parameters for naive: input file and output file, but read "^(string_of_int ((Array.length Sys.argv)-1))^"parameters")
  else
    let infile = Sys.argv.(1) in
    let outfile = Sys.argv.(2) in
    let f = F.parse (M.readfile infile) in
    let fof = naive_translation f in
    let tptpf = tptptrans fof in
    let fp = open_out outfile in
    output_string fp tptpf;close_out fp;;*)
