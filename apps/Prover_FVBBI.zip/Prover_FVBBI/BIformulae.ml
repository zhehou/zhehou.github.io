(*Lexing*)

let explode s =
  let rec f acc = function
    | -1 -> acc
    | k -> f (s.[k] :: acc) (k - 1)
  in f [] (String.length s - 1)

let matches s = 
  let chars = 
    explode s in 
    fun c -> List.mem c chars;;

let space = matches " \t\n\r"
and punctuation = matches "()[]{},"
and symbolic = matches "~`!@#$%^&*-+=|\\:;<>.?/"
and numeric = matches "0123456789"
and alphanumeric = matches
  "abcdefghijklmnopqrstuvwxyz_'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";;

let rec lexwhile prop inp =
  match inp with
  | c::cs when prop c -> let tok,rest = 
      lexwhile prop cs in 
      (Char.escaped c)^tok,rest
  | _ -> "",inp;;


let rec lex inp =
  match snd(lexwhile space inp) with
    [] -> []
  | c::cs -> let prop = if alphanumeric(c) then alphanumeric
                        else if symbolic(c) then symbolic
                        else fun c -> false in
             let toktl,rest = lexwhile prop cs in
             ((Char.escaped c)^toktl)::lex rest;;

(*Parsing*)

type ('a)formula = 
  | TRUE
  | FALSE
  | AP of ('a)
  | NOT of ('a)formula
  | EQU of ('a)formula * ('a)formula
  | IMP of ('a)formula * ('a)formula
  | OR of ('a)formula * ('a)formula
  | AND of ('a)formula * ('a)formula
  | MTRUE
  | MFALSE
  | MAND of ('a)formula * ('a)formula
  | MIMP of ('a)formula * ('a)formula
  | MOR of ('a)formula * ('a)formula
  | MNOT of ('a)formula;;

let rec sizeFormula f =
  match f with
  | TRUE 
  | FALSE 
  | MTRUE
  | MFALSE
  | AP _ -> 1
  | NOT f1
  | MNOT f1 -> succ (sizeFormula f1)
  | EQU (f1, f2) 
  | IMP (f1, f2)
  | OR (f1, f2)  
  | AND (f1, f2)
  | MAND (f1, f2)
  | MOR (f1, f2)
  | MIMP (f1, f2) -> succ (sizeFormula f1 + sizeFormula f2);;

let numConnectives f =
  let num = ref 0 in
  let rec reccheck f =
    match f with
    | TRUE 
    | FALSE 
    | MTRUE
    | MFALSE
    | AP _ -> ()
    | NOT f1
    | MNOT f1 -> let _ = num := !num + 1 in reccheck f1
    | EQU (f1, f2) 
    | IMP (f1, f2)
    | OR (f1, f2)  
    | AND (f1, f2)
    | MAND (f1, f2)
    | MOR (f1, f2)
    | MIMP (f1, f2) -> let _ = num := !num +1 in reccheck f1; reccheck f2
  in 
  let _ = reccheck f in
  !num;;

(* ------------------------------------------------------------------------- *)
(* General parsing of iterated infixes.                                      *)
(* ------------------------------------------------------------------------- *)

let rec parse_ginfix opsym opupdate sof subparser inp =
  let e1,inp1 = subparser inp in
  if inp1 <> [] & List.hd inp1 = opsym then
     parse_ginfix opsym opupdate (opupdate sof e1) subparser (List.tl inp1)
  else sof e1,inp1;;

let parse_left_infix opsym opcon =
  parse_ginfix opsym (fun f e1 e2 -> opcon(f e1,e2)) (fun x -> x);;

let parse_right_infix opsym opcon =
  parse_ginfix opsym (fun f e1 e2 -> f(opcon(e1,e2))) (fun x -> x);;

let parse_list opsym =
  parse_ginfix opsym (fun f e1 e2 -> (f e1)@[e2]) (fun x -> [x]);;

(* ------------------------------------------------------------------------- *)
(* Other general parsing combinators.                                        *)
(* ------------------------------------------------------------------------- *)

let papply f (ast,rest) = (f ast,rest);;

let nextin inp tok = inp <> [] & List.hd inp = tok;;

let parse_bracketed subparser cbra inp =
  let ast,rest = subparser inp in
  if nextin rest cbra then ast,(List.tl rest)
  else failwith "Closing bracket expected";;

(* ------------------------------------------------------------------------- *)
(* Parsing of formulas, parametrized by atom parser "pfn".                   *)
(* ------------------------------------------------------------------------- *)

let rec parse_atomic_formula (ifn,afn) vs inp =
  match inp with
    [] -> failwith "formula expected"
  | "false"::rest -> FALSE,rest
  | "true"::rest -> TRUE,rest
  | "("::rest -> (try ifn vs inp with Failure _ ->
                  parse_bracketed (parse_formula (ifn,afn) vs) ")" rest)
  | "-"::rest -> papply (fun p -> NOT p)
                        (parse_atomic_formula (ifn,afn) vs rest)
  | "mtrue"::rest -> MTRUE,rest
  | "mfalse"::rest -> MFALSE,rest
  | "~"::rest -> papply (fun p -> MNOT p)
                        (parse_atomic_formula (ifn,afn) vs rest)
  | _ -> afn vs inp

and parse_formula (ifn,afn) vs inp = (* right associativity is used here*)
   parse_right_infix "<->" (fun (p,q) -> EQU(p,q))
     (parse_right_infix "-*" (fun (p,q) -> MIMP(p,q))
         (parse_right_infix "->" (fun (p,q) -> IMP(p,q))
             (parse_right_infix "+" (fun (p,q) -> MOR(p,q))
		(parse_right_infix "|" (fun (p,q) -> OR(p,q))
		   (parse_right_infix "*" (fun (p,q) -> MAND(p,q))
		      (parse_right_infix "&" (fun (p,q) -> AND(p,q))		       
			 (parse_atomic_formula (ifn,afn) vs))))))) inp;;


(* ------------------------------------------------------------------------- *)
(* Generic function to impose lexing and exhaustion checking on a parser.    *)
(* ------------------------------------------------------------------------- *)

let make_parser pfn s =
  let expr,rest = pfn (lex(explode s)) in
  if rest = [] then expr else failwith "Unparsed input";;

(* ------------------------------------------------------------------------- *)
(* Parsing of propositional formulas.                                        *)
(* ------------------------------------------------------------------------- *)

type prop = P of string;;

let pname(P s) = s;;

let parse_propvar vs inp =
  match inp with
    p::oinp when p <> "(" -> AP(P(p)),oinp
  | _ -> failwith "parse_propvar";;

let parse_bi_formula = make_parser
  (parse_formula ((fun _ _ -> failwith ""),parse_propvar) []);;

(* ------------------------------------------------------------------------- *)
(* Set this up as default for quotations.                                    *)
(* ------------------------------------------------------------------------- *)

let parse = parse_bi_formula;;

(* parse a list of string to a list of formulae*)
let parselist list =
  let rec recparse list acc = 
    match list with
    | h::t -> recparse t (acc@[parse h])
    | _ -> acc
  in 
  recparse list [];;

(* ------------------------------------------------------------------------- *)
(* Printing of formulas, parametrized by atom printer.                       *)
(* ------------------------------------------------------------------------- *)

let bracket p n f x y =
  (if p then print_string "(" else ());
  Format.open_box n; f x y; Format.close_box();
  (if p then print_string ")" else ());;

let print_formula pfn =
  let rec print_formula pr fm =
    match fm with
      | FALSE -> print_string "FALSE"
      | TRUE -> print_string "TRUE"
      | AP(pargs) -> pfn pr pargs
      | NOT(p) -> bracket (pr > 10) 1 (print_prefix 10) "-" p
      | AND(p,q) -> bracket (pr > 8) 0 (print_infix 8 "&") p q
      | OR(p,q) ->  bracket (pr > 6) 0 (print_infix  6 "|") p q
      | IMP(p,q) ->  bracket (pr > 4) 0 (print_infix 4 "->") p q
      | EQU(p,q) ->  bracket (pr > 2) 0 (print_infix 2 "<->") p q
      | MTRUE -> print_string "MTRUE"
      | MFALSE -> print_string "MFALSE"
      | MNOT(p) -> bracket (pr > 9) 1 (print_prefix 9) "~" p
      | MAND(p,q) -> bracket (pr > 7) 0 (print_infix 7 "*") p q
      | MOR(p,q) ->  bracket (pr > 5) 0 (print_infix  5 "+") p q
      | MIMP(p,q) ->  bracket (pr > 3) 0 (print_infix 3 "-*") p q
  and print_prefix newpr sym p = 
   print_string sym; print_formula (newpr+1) p
  and print_infix newpr sym p q = (* right associativity is used here*)
    print_formula (newpr+1) p;
    print_string(" "^sym^" "); Format.print_space();
    print_formula newpr q in
    print_formula 0;;

let print_biformula pfn fm =
  Format.open_box 0; print_string "<<";
  Format.open_box 0; print_formula pfn fm; Format.close_box();
  print_string ">>"; Format.close_box();;

let print_justformula pfn fm =
  Format.open_box 0; 
  Format.open_box 0; print_formula pfn fm; Format.close_box();
  Format.close_box();;

(* ------------------------------------------------------------------------- *)
(* Printer.                                                                  *)
(* ------------------------------------------------------------------------- *)

let print_propvar prec p = print_string(pname p);;

let print_bi_formula = print_biformula print_propvar;;

let print_justbi_formula = print_justformula print_propvar;;
(*#install_printer print_bi_formula;;*)


(* ------------------------------------------------------------------------- *)
(* Print a formula in a file                                                 *)
(* ------------------------------------------------------------------------- *)

let filebracket p n f x y fp =
  (if p then output_string fp "(" else ());
  Format.open_box n;f x y;Format.close_box();
  (if p then output_string fp")" else ());;

let print_fileformula fp =
  let rec print_fileformula pr fp fm =
    match fm with
      | FALSE -> output_string fp "false "
      | TRUE -> output_string fp "true "
      | AP(pargs) -> output_string fp (pname pargs)
      | NOT(p) -> filebracket (pr > 10) 1 (print_prefix 10) "- " p fp
      | AND(p,q) -> filebracket (pr > 8) 0 (print_infix 8 "& ") p q fp
      | OR(p,q) ->  filebracket (pr > 6) 0 (print_infix  6 "| ") p q fp
      | IMP(p,q) -> filebracket (pr > 4) 0 (print_infix 4 "-> ") p q fp
      | EQU(p,q) ->  filebracket (pr > 2) 0 (print_infix 2 "<-> ") p q fp
      | MTRUE -> output_string fp "mtrue "
      | MFALSE -> output_string fp "mfalse "
      | MNOT(p) -> filebracket (pr > 9) 1 (print_prefix 9) "~ " p fp
      | MAND(p,q) -> filebracket (pr > 7) 0 (print_infix 7 "* ") p q fp
      | MOR(p,q) ->  filebracket (pr > 5) 0 (print_infix  5 "+ ") p q fp
      | MIMP(p,q) ->  filebracket (pr > 3) 0 (print_infix 3 "-* ") p q fp
  and print_prefix newpr sym p = 
    output_string fp sym; print_fileformula (newpr+1) fp p
  and print_infix newpr sym p q = (* right associativity is used here*)
    print_fileformula (newpr+1) fp p;
    output_string fp (" "^sym^" ");output_string fp " ";
    print_fileformula newpr fp q 
  in
    print_fileformula 0 fp;;

let print_filebi_formula fp = print_fileformula fp;;

(* ------------------------------------------------------------------------- *)
(* OCaml won't let us use the constructors.                                  *)
(* ------------------------------------------------------------------------- *)

let mk_and p q = AND(p,q)  
and mk_or p q = OR(p,q)
and mk_imp p q = IMP(p,q) 
and mk_equ p q = EQU(p,q)
and mk_not p = NOT(p)
and mk_mand p q = MAND(p,q)
and mk_mor p q = MOR(p,q)
and mk_mimp p q = MIMP(p,q)
and mk_mnot p = MNOT(p);;

(* ------------------------------------------------------------------------- *)
(* Destructors.                                                              *)
(* ------------------------------------------------------------------------- *)

let dest_equ fm =
  match fm with EQU(p,q) -> (p,q) | _ -> failwith "dest_que";;

let dest_not fm =
  match fm with NOT(p) -> p | _ -> failwith "dest_not";;

let rec negations fm = 
  match fm with NOT(p) -> negations p | _ -> [fm];;

let dest_and fm =
  match fm with AND(p,q) -> (p,q) | _ -> failwith "dest_and";;

let rec conjuncts fm =
  match fm with AND(p,q) -> conjuncts p @ conjuncts q | _ -> [fm];;

let dest_or fm =
  match fm with OR(p,q) -> (p,q) | _ -> failwith "dest_or";;

let rec disjuncts fm =
  match fm with OR(p,q) -> disjuncts p @ disjuncts q | _ -> [fm];;

let dest_imp fm =
  match fm with IMP(p,q) -> (p,q) | _ -> failwith "dest_imp";;

let dest_mnot fm =
  match fm with MNOT(p) -> p | _ -> failwith "dest_mnot";;

let rec mnegations fm = 
  match fm with MNOT(p) -> mnegations p | _ -> [fm];;

let dest_mand fm =
  match fm with MAND(p,q) -> (p,q) | _ -> failwith "dest_mand";;

let rec mconjuncts fm =
  match fm with MAND(p,q) -> mconjuncts p @ mconjuncts q | _ -> [fm];;

let dest_mor fm =
  match fm with MOR(p,q) -> (p,q) | _ -> failwith "dest_mor";;

let rec mdisjuncts fm =
  match fm with MOR(p,q) -> mdisjuncts p @ mdisjuncts q | _ -> [fm];;

let dest_mimp fm =
  match fm with MIMP(p,q) -> (p,q) | _ -> failwith "dest_mimp";;

let antecedent fm = fst(dest_imp fm);;
let consequent fm = snd(dest_imp fm);;

(* ------------------------------------------------------------------------- *)
(* Apply a function to the atoms, otherwise keeping structure.               *)
(* ------------------------------------------------------------------------- *)

let rec onatoms f fm =
  match fm with
    AP a -> f a
  | NOT(p) -> NOT(onatoms f p)
  | AND(p,q) -> AND(onatoms f p,onatoms f q)
  | OR(p,q) -> OR(onatoms f p,onatoms f q)
  | IMP(p,q) -> IMP(onatoms f p,onatoms f q)
  | EQU(p,q) -> EQU(onatoms f p,onatoms f q)
  | MNOT(p) -> MNOT(onatoms f p)
  | MAND(p,q) -> MAND(onatoms f p,onatoms f q)
  | MOR(p,q) -> MOR(onatoms f p,onatoms f q)
  | MIMP(p,q) -> MIMP(onatoms f p,onatoms f q)
  | _ -> fm;;

(* ------------------------------------------------------------------------- *)
(* Formula analog of list iterator "itlist".                                 *)
(* ------------------------------------------------------------------------- *)

let rec overatoms f fm b =
  match fm with
    AP(a) -> f a b
  | NOT(p) | MNOT(p) -> overatoms f p b
  | AND(p,q) | OR(p,q) | IMP(p,q) | EQU(p,q) | MAND(p,q) | MOR(p,q) | MIMP(p,q) ->
        overatoms f p (overatoms f q b)
  | _ -> b;;

(** The constant True.
 *)
let const_true = TRUE;;

(** The constant False.
 *)
let const_false = FALSE;;
    
(** Constructs an atomic proposition.
    @param s The name of the atomic proposition.
    @return The atomic proposition with name s.
 *)
let const_ap s = AP (P s);;

(** Negates a formula.
    @param f A formula.
    @return The negation of f.
 *)
let const_not f = NOT f;;

(** Constructs an equivalence from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The equivalence f1 <=> f2.
 *)
let const_equ f1 f2 = EQU (f1, f2);;

(** Constructs an implication from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The implication f1 => f2.
 *)
let const_imp f1 f2 = IMP (f1, f2);;

(** Constructs an or-formula from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The formula f1 | f2.
 *)
let const_or f1 f2 = OR (f1, f2);;

(** Constructs an and-formula from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The formula f1 & f2.
 *)    
let const_and f1 f2 = AND (f1, f2);;

(* The constant multiplicative truth *)
let const_mtrue = MTRUE;;

(* The constant multiplicative false *)
let const_mfalse = MFALSE;;

(** Multiplicatively negates a formula.
    @param f A formula.
    @return The negation of f.
 *)
let const_mnot f = MNOT f;;

(** Constructs a multiplicative implication from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The multiplicative implication f1 -* f2.
 *)
let const_mimp f1 f2 = MIMP (f1, f2);;

(** Constructs a multiplicative or-formula from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The formula f1 + f2.
 *)
let const_mor f1 f2 = MOR (f1, f2);;

(** Constructs a multiplicative and-formula from two formulae.
    @param f1 The first formula (LHS).
    @param f2 The second formula (LHS).
    @return The formula f1 * f2.
 *)    
let const_mand f1 f2 = MAND (f1, f2);;

(* ------------------------------------------------------------------------- *)
(* Additional functions.                                                     *)
(* ------------------------------------------------------------------------- *)

(* test if f1 is a subformula of f2 *)
let rec issubFormula f1 f2 =
  if f1 = f2 then true
  else 
    match f2 with
    | TRUE
    | FALSE
    | MTRUE
    | MFALSE
    | AP _ -> false
    | NOT f3 
    | MNOT f3 -> issubFormula f1 f3
    | EQU (f3,f4)
    | IMP(f3,f4)
    | OR(f3,f4)
    | AND(f3,f4)
    | MAND(f3,f4)
    | MOR(f3,f4) 
    | MIMP(f3,f4) -> issubFormula f1 f3 || issubFormula f1 f4;;

(** Substitutes some subformulae in a formula.
    @param subl A list of pairs (subf, fp) 
    where subf is a subformula in f and fp is a formula.
    @param f A formula.
    @return A formula f' where each subformula subf
    such that (subf, fp) is contained in subl is replaced by fp.
    NOTE THAT if subf is atomic, it's not substituted!
 *)
let rec substFormula subl f =
  if List.mem_assoc f subl then List.assoc f subl 
  else
    match f with
    | TRUE
    | FALSE 
    | MTRUE
    | MFALSE
    | AP _ -> f
    | NOT f1 -> NOT(substFormula subl f1)
    | MNOT f1 -> MNOT(substFormula subl f1)
    | EQU (f1, f2) -> EQU((substFormula subl f1),(substFormula subl f2))
    | IMP (f1, f2) -> IMP((substFormula subl f1),(substFormula subl f2))
    | OR (f1, f2) -> OR((substFormula subl f1),(substFormula subl f2))
    | AND (f1, f2) -> AND((substFormula subl f1),(substFormula subl f2))
    | MAND (f1, f2) -> MAND((substFormula subl f1),(substFormula subl f2))
    | MOR (f1, f2) -> MOR((substFormula subl f1),(substFormula subl f2))
    | MIMP (f1, f2) -> MIMP((substFormula subl f1),(substFormula subl f2));;

(* find common subformulae in f, make a list [(subf,fp)] for substitution *)
let subfsubst f =
  let rec issubf f rhsl =
    match rhsl with
    | h::t -> if issubFormula f h then true else issubf f t
    | _ -> false
  in 
  let newfnum = ref 0 in
  let subl = ref [] in
  let rec findsubf f rhsl =
    match f with
    | TRUE 
    | FALSE 
    | MTRUE
    | MFALSE
    | AP _ -> ()
    | _ ->
      if issubf f rhsl then 
	begin 
	  if List.mem_assoc f !subl then ()
	  else let _ = newfnum := !newfnum + 1 in 
	       let _ = subl := (!subl@[(f,(AP(P("sudo"^(string_of_int !newfnum)))))]) in ()
	end 
      else 
	begin
	  match f with
	  | NOT f1
	  | MNOT f1 -> findsubf f1 rhsl
	  | EQU (f1, f2) 
	  | IMP (f1, f2)
	  | OR (f1, f2)  
	  | AND (f1, f2)
	  | MAND (f1, f2)
	  | MOR (f1, f2)
	  | MIMP (f1, f2) -> findsubf f1 (rhsl@[f2]);findsubf f2 rhsl;
	  | _ -> failwith "findsubf(): invalid formula!"
	end 
  in 
  let _ = findsubf f [] in !subl;;

(* simplify formula f by replcaing the common subformulae by new atomic formulae *)
let atomsimpFormula f = let subl = subfsubst f in substFormula subl f;;
